-- PulseMDT :: pulse_property (Ownable properties)
--
-- Real walk-in interiors, not just a lockable door. Properties draw from a
-- small curated pool of interior "shells" already built into the base game
-- (the same apartment interiors GTA Online itself reuses), so this works
-- with nothing extra installed, no paid MLO pack required. Admins who want
-- distinct custom interiors can replace or add to Config.Shells with their
-- own MLO/IPL coordinates.
--
-- IMPORTANT LIMITATION: these shells are physical spaces already in the game
-- world, reused across every property that picks the same shell. Two
-- players who each own a "Small Apartment" both walk into the SAME interior
-- location; this is a real simplification of using free base-game interiors
-- instead of per-property instanced MLOs, not a bug. If that matters for
-- your server, use one shell per property or add custom MLO coordinates.
--
-- Each property's entry door is registered through pulse_doorlocks (install
-- it alongside this), so locking a property door works exactly like any
-- other pulse_doorlocks door.
--
-- Admin commands (require the ace permission below):
--   /propertyadd <shellKey> <price> [name...]   list a new property for sale
--                                                 where you're standing
--   /propertylist                                list all properties
--   /propertyremove <id>                         remove a listing
--
-- Grant an admin access in server.cfg:
--   add_ace group.admin pulse.property allow

Config = {}

Config.AcePermission = 'pulse.property'

Config.InteractRange = 2.0

-- Percent of the purchase price credited back when an owner sells.
Config.SellReturnPercent = 60

-- Interior shells. `enter` is where a player is teleported inside; leaving
-- returns them to the property's own exterior door position.
Config.Shells = {
    { key = 'small',  label = 'Small Apartment',  interiorSet = 'apa_v_mp_h_01_a', enter = { x = -791.3, y = 312.4, z = 145.8, heading = 0.0 } },
    { key = 'medium', label = 'Medium Apartment', interiorSet = 'apa_v_mp_h_01_b', enter = { x = -791.3, y = 312.4, z = 149.3, heading = 0.0 } },
    { key = 'large',  label = 'Large Apartment',  interiorSet = 'apa_v_mp_h_01_c', enter = { x = -791.3, y = 312.4, z = 152.8, heading = 0.0 } },
    { key = 'house',  label = 'Safehouse',        interiorSet = 'v_safehouse01',   enter = { x = -1150.6, y = -1520.7, z = 10.5, heading = 90.0 } },
}

Config.Blip = { sprite = 40, color = 2, label = 'Property' }
