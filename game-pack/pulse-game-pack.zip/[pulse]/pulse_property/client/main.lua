local properties = {}
local menuOpen = false
local insidePropertyId = nil
local exteriorReturn = nil
local nearestPropertyId = nil

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_property:notify', function(msg)
    if msg then notify(msg) end
end)

local propertyBlips = {}
local function rebuildBlips()
    for _, b in ipairs(propertyBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    propertyBlips = {}
    for _, p in ipairs(properties) do
        local b = AddBlipForCoord(p.x, p.y, p.z)
        SetBlipSprite(b, Config.Blip.sprite)
        SetBlipColour(b, p.char_id and 2 or Config.Blip.color)
        SetBlipScale(b, 0.75)
        SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName(p.label)
        EndTextCommandSetBlipName(b)
        propertyBlips[#propertyBlips + 1] = b
    end
end

RegisterNetEvent('pulse_property:sync', function(payload)
    properties = payload or {}
    rebuildBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_property:requestSync')
end)

local function propertyById(id)
    for _, p in ipairs(properties) do if p.id == id then return p end end
    return nil
end

RegisterNetEvent('pulse_property:enterResult', function(propertyId, allowed)
    if not allowed then notify('~r~You do not have access to this property.') return end
    local p = propertyById(propertyId)
    if not p then return end
    local shell = nil
    for _, s in ipairs(Config.Shells) do if s.key == p.shell_key then shell = s break end end
    if not shell then notify('~r~Unknown interior shell.') return end

    exteriorReturn = { x = p.x, y = p.y, z = p.z, heading = p.heading }
    insidePropertyId = propertyId
    local ped = PlayerPedId()
    ActivateInteriorEntitySet(GetInteriorAtCoords(shell.enter.x, shell.enter.y, shell.enter.z), shell.interiorSet)
    SetEntityCoords(ped, shell.enter.x, shell.enter.y, shell.enter.z, false, false, false, false)
    SetEntityHeading(ped, shell.enter.heading or 0.0)
    notify('~g~Welcome home. Use /leaveproperty to head back outside.')
end)

RegisterCommand('leaveproperty', function()
    if not insidePropertyId or not exteriorReturn then notify('~y~You are not inside a property.') return end
    local ped = PlayerPedId()
    SetEntityCoords(ped, exteriorReturn.x, exteriorReturn.y, exteriorReturn.z, false, false, false, false)
    SetEntityHeading(ped, exteriorReturn.heading or 0.0)
    insidePropertyId = nil
    exteriorReturn = nil
end, false)

RegisterNUICallback('buyProperty', function(data, cb)
    TriggerServerEvent('pulse_property:buy', data.propertyId)
    cb({})
end)

RegisterNUICallback('closeListing', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

CreateThread(function()
    while true do
        local sleep = 900
        nearestPropertyId = nil
        if not menuOpen then
            local pos = GetEntityCoords(PlayerPedId())
            for _, p in ipairs(properties) do
                local dist = #(pos - vector3(p.x, p.y, p.z))
                if dist < 30.0 then
                    sleep = 0
                    DrawMarker(2, p.x, p.y, p.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                        0.5, 0.5, 0.5, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                    if dist <= Config.InteractRange then
                        nearestPropertyId = p.id
                        if not p.char_id then
                            BeginTextCommandDisplayHelp('STRING')
                            AddTextComponentSubstringPlayerName(('Press ~INPUT_CONTEXT~ to view listing ($%d)'):format(p.price))
                            EndTextCommandDisplayHelp(0, false, true, -1)
                            if IsControlJustReleased(0, 38) then
                                menuOpen = true
                                SetNuiFocus(true, true)
                                SendNUIMessage({ action = 'listing', propertyId = p.id, label = p.label, price = p.price, shellKey = p.shell_key })
                                Wait(400)
                            end
                        else
                            BeginTextCommandDisplayHelp('STRING')
                            AddTextComponentSubstringPlayerName('Press ~INPUT_CONTEXT~ to enter')
                            EndTextCommandDisplayHelp(0, false, true, -1)
                            if IsControlJustReleased(0, 38) then
                                TriggerServerEvent('pulse_property:requestEnter', p.id)
                                Wait(400)
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

local function ownerTargetPropertyId()
    return insidePropertyId or nearestPropertyId
end

RegisterCommand('lockproperty', function()
    local propertyId = ownerTargetPropertyId()
    if not propertyId then notify('~y~You must be at or inside a property to lock its door.') return end
    local p = propertyById(propertyId)
    if not p or not p.door_id then notify('~y~This property has no registered door (install pulse_doorlocks).') return end
    TriggerServerEvent('pulse_property:toggleDoor', { propertyId = propertyId, doorId = p.door_id })
end, false)

RegisterCommand('sellproperty', function()
    local propertyId = ownerTargetPropertyId()
    if not propertyId then notify('~y~You must be at or inside a property to sell it.') return end
    local p = propertyById(propertyId)
    if not p then return end
    TriggerServerEvent('pulse_property:sell', propertyId, p.price)
end, false)

RegisterCommand('propertyaccess', function(_, args)
    local propertyId = ownerTargetPropertyId()
    if not propertyId then notify('~y~You must be at or inside a property to manage access.') return end
    if not args[1] then notify('~b~Usage: /propertyaccess <serverId>') return end
    TriggerServerEvent('pulse_property:grantAccess', { propertyId = propertyId, serverId = args[1] })
end, false)

RegisterCommand('propertyrevoke', function(_, args)
    local propertyId = ownerTargetPropertyId()
    if not propertyId then notify('~y~You must be at or inside a property to manage access.') return end
    if not args[1] then notify('~b~Usage: /propertyrevoke <serverId>') return end
    TriggerServerEvent('pulse_property:revokeAccess', { propertyId = propertyId, serverId = args[1] })
end, false)

local function aimedEntity()
    local camCoord = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local radX, radZ = math.rad(camRot.x), math.rad(camRot.z)
    local cosX = math.abs(math.cos(radX))
    local dir = vector3(-math.sin(radZ) * cosX, math.cos(radZ) * cosX, math.sin(radX))
    local dest = camCoord + dir * 10.0
    local ray = StartShapeTestRay(camCoord.x, camCoord.y, camCoord.z, dest.x, dest.y, dest.z, 16, PlayerPedId(), 0)
    local _, hit, _, _, entity = GetShapeTestResult(ray)
    if hit == 1 and entity ~= 0 then return entity end
    return nil
end

RegisterCommand('propertyadd', function(_, args)
    local shellKey = args[1]
    local price = tonumber(args[2])
    if not shellKey or not price then
        notify('~b~Usage: /propertyadd <shellKey> <price> [name...]')
        return
    end
    local label = table.concat(args, ' ', 3)
    if label == '' then label = 'Property' end
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local entity = aimedEntity()
    TriggerServerEvent('pulse_property:adminCreate', {
        shellKey = shellKey, price = price, label = label,
        x = pos.x, y = pos.y, z = pos.z, heading = GetEntityHeading(ped),
        model = entity and GetEntityModel(entity) or 0,
    })
end, false)

RegisterCommand('propertylist', function()
    TriggerServerEvent('pulse_property:adminList')
end, false)

RegisterCommand('propertyremove', function(_, args)
    if not tonumber(args[1]) then
        notify('~b~Usage: /propertyremove <id>')
        return
    end
    TriggerServerEvent('pulse_property:adminRemove', tonumber(args[1]))
end, false)
