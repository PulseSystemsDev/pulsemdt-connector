const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'pulse_property';

const listing = document.getElementById('listing');
const title = document.getElementById('title');
const price = document.getElementById('price');
const closeBtn = document.getElementById('close');
const buyBtn = document.getElementById('buyBtn');

let currentPropertyId = null;

function post(name, body) {
  return fetch(`https://${resource}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  });
}

closeBtn.addEventListener('click', () => { listing.classList.add('hidden'); post('closeListing'); });
buyBtn.addEventListener('click', () => {
  if (currentPropertyId == null) return;
  post('buyProperty', { propertyId: currentPropertyId });
  listing.classList.add('hidden');
  post('closeListing');
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !listing.classList.contains('hidden')) {
    listing.classList.add('hidden');
    post('closeListing');
  }
});

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action !== 'listing') return;
  currentPropertyId = data.propertyId;
  title.textContent = data.label || 'Property';
  price.textContent = `$${Math.round(data.price).toLocaleString()}`;
  listing.classList.remove('hidden');
});
