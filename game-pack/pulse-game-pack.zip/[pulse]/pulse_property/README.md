# pulse_property

`pulse_property` adds purchasable properties using base-game interiors or custom MLO coordinates, with owner sales and per-character guest access.

## Requirements

- `pulsemdt` with characters and economy enabled
- `pulse_doorlocks` for property door locking
- `pulse_core` recommended
- `pulse_notify` optional

## Installation

Start `pulse_doorlocks` before `pulse_property` and grant property administrators access:

```cfg
add_ace group.admin pulse.property allow
ensure pulse_doorlocks
ensure pulse_property
```

## Commands

- `/propertyadd <shellKey> <price> [name]` creates a property at the current location.
- `/leaveproperty` exits the current interior.
- `/lockproperty` toggles the current property's door.
- `/sellproperty` sells the current property.
- `/propertyaccess <serverId>` grants guest access.
- `/propertyrevoke <serverId>` revokes guest access.

Configure shell coordinates, interaction range, resale percentage, and blips in `config.lua`. Built-in shells are shared physical locations; players using the same shell are not automatically instanced from one another.
