local SHELL_BY_KEY = {}
for _, s in ipairs(Config.Shells) do SHELL_BY_KEY[s.key] = s end

local RCFG = { enabled = true, settings = {} }

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_property') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function num(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    return tonumber(v) or fallback
end
local function moduleEnabled() return RCFG.enabled ~= false end

local function notify(src, msg)
    TriggerClientEvent('pulse_property:notify', src, msg)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local function broadcastProperties(target)
    exports.pulsemdt:ApiRequest('GET', '/property', nil, function(code, res)
        if code == 200 and res then
            TriggerClientEvent('pulse_property:sync', target or -1, res.properties or {})
        end
    end)
end

RegisterNetEvent('pulse_property:requestSync', function()
    broadcastProperties(source)
end)

local function isPropertyAdmin(src)
    return IsPlayerAceAllowed(src, Config.AcePermission)
end

local function shellKeyList()
    local keys = {}
    for _, s in ipairs(Config.Shells) do keys[#keys + 1] = s.key end
    return table.concat(keys, ', ')
end

RegisterNetEvent('pulse_property:adminCreate', function(data)
    local src = source
    if not isPropertyAdmin(src) then return end
    local shell = data and SHELL_BY_KEY[data.shellKey]
    if not shell then notify(src, ('~r~Unknown shell. Options: %s'):format(shellKeyList())) return end
    local price = tonumber(data.price)
    if not price or price <= 0 then notify(src, '~r~Invalid price.') return end

    local doorId = nil
    pcall(function()
        doorId = exports.pulse_doorlocks:RegisterDoor(data.label or 'Property Door', data.model or 0, data.x, data.y, data.z, data.heading, 0)
    end)

    exports.pulsemdt:ApiRequest('POST', '/property', {
        action = 'create', label = data.label or 'Property', shellKey = data.shellKey,
        x = data.x, y = data.y, z = data.z, heading = data.heading, price = price, doorId = doorId,
    }, function(code, res)
        if code == 201 and res and res.ok then
            notify(src, ('~g~Property~s~ Listed for $%d (id %d).'):format(price, res.propertyId))
            broadcastProperties()
        else
            notify(src, '~r~Could not create that listing.')
        end
    end)
end)

RegisterNetEvent('pulse_property:adminList', function()
    local src = source
    if not isPropertyAdmin(src) then return end
    exports.pulsemdt:ApiRequest('GET', '/property', nil, function(code, res)
        if code ~= 200 or not res then notify(src, '~r~Could not load properties.') return end
        local rows = res.properties or {}
        if #rows == 0 then notify(src, '~b~Property~s~ No properties are listed.') return end
        for _, property in ipairs(rows) do
            local owner = property.char_id and ('owned by character %s'):format(property.char_id) or 'for sale'
            local propertyId = tonumber(property.id) or 0
            local price = tonumber(property.price) or 0
            TriggerClientEvent('chat:addMessage', src, {
                args = { '^3Property', ('#%d %s - $%d (%s)'):format(propertyId, tostring(property.label or 'Property'), price, owner) }
            })
        end
    end)
end)

RegisterNetEvent('pulse_property:adminRemove', function(propertyId)
    local src = source
    if not isPropertyAdmin(src) then return end
    propertyId = tonumber(propertyId)
    if not propertyId then notify(src, '~b~Usage: /propertyremove <id>') return end
    exports.pulsemdt:ApiRequest('POST', '/property', { action = 'remove', propertyId = propertyId }, function(code, res)
        if code == 200 and res and res.ok then
            if res.doorId then pcall(function() exports.pulse_doorlocks:RemoveDoor(res.doorId) end) end
            notify(src, ('~g~Property~s~ Listing #%d removed.'):format(propertyId))
            broadcastProperties()
        elseif code == 404 then
            notify(src, '~y~Property~s~ No listing has that id.')
        else
            notify(src, '~r~Could not remove that listing.')
        end
    end)
end)

RegisterNetEvent('pulse_property:buy', function(propertyId)
    local src = source
    if not moduleEnabled() then notify(src, '~y~Properties are not for sale right now.') return end
    getCharId(src, function(charId)
        if not charId then notify(src, '~r~No active character.') return end
        exports.pulsemdt:ApiRequest('POST', '/property', { action = 'buy', propertyId = propertyId, charId = charId }, function(code, res)
            if code == 200 and res and res.ok then
                notify(src, '~g~Property~s~ Purchased.')
                broadcastProperties()
            elseif code == 402 then
                notify(src, '~r~Not enough money for that.')
            else
                notify(src, '~r~That property is no longer available.')
            end
        end)
    end)
end)

RegisterNetEvent('pulse_property:sell', function(propertyId, price)
    local src = source
    getCharId(src, function(charId)
        if not charId then return end
        local creditAmount = math.floor((tonumber(price) or 0) * (num('sellReturnPercent', Config.SellReturnPercent) / 100))
        exports.pulsemdt:ApiRequest('POST', '/property', {
            action = 'sell', propertyId = propertyId, charId = charId, creditAmount = creditAmount,
        }, function(code, res)
            if code == 200 and res and res.ok then
                notify(src, ('~g~Property~s~ Sold for $%d.'):format(res.credited or creditAmount))
                broadcastProperties()
            else
                notify(src, '~r~You do not own that property.')
            end
        end)
    end)
end)

local function accessAction(src, action, propertyId, targetSrc)
    getCharId(src, function(charId)
        if not charId then return end
        if not targetSrc or not GetPlayerName(targetSrc) then notify(src, '~r~No player with that server ID.') return end
        getCharId(targetSrc, function(targetCharId)
            if not targetCharId then notify(src, '~r~That player has no active character.') return end
            exports.pulsemdt:ApiRequest('POST', '/property', {
                action = action, propertyId = propertyId, charId = charId, targetCharId = targetCharId,
            }, function(code, res)
                if code == 200 and res and res.ok then
                    if action == 'grantAccess' then
                        notify(src, ('~g~Property~s~ Access granted to %s.'):format(GetPlayerName(targetSrc)))
                        notify(targetSrc, '~g~Property~s~ You were granted access to a property.')
                    else
                        notify(src, ('~g~Property~s~ Access revoked from %s.'):format(GetPlayerName(targetSrc)))
                    end
                else
                    notify(src, '~r~That could not be done (are you the owner?).')
                end
            end)
        end)
    end)
end

RegisterNetEvent('pulse_property:grantAccess', function(data)
    accessAction(source, 'grantAccess', data.propertyId, tonumber(data.serverId))
end)

RegisterNetEvent('pulse_property:revokeAccess', function(data)
    accessAction(source, 'revokeAccess', data.propertyId, tonumber(data.serverId))
end)

RegisterNetEvent('pulse_property:requestEnter', function(propertyId)
    local src = source
    getCharId(src, function(charId)
        if not charId then notify(src, '~r~No active character.') return end
        exports.pulsemdt:ApiRequest('GET', ('/property?propertyId=%d&charId=%d'):format(propertyId, charId), nil, function(code, res)
            TriggerClientEvent('pulse_property:enterResult', src, propertyId, code == 200 and res and res.hasAccess == true)
        end)
    end)
end)

RegisterNetEvent('pulse_property:toggleDoor', function(data)
    local src = source
    local doorId = tonumber(data and data.doorId)
    if not doorId then return end
    getCharId(src, function(charId)
        if not charId then return end
        exports.pulsemdt:ApiRequest('GET', ('/property?propertyId=%d&charId=%d'):format(data.propertyId, charId), nil, function(code, res)
            if code ~= 200 or not res or not res.hasAccess then
                notify(src, '~r~You do not have access to this property.')
                return
            end
            local currentlyLocked = true
            local ok = pcall(function() currentlyLocked = exports.pulse_doorlocks:IsDoorLocked(doorId) end)
            if not ok then notify(src, '~y~Install pulse_doorlocks to lock property doors.') return end
            exports.pulse_doorlocks:SetDoorLocked(doorId, not currentlyLocked)
            notify(src, (not currentlyLocked) and '~y~Door locked.' or '~g~Door unlocked.')
        end)
    end)
end)
