local runs = {}          -- src -> active run state
local statsCache = {}    -- src -> decoded job_stats table
local characterCache = {} -- src -> active CAD character
local taxiCalls = {}
local callCooldown = {}
local npcRides = {}
local truckOffers = {}   -- src -> { contracts, expires }
local pendingRatings = {}
local adminStations = nil   -- freshest stations from /job-stations (beats RCFG until next poll)

local JOBS = { 'taxi', 'delivery', 'trucking', 'garbage' }
local ENABLED_KEY = {
    taxi = 'taxiEnabled', delivery = 'deliveryEnabled',
    trucking = 'truckingEnabled', garbage = 'garbageEnabled',
}

local RCFG = { enabled = true, settings = {} }

local function setting(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    if v == nil then return fallback end
    return v
end
local function num(key, fallback)
    return tonumber(setting(key, fallback)) or fallback
end
local function moduleEnabled(job)
    return RCFG.enabled and setting(ENABLED_KEY[job] or '', true) == true
end

local function notify(src, msg)
    TriggerClientEvent('pulse_jobs:notify', src, msg)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function resolveCharacter(src, cb)
    local ok, char = pcall(function() return exports.pulse_core:GetCharacter(src) end)
    if ok and char and char.id then
        characterCache[src] = char
        cb(char)
        return
    end
    if characterCache[src] and characterCache[src].id then
        cb(characterCache[src])
        return
    end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        if code ~= 200 or type(res) ~= 'table' or not res.activeCharId then
            cb(nil)
            return
        end
        for _, candidate in ipairs(res.characters or {}) do
            if candidate.id == res.activeCharId then
                characterCache[src] = candidate
                cb(candidate)
                return
            end
        end
        cb(nil)
    end)
end

AddEventHandler('pulse_core:characterLoaded', function(src, char)
    if src and char and char.id then characterCache[src] = char end
end)
AddEventHandler('pulse_core:characterUnloaded', function(src)
    if src then characterCache[src] = nil end
end)

-- ── Stations ────────────────────────────────────────────────────────────────
local function bayFor(st)
    local rad = math.rad(st.heading or 0.0)
    return {
        x = st.x - math.sin(rad) * Config.BayDistance,
        y = st.y + math.cos(rad) * Config.BayDistance,
        z = st.z,
        heading = st.heading or 0.0,
    }
end

local function effectiveStations()
    local byJob = {}
    for _, job in ipairs(JOBS) do byJob[job] = {} end

    local source = adminStations
    if not source then
        local raw = setting('stationsJson', '')
        if type(raw) == 'string' and raw ~= '' then
            local ok, parsed = pcall(json.decode, raw)
            if ok and type(parsed) == 'table' then source = parsed end
        end
    end
    if type(source) == 'table' then
        for _, s in ipairs(source) do
            if byJob[s.job] and tonumber(s.x) then
                byJob[s.job][#byJob[s.job] + 1] = {
                    label = tostring(s.label or 'Station'),
                    x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                    heading = tonumber(s.heading) or 0.0,
                }
            end
        end
    end
    for _, job in ipairs(JOBS) do
        if #byJob[job] == 0 then
            for _, s in ipairs(Config.Stations[job] or {}) do
                byJob[job][#byJob[job] + 1] = s
            end
        end
    end
    return byJob
end

local function broadcastStations(target)
    local byJob = effectiveStations()
    local payload = { stations = {}, blips = Config.Blips, radius = Config.StationRadius }
    for _, job in ipairs(JOBS) do
        payload.stations[job] = moduleEnabled(job) and byJob[job] or {}
    end
    TriggerClientEvent('pulse_jobs:stations', target or -1, payload)
end

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_jobs') end)
    if ok and type(c) == 'table' then
        RCFG = c
        adminStations = nil   -- dashboard is authoritative again after a poll
    end
    broadcastStations()
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

RegisterNetEvent('pulse_jobs:requestStations', function()
    local src = source
    broadcastStations(src)
    resolveCharacter(src, function() end)
end)

local function stationAt(job, idx)
    local list = effectiveStations()[job] or {}
    return list[idx]
end

local function nearStation(src, st, slack)
    if not st then return false end
    return #(GetEntityCoords(GetPlayerPed(src)) - vector3(st.x, st.y, st.z)) <= (slack or 12.0)
end

local function nearAnyStation(src, job)
    for _, st in ipairs(effectiveStations()[job] or {}) do
        if nearStation(src, st, 15.0) then return true end
    end
    return false
end

-- ── Career stats (persisted on the CAD character) ───────────────────────────
local function getStats(src)
    if statsCache[src] then return statsCache[src] end
    local stats = {}
    local char = characterCache[src]
    if char and type(char.job_stats) == 'string' and char.job_stats ~= '' then
        local ok, decoded = pcall(json.decode, char.job_stats)
        if ok and type(decoded) == 'table' then stats = decoded end
    end
    statsCache[src] = stats
    return stats
end

local function saveStats(src)
    local stats = statsCache[src]
    if not stats then return end
    local char = characterCache[src]
    if not char then return end
    local encoded = json.encode(stats)
    char.job_stats = encoded
    local discordId = getDiscordId(src)
    if discordId then
        exports.pulsemdt:ApiWrite('PATCH', '/characters/' .. char.id, {
            discordId = discordId, job_stats = encoded,
        }, nil)
    end
end

local function jobStats(src, job)
    local stats = getStats(src)
    stats[job] = stats[job] or { done = 0, earned = 0 }
    return stats[job]
end

local function tierFor(tiers, done)
    local current = tiers[1]
    local nextTier = nil
    for _, t in ipairs(tiers) do
        if done >= t.at then current = t
        elseif not nextTier then nextTier = t end
    end
    return current, nextTier
end

local TIERS = {
    taxi = Config.Taxi.tiers, delivery = Config.Delivery.tiers,
    trucking = Config.Trucking.tiers, garbage = Config.Garbage.tiers,
}

local function recordCompletion(src, job, earned)
    local tiers = TIERS[job]
    local s = jobStats(src, job)
    local before = tierFor(tiers, s.done)
    s.done = s.done + 1
    s.earned = math.floor((s.earned + earned) * 100) / 100
    local after = tierFor(tiers, s.done)
    saveStats(src)
    if after.label ~= before.label then
        notify(src, ('~g~Promotion~s~ You are now a %s: pay up %d%%.'):format(after.label, math.floor((after.mult - 1) * 100 + 0.5)))
    end
    return after
end

local function pay(src, amount, reason, cb)
    local char = characterCache[src]
    if not char or not char.id then
        if cb then cb(false, 'no_character') end
        return
    end
    exports.pulsemdt:ApiRequest('POST', '/money', {
        charId = char.id, account = 'bank', amount = amount, reason = reason,
    }, function(code, res)
        if code == 200 and res and res.ok then
            if cb then cb(true, res) end
        elseif code == 403 then
            if cb then cb(false, 'disabled') end
        elseif code == 402 then
            if cb then cb(false, 'insufficient') end
        else
            if cb then cb(false, 'error') end
        end
    end)
end

local function cancelRun(src, silent)
    if not runs[src] then return end
    runs[src] = nil
    TriggerClientEvent('pulse_jobs:cancelled', src)
    if not silent then notify(src, '~y~Job~s~ Clocked out.') end
end

local function cargoQuality(damagePct)
    local d = math.max(0, math.min(100, tonumber(damagePct) or 0))
    return 1.0 - math.min(d, 50) / 100
end

-- ── Surge pricing ───────────────────────────────────────────────────────────
local recentCallTimes = {}
local surgeUntil = 0

local function surgePct()
    if os.time() < surgeUntil then return Config.Taxi.surge.pct end
    return 0
end

local function noteCall()
    local now = os.time()
    recentCallTimes[#recentCallTimes + 1] = now
    local kept = {}
    for _, t in ipairs(recentCallTimes) do
        if now - t <= Config.Taxi.surge.windowSeconds then kept[#kept + 1] = t end
    end
    recentCallTimes = kept
    if #kept >= Config.Taxi.surge.calls then
        surgeUntil = now + Config.Taxi.surge.durationSeconds
    end
end

-- ── Rates / fares ───────────────────────────────────────────────────────────
local function taxiRates(src)
    local tier = tierFor(Config.Taxi.tiers, jobStats(src, 'taxi').done)
    return {
        base = num('taxiBaseFare', Config.Taxi.baseFare),
        perKm = num('taxiPerKm', Config.Taxi.perKm),
        waitPerMin = Config.Taxi.waitingPerMinute,
        nightPct = num('taxiNightSurchargePct', Config.Taxi.nightSurchargePct),
        nightStart = Config.Taxi.nightStart,
        nightEnd = Config.Taxi.nightEnd,
        surgePct = surgePct(),
        tier = tier.label,
        tierMult = tier.mult,
    }
end

local function computeFare(src, run)
    local rates = taxiRates(src)
    local elapsed = math.max(1, os.time() - (run.fareStart or os.time()))
    local dist = math.min(tonumber(run.meter and run.meter.dist) or 0, elapsed * 50)
    local wait = math.min(tonumber(run.meter and run.meter.wait) or 0, elapsed)
    local km = dist / 1000.0
    local fare = rates.base + rates.perKm * km + rates.waitPerMin * (wait / 60.0)
    if run.meter and run.meter.night then
        fare = fare * (1 + rates.nightPct / 100)
    end
    if (run.surgePct or 0) > 0 then
        fare = fare * (1 + run.surgePct / 100)
    end
    return math.floor(fare * rates.tierMult + 0.5), km
end

-- ── Station UI: info + clock in/out ─────────────────────────────────────────
local function rollCargoClass(done)
    local pool = {}
    for _, c in ipairs(Config.Trucking.cargoClasses) do
        if done >= (c.minDone or 0) then
            for _ = 1, c.weight do pool[#pool + 1] = c end
        end
    end
    return pool[math.random(#pool)]
end

local function pickLegs()
    local count = math.random(Config.Trucking.minLegs, Config.Trucking.maxLegs)
    local pool = {}
    for i in ipairs(Config.Trucking.destinations) do pool[#pool + 1] = i end
    local legs = {}
    for _ = 1, count do
        if #pool == 0 then break end
        legs[#legs + 1] = Config.Trucking.destinations[table.remove(pool, math.random(#pool))]
    end
    return legs
end

RegisterNetEvent('pulse_jobs:stationInfo', function(data)
    local src = source
    local job = data and data.job
    local idx = data and tonumber(data.station)
    local st = job and idx and stationAt(job, idx)
    if not st or not nearStation(src, st) then return end

    local payload = {
        job = job, station = idx, stationLabel = st.label,
        description = Config.Descriptions[job] or '',
        enabled = moduleEnabled(job),
        onDuty = runs[src] ~= nil and runs[src].job == job,
        otherDuty = runs[src] ~= nil and runs[src].job ~= job and runs[src].job or nil,
    }

    local s = jobStats(src, job)
    local tier, nextTier = tierFor(TIERS[job], s.done)
    payload.career = {
        tier = tier.label, done = s.done, earned = s.earned or 0,
        bonusPct = math.floor((tier.mult - 1) * 100 + 0.5),
        nextLabel = nextTier and nextTier.label or nil,
        nextAt = nextTier and nextTier.at or nil,
    }

    if job == 'taxi' then
        local r = taxiRates(src)
        payload.rates = {
            { k = 'Base fare', v = ('$%d'):format(r.base) },
            { k = 'Per km', v = ('$%d'):format(r.perKm) },
            { k = 'Waiting', v = ('$%d/min'):format(r.waitPerMin) },
            { k = 'Night tariff', v = ('+%d%%'):format(r.nightPct) },
        }
        if r.surgePct > 0 then
            payload.rates[#payload.rates + 1] = { k = 'Surge active', v = ('+%d%%'):format(r.surgePct), accent = true }
        end
    elseif job == 'delivery' then
        payload.rates = {
            { k = 'Per stop', v = ('$%d'):format(num('payPerStop', Config.Delivery.payPerStop)) },
            { k = 'Streak bonus', v = ('+%d%%/stop'):format(num('deliveryStreakStepPct', Config.Delivery.streakStepPct)) },
        }
        payload.lengths = {
            { id = 'short', label = 'Short route', detail = ('%d stops'):format(Config.Delivery.runLengths.short) },
            { id = 'standard', label = 'Standard route', detail = ('%d stops'):format(num('stopsPerRun', Config.Delivery.stopsPerRun)) },
            { id = 'long', label = 'Long route', detail = ('%d stops'):format(Config.Delivery.runLengths.long) },
        }
    elseif job == 'trucking' then
        payload.rates = {
            { k = 'Per leg', v = ('$%d'):format(num('truckingPay', Config.Trucking.payPerHaul)) },
            { k = 'Chain bonus', v = ('+%d%%'):format(num('truckingChainBonusPct', Config.Trucking.chainBonusPct)) },
        }
        if not payload.onDuty and payload.enabled then
            local basePay = num('truckingPay', Config.Trucking.payPerHaul)
            local chainPct = num('truckingChainBonusPct', Config.Trucking.chainBonusPct)
            local display, internal = {}, {}
            for i = 1, Config.Trucking.offers do
                local legs = pickLegs()
                local class = rollCargoClass(s.done)
                local est = math.floor(#legs * basePay * class.payMult * tier.mult * (#legs > 1 and (1 + chainPct / 100) or 1) + 0.5)
                local names = {}
                for _, leg in ipairs(legs) do names[#names + 1] = leg.label end
                display[i] = {
                    id = i, class = class.label, hazmat = class.maxDamagePct ~= nil,
                    legs = #legs, route = table.concat(names, ' > '), est = est,
                }
                internal[i] = { legs = legs, class = class }
            end
            truckOffers[src] = { contracts = internal, expires = os.time() + Config.Trucking.offerSeconds }
            payload.contracts = display
        end
    elseif job == 'garbage' then
        payload.rates = {
            { k = 'Per bag', v = ('$%d'):format(num('garbagePayPerBag', Config.Garbage.payPerBag)) },
            { k = 'Route bonus', v = ('$%d'):format(num('garbageRouteBonus', Config.Garbage.routeBonus)) },
            { k = 'Bags per route', v = ('%d'):format(num('garbageBagsPerRoute', Config.Garbage.bagsPerRoute)) },
        }
    end

    TriggerClientEvent('pulse_jobs:stationInfoResult', src, payload)
end)

-- ── Clock in / clock out ────────────────────────────────────────────────────
local function rollPackageType()
    local pool = {}
    for _, t in ipairs(Config.Delivery.packageTypes) do
        for _ = 1, t.weight do pool[#pool + 1] = t end
    end
    return pool[math.random(#pool)]
end

local function startDelivery(src, bay, length)
    local count = Config.Delivery.runLengths[length] or num('stopsPerRun', Config.Delivery.stopsPerRun)
    count = math.min(count, #Config.Delivery.stops)
    local pool = {}
    for i in ipairs(Config.Delivery.stops) do pool[#pool + 1] = i end
    local stops, types = {}, {}
    for _ = 1, math.max(1, count) do
        if #pool == 0 then break end
        stops[#stops + 1] = Config.Delivery.stops[table.remove(pool, math.random(#pool))]
        types[#types + 1] = rollPackageType()
    end

    local tier = tierFor(Config.Delivery.tiers, jobStats(src, 'delivery').done)
    runs[src] = { job = 'delivery', stops = stops, types = types, current = 1, streak = 0, lastStopAt = os.time() }
    local typeLabels = {}
    for i, t in ipairs(types) do typeLabels[i] = t.label end
    TriggerClientEvent('pulse_jobs:beginDelivery', src, {
        stops = stops, types = typeLabels, bay = bay,
        vehicle = Config.Delivery.vehicle,
        pay = num('payPerStop', Config.Delivery.payPerStop),
        handoverSeconds = Config.Delivery.handoverSeconds,
        tier = tier.label,
    })
end

local function startTaxi(src, bay)
    runs[src] = { job = 'taxi' }
    TriggerClientEvent('pulse_jobs:beginTaxi', src, {
        bay = bay,
        vehicle = Config.Taxi.vehicle,
        anyVehicle = Config.Taxi.anyVehicle,
        rates = taxiRates(src),
    })
end

local function startTrucking(src, bay, pick)
    local offer = truckOffers[src]
    if not offer or os.time() > offer.expires then
        truckOffers[src] = nil
        notify(src, '~y~Trucking~s~ Those contracts expired; open the board again.')
        return
    end
    local contract = offer.contracts[tonumber(pick) or -1]
    if not contract then return end
    truckOffers[src] = nil

    local tier = tierFor(Config.Trucking.tiers, jobStats(src, 'trucking').done)
    runs[src] = { job = 'trucking', legs = contract.legs, leg = 1, legPay = {}, class = contract.class }
    TriggerClientEvent('pulse_jobs:beginTrucking', src, {
        bay = bay,
        vehicle = Config.Trucking.vehicle,
        legs = contract.legs,
        pay = num('truckingPay', Config.Trucking.payPerHaul),
        chainBonusPct = num('truckingChainBonusPct', Config.Trucking.chainBonusPct),
        cargoClass = contract.class.label,
        hazmat = contract.class.maxDamagePct ~= nil,
        tier = tier.label,
    })
end

local function startGarbage(src, bay, stationIdx)
    local count = math.min(num('garbageBagsPerRoute', Config.Garbage.bagsPerRoute), #Config.Garbage.points)
    local pool = {}
    for i in ipairs(Config.Garbage.points) do pool[#pool + 1] = i end
    local points = {}
    for _ = 1, math.max(1, count) do
        if #pool == 0 then break end
        points[#points + 1] = Config.Garbage.points[table.remove(pool, math.random(#pool))]
    end

    local tier = tierFor(Config.Garbage.tiers, jobStats(src, 'garbage').done)
    runs[src] = { job = 'garbage', points = points, idx = 1, station = stationIdx }
    TriggerClientEvent('pulse_jobs:beginGarbage', src, {
        bay = bay,
        vehicle = Config.Garbage.vehicle,
        points = points,
        pay = num('garbagePayPerBag', Config.Garbage.payPerBag),
        bonus = num('garbageRouteBonus', Config.Garbage.routeBonus),
        bagProp = Config.Garbage.bagProp,
        tier = tier.label,
    })
end

RegisterNetEvent('pulse_jobs:clockIn', function(data)
    local src = source
    local job = data and data.job
    if not ENABLED_KEY[job] then return end
    if not moduleEnabled(job) then
        notify(src, '~y~Job~s~ That job is disabled on this server.')
        return
    end
    if runs[src] then
        notify(src, '~y~Job~s~ Clock out of your current job first.')
        return
    end
    resolveCharacter(src, function(char)
        if not char then
            notify(src, '~r~Job~s~ Load or select a character first.')
            return
        end
        if runs[src] then return end

        local bay
        local idx = tonumber(data.station)
        if idx then
            local st = stationAt(job, idx)
            if not st or not nearStation(src, st) then return end
            bay = bayFor(st)
        elseif Config.AllowCommands then
            local pos = GetEntityCoords(GetPlayerPed(src))
            bay = { x = pos.x + 3.0, y = pos.y + 3.0, z = pos.z, heading = 0.0 }
        else
            return
        end

        if job == 'delivery' then startDelivery(src, bay, data.opt)
        elseif job == 'taxi' then startTaxi(src, bay)
        elseif job == 'trucking' then startTrucking(src, bay, data.opt)
        elseif job == 'garbage' then startGarbage(src, bay, idx) end
    end)
end)

RegisterNetEvent('pulse_jobs:clockOut', function()
    local src = source
    local run = runs[src]
    if not run then return end
    if not nearAnyStation(src, run.job) and not Config.AllowCommands then
        notify(src, '~y~Job~s~ Clock out at a job station.')
        return
    end
    cancelRun(src)
end)

-- ── Delivery ────────────────────────────────────────────────────────────────
RegisterNetEvent('pulse_jobs:stopReached', function(data)
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'delivery' or not moduleEnabled('delivery') then return end

    local stop = run.stops[run.current]
    if not stop then return end
    if #(GetEntityCoords(GetPlayerPed(src)) - vector3(stop.x, stop.y, stop.z)) > (Config.Delivery.stopRadius + 8.0) then return end

    local pkg = (run.types and run.types[run.current]) or Config.Delivery.packageTypes[1]
    local now = os.time()
    local onTime = (now - run.lastStopAt) <= math.floor(Config.Delivery.onTimeSeconds * (pkg.timeMult or 1.0))
    run.streak = onTime and (run.streak + 1) or 0
    run.lastStopAt = now

    local stepPct = num('deliveryStreakStepPct', Config.Delivery.streakStepPct)
    local bonusPct = math.min(run.streak, Config.Delivery.streakCap) * stepPct
    local tier = tierFor(Config.Delivery.tiers, jobStats(src, 'delivery').done)
    local rawDamage = math.max(0, math.min(100, tonumber(data and data.damagePct) or 0))
    local quality = cargoQuality(rawDamage * (pkg.damageMult or 1.0))

    local amount = math.floor(num('payPerStop', Config.Delivery.payPerStop) * (pkg.payMult or 1.0) * tier.mult * (1 + bonusPct / 100) * quality + 0.5)

    pay(src, amount, 'Delivery job', function(paid, err)
        if paid then
            local extra = bonusPct > 0 and (' (+%d%% streak)'):format(bonusPct) or ''
            notify(src, ('~g~Delivery~s~ %s package delivered: +$%d%s.'):format(pkg.label, amount, extra))
        elseif err == 'disabled' then
            notify(src, '~y~Delivery~s~ Package delivered (the economy is off, no pay).')
        end
    end)
    recordCompletion(src, 'delivery', amount)

    run.current = run.current + 1
    if run.current > #run.stops then
        local total = #run.stops
        runs[src] = nil
        TriggerClientEvent('pulse_jobs:finished', src)
        notify(src, ('~g~Delivery~s~ Run complete: %d stops.'):format(total))
    else
        TriggerClientEvent('pulse_jobs:nextStop', src, { index = run.current, streak = math.min(run.streak, Config.Delivery.streakCap) * stepPct })
    end
end)

-- ── Taxi ────────────────────────────────────────────────────────────────────
local function newFare(src)
    local run = runs[src]
    if not run or run.job ~= 'taxi' then return end
    local n = #Config.Taxi.points
    local pickupIdx = math.random(n)
    local dropIdx = pickupIdx
    while dropIdx == pickupIdx do dropIdx = math.random(n) end
    run.mode = 'npc'
    run.pickup = pickupIdx
    run.drop = dropIdx
    run.stage = 'pickup'
    run.surgePct = surgePct()
    run.meter = { dist = 0, wait = 0, night = false }
    TriggerClientEvent('pulse_jobs:taxiFare', src, {
        pickup = Config.Taxi.points[pickupIdx],
        drop = Config.Taxi.points[dropIdx],
        surgePct = run.surgePct,
    })
end

RegisterNetEvent('pulse_jobs:taxiReady', function()
    local src = source
    local run = runs[src]
    if run and run.job == 'taxi' and not run.stage then
        newFare(src)
    end
end)

RegisterNetEvent('pulse_jobs:taxiPickedUp', function()
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'taxi' or run.stage ~= 'pickup' or run.mode ~= 'npc' then return end
    local p = Config.Taxi.points[run.pickup]
    if #(GetEntityCoords(GetPlayerPed(src)) - vector3(p.x, p.y, p.z)) > (Config.Taxi.pickupRadius + 12.0) then return end
    run.stage = 'drive'
    run.fareStart = os.time()
    run.meter = { dist = 0, wait = 0, night = false }
end)

RegisterNetEvent('pulse_jobs:meterTick', function(data)
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'taxi' or run.stage ~= 'drive' or type(data) ~= 'table' then return end
    run.meter = {
        dist = tonumber(data.dist) or 0,
        wait = tonumber(data.wait) or 0,
        night = data.night == true,
    }
end)

RegisterNetEvent('pulse_jobs:taxiDropped', function(data)
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'taxi' or run.stage ~= 'drive' or run.mode ~= 'npc' or not moduleEnabled('taxi') then return end
    local d = Config.Taxi.points[run.drop]
    if #(GetEntityCoords(GetPlayerPed(src)) - vector3(d.x, d.y, d.z)) > (Config.Taxi.dropRadius + 12.0) then return end

    local fare, km = computeFare(src, run)
    local maxTip = num('taxiMaxTipPct', Config.Taxi.maxTipPct)
    local damage = math.max(0, math.min(100, tonumber(data and data.damagePct) or 0))
    local tipFactor = math.max(0, 1 - damage / 25)
    local tip = math.floor(fare * (maxTip / 100) * tipFactor + 0.5)
    local total = fare + tip

    pay(src, total, 'Taxi fare', function(paid, err)
        if paid then
            if tip > 0 then
                notify(src, ('~g~Taxi~s~ Fare $%d + $%d tip (%.1f km).'):format(fare, tip, km))
            else
                notify(src, ('~g~Taxi~s~ Fare $%d (%.1f km). No tip for the rough ride.'):format(fare, km))
            end
        elseif err == 'disabled' then
            notify(src, '~y~Taxi~s~ Fare complete (the economy is off, no pay).')
        end
    end)
    run.shiftEarned = (run.shiftEarned or 0) + total
    TriggerClientEvent('pulse_jobs:taxiPaid', src, { amount = total, shiftTotal = run.shiftEarned })
    recordCompletion(src, 'taxi', total)
    newFare(src)
end)

RegisterNetEvent('pulse_jobs:taxiCall', function(data)
    local src = source
    if not moduleEnabled('taxi') then
        notify(src, '~y~Taxi~s~ No taxi service on this server.')
        return
    end
    resolveCharacter(src, function(char)
        if not char then
            notify(src, '~r~Taxi~s~ Load or select a character first.')
            return
        end
        local now = os.time()
        if callCooldown[src] and (now - callCooldown[src]) < Config.Taxi.callCooldownSeconds then
            notify(src, '~y~Taxi~s~ You already called; give the driver a minute.')
            return
        end
        noteCall()

        local quote = nil
        if data and tonumber(data.dx) then
            local from = GetEntityCoords(GetPlayerPed(src))
            local km = #(from - vector3(tonumber(data.dx), tonumber(data.dy) or 0.0, tonumber(data.dz) or from.z)) / 1000.0
            local est = num('taxiBaseFare', Config.Taxi.baseFare) + num('taxiPerKm', Config.Taxi.perKm) * km
            if surgePct() > 0 then est = est * (1 + surgePct() / 100) end
            quote = math.floor(est + 0.5)
        end

        local drivers = {}
        for driverSrc, run in pairs(runs) do
            if run.job == 'taxi' and driverSrc ~= src then drivers[#drivers + 1] = driverSrc end
        end
        if #drivers == 0 then
            if Config.Taxi.npcService.enabled and setting('taxiNpcService', true) == true then
                callCooldown[src] = now
                npcRides[src] = { start = now, surgePct = surgePct(), meter = { dist = 0, wait = 0, night = false } }
                TriggerClientEvent('pulse_jobs:npcCab', src, {
                    vehicle = Config.Taxi.npcService.vehicle,
                    driverModel = Config.Taxi.npcService.driverModel,
                    waitSeconds = Config.Taxi.npcService.waitForPickupSeconds,
                    arriveRadius = Config.Taxi.npcService.arriveRadius,
                    rates = {
                        base = num('taxiBaseFare', Config.Taxi.baseFare),
                        perKm = num('taxiPerKm', Config.Taxi.perKm),
                        waitPerMin = Config.Taxi.waitingPerMinute,
                        nightPct = num('taxiNightSurchargePct', Config.Taxi.nightSurchargePct),
                        nightStart = Config.Taxi.nightStart,
                        nightEnd = Config.Taxi.nightEnd,
                        surgePct = surgePct(),
                        tierMult = 1.0,
                    },
                })
                notify(src, '~b~Taxi~s~ No drivers on shift; an AI cab is on the way. Set a waypoint for your destination.')
            else
                notify(src, '~y~Taxi~s~ No drivers are on shift right now.')
            end
            return
        end

        callCooldown[src] = now
        local pos = GetEntityCoords(GetPlayerPed(src))
        taxiCalls[src] = { x = pos.x, y = pos.y, z = pos.z, at = now, quote = quote }
        local quoteText = quote and (' Estimated fare: $%d.'):format(quote) or ''
        notify(src, ('~b~Taxi~s~ Cab requested. %d driver(s) notified.%s'):format(#drivers, quoteText))
        for _, driverSrc in ipairs(drivers) do
            TriggerClientEvent('pulse_jobs:taxiCallPing', driverSrc, {
                x = pos.x, y = pos.y, z = pos.z,
                expire = Config.Taxi.callExpireSeconds,
            })
            local driverQuote = quote and (' Est. $%d fare.'):format(quote) or ''
            notify(driverSrc, ('~b~Taxi~s~ A customer is calling for a cab.%s Check your map.'):format(driverQuote))
        end
    end)
end)

RegisterNetEvent('pulse_jobs:rateDriver', function(stars)
    local paxSrc = source
    local pending = pendingRatings[paxSrc]
    if not pending or os.time() > pending.expires then
        pendingRatings[paxSrc] = nil
        return
    end
    stars = math.floor(tonumber(stars) or 0)
    if stars < 1 or stars > 5 then return end
    pendingRatings[paxSrc] = nil

    local driverSrc = pending.driver
    if not GetPlayerName(driverSrc) then return end
    local s = jobStats(driverSrc, 'taxi')
    s.ratingSum = (s.ratingSum or 0) + stars
    s.ratingCount = (s.ratingCount or 0) + 1
    saveStats(driverSrc)
    local avg = s.ratingSum / s.ratingCount
    notify(driverSrc, ('~b~Taxi~s~ Your passenger rated you %d star%s (avg %.1f).'):format(stars, stars == 1 and '' or 's', avg))
    notify(paxSrc, '~g~Taxi~s~ Thanks for the rating.')
end)

RegisterNetEvent('pulse_jobs:paxEntered', function(data)
    local paxSrc = source
    local driverSrc = tonumber(data and data.driver)
    if not driverSrc or paxSrc == driverSrc then return end
    local run = runs[driverSrc]
    if not run or run.job ~= 'taxi' then return end
    if run.mode == 'player' and run.stage == 'drive' then return end
    resolveCharacter(paxSrc, function(char)
        if not char then
            notify(paxSrc, '~r~Taxi~s~ Load or select a character before taking a paid ride.')
            return
        end
        run = runs[driverSrc]
        if not run or run.job ~= 'taxi' or (run.mode == 'player' and run.stage == 'drive') then return end
        run.mode = 'player'
        run.stage = 'drive'
        run.pax = paxSrc
        run.fareStart = os.time()
        run.surgePct = surgePct()
        run.meter = { dist = 0, wait = 0, night = false }
        taxiCalls[paxSrc] = nil
        TriggerClientEvent('pulse_jobs:playerFareStarted', driverSrc, { passenger = GetPlayerName(paxSrc), surgePct = run.surgePct })
        notify(paxSrc, '~b~Taxi~s~ Meter running. Pay is charged when you leave the cab.')
    end)
end)

RegisterNetEvent('pulse_jobs:paxExited', function(data)
    local paxSrc = source
    local driverSrc = tonumber(data and data.driver)
    if not driverSrc then return end
    local run = runs[driverSrc]
    if not run or run.job ~= 'taxi' or run.mode ~= 'player' or run.pax ~= paxSrc then return end

    local fare = computeFare(driverSrc, run)
    local cut = num('taxiCompanyCutPct', Config.Taxi.companyCutPct)
    local driverShare = math.floor(fare * (1 - cut / 100) + 0.5)

    local paxCharId = characterCache[paxSrc] and characterCache[paxSrc].id or nil

    local function settle(charged)
        if charged then
            pay(driverSrc, driverShare, 'Taxi fare', nil)
            notify(driverSrc, ('~g~Taxi~s~ Passenger paid $%d; your share is $%d.'):format(fare, driverShare))
            notify(paxSrc, ('~b~Taxi~s~ Ride charged: $%d.'):format(fare))
            run.shiftEarned = (run.shiftEarned or 0) + driverShare
            TriggerClientEvent('pulse_jobs:taxiPaid', driverSrc, { amount = driverShare, shiftTotal = run.shiftEarned })
            recordCompletion(driverSrc, 'taxi', driverShare)
            pendingRatings[paxSrc] = { driver = driverSrc, expires = os.time() + 120 }
            notify(paxSrc, '~b~Taxi~s~ Rate your driver with /rate 1 to 5.')
        else
            notify(driverSrc, '~r~Taxi~s~ The passenger could not pay the fare.')
            notify(paxSrc, '~r~Taxi~s~ You could not afford the fare.')
        end
        TriggerClientEvent('pulse_jobs:playerFareEnded', driverSrc, {})
        newFare(driverSrc)
    end

    if not paxCharId or fare <= 0 then
        settle(false)
        return
    end
    local ok = pcall(function()
        exports.pulsemdt:ApiRequest('POST', '/money', {
            charId = paxCharId, account = 'bank', amount = -fare,
            reason = 'Taxi ride',
        }, function(code, res)
            if code == 200 and res and res.ok then settle(true)
            elseif code == 403 then settle(true)
            else settle(false) end
        end)
    end)
    if not ok then settle(false) end
end)

-- ── AI cab rides (passenger side) ───────────────────────────────────────────
RegisterNetEvent('pulse_jobs:npcRideTick', function(data)
    local src = source
    local ride = npcRides[src]
    if not ride or type(data) ~= 'table' then return end
    ride.meter = {
        dist = tonumber(data.dist) or 0,
        wait = tonumber(data.wait) or 0,
        night = data.night == true,
    }
end)

RegisterNetEvent('pulse_jobs:npcRideCancel', function()
    npcRides[source] = nil
end)

RegisterNetEvent('pulse_jobs:npcRideEnd', function()
    local src = source
    local ride = npcRides[src]
    if not ride then return end
    npcRides[src] = nil

    local elapsed = math.max(1, os.time() - ride.start)
    local dist = math.min(tonumber(ride.meter.dist) or 0, elapsed * 50)
    local wait = math.min(tonumber(ride.meter.wait) or 0, elapsed)
    local km = dist / 1000.0
    local fare = num('taxiBaseFare', Config.Taxi.baseFare)
        + num('taxiPerKm', Config.Taxi.perKm) * km
        + Config.Taxi.waitingPerMinute * (wait / 60.0)
    if ride.meter.night then
        fare = fare * (1 + num('taxiNightSurchargePct', Config.Taxi.nightSurchargePct) / 100)
    end
    if (ride.surgePct or 0) > 0 then
        fare = fare * (1 + ride.surgePct / 100)
    end
    fare = math.floor(fare + 0.5)
    if fare <= 0 then return end

    local paxCharId = characterCache[src] and characterCache[src].id or nil
    if not paxCharId then return end

    pcall(function()
        exports.pulsemdt:ApiRequest('POST', '/money', {
            charId = paxCharId, account = 'bank', amount = -fare,
            reason = 'Taxi ride',
        }, function(code, res)
            if code == 200 and res and res.ok then
                notify(src, ('~b~Taxi~s~ Ride charged: $%d (%.1f km).'):format(fare, km))
            elseif code == 402 then
                notify(src, ('~r~Taxi~s~ You could not afford the $%d fare. The company will remember.'):format(fare))
            end
        end)
    end)
end)

-- ── Trucking ────────────────────────────────────────────────────────────────
RegisterNetEvent('pulse_jobs:haulDelivered', function(data)
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'trucking' or not moduleEnabled('trucking') then return end
    local d = run.legs[run.leg]
    if not d then return end
    if #(GetEntityCoords(GetPlayerPed(src)) - vector3(d.x, d.y, d.z)) > (Config.Trucking.dropRadius + 10.0) then return end

    local tier = tierFor(Config.Trucking.tiers, jobStats(src, 'trucking').done)
    local class = run.class or Config.Trucking.cargoClasses[1]
    local rawDamage = math.max(0, math.min(100, tonumber(data and data.damagePct) or 0))
    local amount
    if class.maxDamagePct and rawDamage > class.maxDamagePct then
        amount = 0
        notify(src, ('~r~Trucking~s~ %s cargo compromised (%.0f%% damage): leg voided.'):format(class.label, rawDamage))
    else
        amount = math.floor(num('truckingPay', Config.Trucking.payPerHaul) * (class.payMult or 1.0) * tier.mult * cargoQuality(rawDamage) + 0.5)
    end
    run.legPay[#run.legPay + 1] = amount

    if amount > 0 then
        pay(src, amount, 'Trucking haul', function(paid, err)
            if paid then
                notify(src, ('~g~Trucking~s~ %s cargo unloaded at %s: +$%d.'):format(class.label, d.label or 'destination', amount))
            elseif err == 'disabled' then
                notify(src, '~y~Trucking~s~ Cargo unloaded (the economy is off, no pay).')
            end
        end)
    end
    recordCompletion(src, 'trucking', amount)

    run.leg = run.leg + 1
    if run.leg > #run.legs then
        local chainPct = num('truckingChainBonusPct', Config.Trucking.chainBonusPct)
        if #run.legs > 1 and chainPct > 0 then
            local total = 0
            for _, p in ipairs(run.legPay) do total = total + p end
            local bonus = math.floor(total * chainPct / 100 + 0.5)
            if bonus > 0 then
                pay(src, bonus, 'Trucking chain bonus', nil)
                notify(src, ('~g~Trucking~s~ Full chain complete: +$%d bonus.'):format(bonus))
            end
        end
        runs[src] = nil
        TriggerClientEvent('pulse_jobs:finished', src)
    else
        TriggerClientEvent('pulse_jobs:nextLeg', src, { index = run.leg, dest = run.legs[run.leg] })
    end
end)

-- ── Garbage ─────────────────────────────────────────────────────────────────
RegisterNetEvent('pulse_jobs:bagCollected', function()
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'garbage' or not moduleEnabled('garbage') then return end
    local point = run.points[run.idx]
    if not point then return end
    if #(GetEntityCoords(GetPlayerPed(src)) - vector3(point.x, point.y, point.z)) > (Config.Garbage.pointRadius + 8.0) then return end

    local tier = tierFor(Config.Garbage.tiers, jobStats(src, 'garbage').done)
    local amount = math.floor(num('garbagePayPerBag', Config.Garbage.payPerBag) * tier.mult + 0.5)
    pay(src, amount, 'Garbage route', function(paid, err)
        if paid then
            notify(src, ('~g~Garbage~s~ Bag loaded: +$%d.'):format(amount))
        elseif err == 'disabled' then
            notify(src, '~y~Garbage~s~ Bag loaded (the economy is off, no pay).')
        end
    end)
    recordCompletion(src, 'garbage', amount)

    run.idx = run.idx + 1
    if run.idx > #run.points then
        run.phase = 'return'
        TriggerClientEvent('pulse_jobs:garbageReturnPhase', src, { station = run.station })
        notify(src, '~b~Garbage~s~ Route done. Return the truck to the depot for your bonus.')
    else
        TriggerClientEvent('pulse_jobs:nextBag', src, { index = run.idx })
    end
end)

RegisterNetEvent('pulse_jobs:garbageReturn', function()
    local src = source
    local run = runs[src]
    if not run or run.job ~= 'garbage' or run.phase ~= 'return' then return end
    if not nearAnyStation(src, 'garbage') then return end

    local tier = tierFor(Config.Garbage.tiers, jobStats(src, 'garbage').done)
    local bonus = math.floor(num('garbageRouteBonus', Config.Garbage.routeBonus) * tier.mult + 0.5)
    if bonus > 0 then
        pay(src, bonus, 'Garbage route bonus', nil)
        notify(src, ('~g~Garbage~s~ Truck returned: +$%d route bonus.'):format(bonus))
    end
    runs[src] = nil
    TriggerClientEvent('pulse_jobs:finished', src)
end)

-- ── In-game station admin (/jobstation) ─────────────────────────────────────
RegisterNetEvent('pulse_jobs:adminStation', function(data)
    local src = source
    if not IsPlayerAceAllowed(src, 'pulse.jobs') then
        notify(src, '~r~Jobs~s~ You lack the pulse.jobs permission.')
        return
    end
    local action = data and data.action
    local body = {
        action = action,
        job = data.job,
        label = data.label,
        x = data.x, y = data.y, z = data.z, heading = data.heading,
    }
    local ok = pcall(function()
        exports.pulsemdt:ApiRequest('POST', '/job-stations', body, function(code, res)
            if code == 200 and res and res.stations then
                adminStations = res.stations
                broadcastStations()
                if action == 'add' then
                    notify(src, ('~g~Jobs~s~ Station "%s" added for %s.'):format(data.label or 'Station', data.job))
                elseif action == 'remove' then
                    notify(src, '~g~Jobs~s~ Station removed.')
                elseif action == 'list' then
                    if #res.stations == 0 then
                        notify(src, '~b~Jobs~s~ No dashboard-managed stations; defaults are in use.')
                    end
                    for _, s in ipairs(res.stations) do
                        TriggerClientEvent('chat:addMessage', src, {
                            args = { '^3Jobs', ('%s: %s (%.0f, %.0f)'):format(s.job, s.label, s.x, s.y) }
                        })
                    end
                end
            elseif code == 0 then
                notify(src, '~r~Jobs~s~ The CAD is offline; try again later.')
            else
                notify(src, '~r~Jobs~s~ ' .. ((res and res.error) or 'Station change failed.'))
            end
        end)
    end)
    if not ok then
        notify(src, '~r~Jobs~s~ Station management is unavailable right now.')
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    runs[src] = nil
    statsCache[src] = nil
    characterCache[src] = nil
    taxiCalls[src] = nil
    callCooldown[src] = nil
    npcRides[src] = nil
    truckOffers[src] = nil
    pendingRatings[src] = nil
end)
