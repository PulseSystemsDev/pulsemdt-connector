-- PulseMDT :: pulse_jobs (Civilian career jobs)
--
-- Four career jobs: delivery, taxi, trucking, and garbage. Shifts start and
-- end at physical JOB STATIONS on the map (marker + prompt + station UI), the
-- QBCore way; there are no job commands unless AllowCommands is enabled.
-- Clocking in spawns the job vehicle at the station's bay; the worker walks
-- over and gets in, and only they can drive it.
--
-- Stations below are the defaults. Server owners can replace them per job
-- from the dashboard (Scripts page, "Job stations") or in-game with
-- /jobstation add|remove|list (requires ace: add_ace group.admin pulse.jobs allow).
--
-- All pay flows through the CAD economy and every completed run updates the
-- character's career stats in the CAD.

Config = {}

-- Legacy command fallback (/taxi, /delivery, /trucking, /garbage). Stations
-- are the intended flow; leave this off unless you want both.
Config.AllowCommands = false

-- Marker/prompt radius at stations.
Config.StationRadius = 2.5

-- The vehicle bay is projected this many metres in front of the station
-- point along its heading.
Config.BayDistance = 7.0

-- Map blips per job (shown for every station of an enabled job).
Config.Blips = {
    taxi     = { sprite = 198, color = 5,  label = 'Taxi Depot' },
    delivery = { sprite = 478, color = 5,  label = 'Courier Depot' },
    trucking = { sprite = 477, color = 5,  label = 'Freight Yard' },
    garbage  = { sprite = 318, color = 25, label = 'Sanitation Depot' },
}

-- Default stations (replaced per job by dashboard stations when any exist).
Config.Stations = {
    taxi = {
        { label = 'Downtown Cab Co.',   x = 909.6,  y = -177.4,  z = 74.2, heading = 238.0 },
    },
    delivery = {
        { label = 'La Mesa Depot',      x = 77.4,   y = 112.6,   z = 81.2, heading = 340.0 },
    },
    trucking = {
        { label = 'La Mesa Freight',    x = 899.5,  y = -1442.5, z = 25.4, heading = 90.0 },
    },
    garbage = {
        { label = 'Rancho Sanitation',  x = -322.3, y = -1545.1, z = 31.0, heading = 265.0 },
    },
}

-- Shown in the station UI.
Config.Descriptions = {
    taxi     = 'Drive NPC fares and player calls. The meter charges per km with night and surge pricing; smooth driving earns tips.',
    delivery = 'Run package routes. On-time stops build a streak bonus; priority and fragile packages pay more.',
    trucking = 'Pick a contract from the board and haul cargo between depots. Hazmat pays big but hates dents.',
    garbage  = 'Work a collection route: load the bags, return the truck to the depot for the route bonus.',
}

-- ── Delivery ────────────────────────────────────────────────────────────────
Config.Delivery = {
    vehicle = 'boxville2',
    payPerStop = 45,
    stopsPerRun = 5,
    stopRadius = 6.0,
    onTimeSeconds = 240,
    streakStepPct = 5,
    streakCap = 5,
    handoverSeconds = 3,
    runLengths = { short = 3, long = 8 },
    packageTypes = {
        { id = 'standard', label = 'Standard', weight = 6, payMult = 1.0,  timeMult = 1.0, damageMult = 1.0 },
        { id = 'priority', label = 'Priority', weight = 3, payMult = 1.4,  timeMult = 0.6, damageMult = 1.0 },
        { id = 'fragile',  label = 'Fragile',  weight = 2, payMult = 1.25, timeMult = 1.0, damageMult = 2.0 },
    },
    tiers = {
        { label = 'Runner',  at = 0,  mult = 1.0 },
        { label = 'Courier', at = 15, mult = 1.1 },
        { label = 'Express', at = 40, mult = 1.2 },
        { label = 'Prime',   at = 80, mult = 1.3 },
    },
    stops = {
        { x = 25.9,    y = -1347.3, z = 29.5 },
        { x = 373.5,   y = 325.6,   z = 103.6 },
        { x = -47.5,   y = -1757.5, z = 29.4 },
        { x = 1163.4,  y = -323.8,  z = 69.2 },
        { x = -706.2,  y = -914.2,  z = 19.2 },
        { x = -1487.6, y = -379.1,  z = 40.2 },
        { x = 1135.8,  y = -982.3,  z = 46.4 },
        { x = -1222.9, y = -906.9,  z = 12.3 },
    },
}

-- ── Taxi ────────────────────────────────────────────────────────────────────
Config.Taxi = {
    callCommand = 'taxicall',
    vehicle = 'taxi',
    anyVehicle = false,
    baseFare = 20,
    perKm = 15,
    waitingPerMinute = 6,
    nightSurchargePct = 20,
    nightStart = 22,
    nightEnd = 5,
    maxTipPct = 30,
    companyCutPct = 20,
    pickupRadius = 5.0,
    dropRadius = 6.0,
    callExpireSeconds = 120,
    callCooldownSeconds = 60,
    npcService = {
        enabled = true,
        vehicle = 'taxi',
        driverModel = 's_m_m_gentransport',
        waitForPickupSeconds = 90,
        arriveRadius = 14.0,
    },
    surge = { calls = 2, windowSeconds = 300, pct = 25, durationSeconds = 600 },
    chatter = {
        pickup = {
            'Legion Square, and take it easy, my stomach is still deciding.',
            'You know a shortcut? Every cabbie says that and none of you do.',
            'Long day. You mind if I just stare out the window?',
            'My cousin says taxis are finished. I say he walks everywhere.',
        },
        mid = {
            'You always drive like this, or am I special?',
            'This city never fixes that pothole. Never.',
            'The meter is fair, right? It looks fair.',
            'I once left my phone in a cab. Three years ago. Still angry.',
        },
        drop = {
            'Appreciated. Keep the wheels on.',
            'Smooth enough. Take care out there.',
            'This is me. Thanks for the ride.',
        },
    },
    tiers = {
        { label = 'Rookie', at = 0,  mult = 1.0 },
        { label = 'Cabbie', at = 10, mult = 1.1 },
        { label = 'Pro',    at = 25, mult = 1.2 },
        { label = 'Elite',  at = 50, mult = 1.3 },
    },
    points = {
        { x = 195.2,   y = -934.5,  z = 30.7 },
        { x = -265.0,  y = -963.6,  z = 31.2 },
        { x = 300.5,   y = -584.0,  z = 43.3 },
        { x = -538.2,  y = -216.0,  z = 37.6 },
        { x = -1037.8, y = -2737.6, z = 20.2 },
        { x = -1223.7, y = -906.2,  z = 12.3 },
        { x = 129.5,   y = -223.0,  z = 54.6 },
        { x = 971.6,   y = -428.5,  z = 64.0 },
        { x = -797.0,  y = -1275.5, z = 5.0 },
        { x = 1136.3,  y = -981.9,  z = 46.4 },
    },
}

-- ── Trucking ────────────────────────────────────────────────────────────────
Config.Trucking = {
    vehicle = 'benson',
    payPerHaul = 180,
    chainBonusPct = 15,
    minLegs = 1,
    maxLegs = 3,
    offers = 3,
    offerSeconds = 90,
    dropRadius = 8.0,
    cargoClasses = {
        { id = 'standard', label = 'Standard', weight = 6, payMult = 1.0, minDone = 0 },
        { id = 'heavy',    label = 'Heavy',    weight = 2, payMult = 1.3, minDone = 0 },
        { id = 'hazmat',   label = 'Hazmat',   weight = 2, payMult = 1.6, minDone = 10, maxDamagePct = 10 },
    },
    tiers = {
        { label = 'Driver',     at = 0,  mult = 1.0 },
        { label = 'Hauler',     at = 10, mult = 1.1 },
        { label = 'Longhauler', at = 25, mult = 1.2 },
        { label = 'Kingpin',    at = 50, mult = 1.3 },
    },
    destinations = {
        { label = 'Paleto Bay Depot',  x = -430.6,  y = 6134.1,  z = 31.5 },
        { label = 'Sandy Shores Yard', x = 1651.6,  y = 3789.5,  z = 34.9 },
        { label = 'LSIA Cargo',        x = -1042.8, y = -2384.5, z = 13.9 },
        { label = 'Grapeseed Farm',    x = 2224.2,  y = 5152.9,  z = 57.4 },
        { label = 'Vespucci Docks',    x = -1595.2, y = -969.1,  z = 13.0 },
    },
}

-- ── Garbage ─────────────────────────────────────────────────────────────────
Config.Garbage = {
    vehicle = 'trash',
    payPerBag = 30,
    bagsPerRoute = 6,
    routeBonus = 60,
    pointRadius = 5.0,
    bagProp = 'prop_cs_rub_binbag_01',
    tiers = {
        { label = 'Picker',     at = 0,  mult = 1.0 },
        { label = 'Collector',  at = 15, mult = 1.1 },
        { label = 'Crew Chief', at = 40, mult = 1.2 },
        { label = 'Route Boss', at = 80, mult = 1.3 },
    },
    points = {
        { x = -351.6,  y = -1569.9, z = 25.2 },
        { x = -621.9,  y = -1622.6, z = 26.9 },
        { x = 84.7,    y = -1553.0, z = 29.6 },
        { x = 445.6,   y = -1707.5, z = 29.5 },
        { x = 240.3,   y = -1379.7, z = 33.7 },
        { x = -145.3,  y = -1440.0, z = 31.7 },
        { x = -560.7,  y = -1105.4, z = 22.3 },
        { x = -1042.6, y = -1136.9, z = 2.7 },
        { x = 118.2,   y = -1076.6, z = 29.2 },
        { x = 464.5,   y = -1284.1, z = 29.6 },
    },
}
