local job = nil
local blip = nil
local jobVehicle = nil
local passenger = nil
local stationData = { stations = {}, blips = {}, radius = 2.5 }
local stationBlips = {}
local stationUiOpen = false

local deliveryStops = {}
local deliveryIdx = 0
local deliveryRun = nil
local bodyStart = nil

local taxiStage = nil
local taxiMode = nil
local taxiPickup, taxiDrop = nil, nil
local taxiRates = nil
local meter = { dist = 0, wait = 0 }
local meterSurge = 0
local shiftTotal = 0
local lastPos = nil
local awaitingCab = false

local truckRun = nil

local garbRun = nil
local carryingBag = nil

local paxDriver = nil

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function chatLine(line)
    if not line then return end
    local ok = pcall(function()
        exports.pulse_notify:Notify({ kind = 'info', title = 'Passenger', message = line })
    end)
    if not ok then notify('~b~Passenger~s~ ' .. line) end
end

local function randomLine(pool)
    if type(pool) ~= 'table' or #pool == 0 then return nil end
    return pool[math.random(#pool)]
end

local function sendHud(data)
    SendNUIMessage({ action = 'job', data = data })
end

local function hideHud()
    SendNUIMessage({ action = 'hide' })
end

local function clearBlip()
    if blip and DoesBlipExist(blip) then RemoveBlip(blip) end
    blip = nil
end

local function setBlip(x, y, z, sprite, label, route)
    clearBlip()
    blip = AddBlipForCoord(x, y, z)
    SetBlipSprite(blip, sprite)
    SetBlipColour(blip, 5)
    if route then
        SetBlipRoute(blip, true)
        SetBlipRouteColour(blip, 5)
    end
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(label)
    EndTextCommandSetBlipName(blip)
end

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local deadline = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return nil end
        Wait(25)
    end
    return hash
end

local function clearPassenger()
    if passenger and DoesEntityExist(passenger) then
        TaskLeaveVehicle(passenger, GetVehiclePedIsIn(passenger, false), 0)
        SetPedAsNoLongerNeeded(passenger)
    end
    passenger = nil
end

local function damagePct()
    local veh = jobVehicle
    if (not veh or not DoesEntityExist(veh)) then veh = GetVehiclePedIsIn(PlayerPedId(), false) end
    if not veh or veh == 0 or not bodyStart then return 0 end
    local now = GetVehicleBodyHealth(veh)
    return math.max(0, math.min(100, (bodyStart - now) / 10.0))
end

local function markBodyStart()
    local veh = jobVehicle
    if (not veh or not DoesEntityExist(veh)) then veh = GetVehiclePedIsIn(PlayerPedId(), false) end
    bodyStart = (veh and veh ~= 0) and GetVehicleBodyHealth(veh) or 1000.0
end

local function dropBag()
    if carryingBag and DoesEntityExist(carryingBag) then DeleteObject(carryingBag) end
    carryingBag = nil
    ClearPedTasks(PlayerPedId())
end

local function endRun()
    job = nil
    deliveryStops = {}
    deliveryIdx = 0
    deliveryRun = nil
    taxiStage = nil
    taxiMode = nil
    taxiRates = nil
    truckRun = nil
    garbRun = nil
    bodyStart = nil
    lastPos = nil
    awaitingCab = false
    meter = { dist = 0, wait = 0 }
    meterSurge = 0
    clearBlip()
    clearPassenger()
    dropBag()
    hideHud()
    if jobVehicle and DoesEntityExist(jobVehicle) then
        DeleteVehicle(jobVehicle)
    end
    jobVehicle = nil
end

-- Spawns the job vehicle at the station bay. The worker walks over and gets in
-- themselves; the vehicle carries an owner tag so nobody else can drive it.
local function spawnJobVehicle(model, bay, plate)
    local hash = loadModel(model)
    if not hash then return end
    jobVehicle = CreateVehicle(hash, bay.x, bay.y, bay.z, bay.heading or 0.0, true, false)
    SetModelAsNoLongerNeeded(hash)
    SetVehicleNumberPlateText(jobVehicle, plate)
    SetVehicleOnGroundProperly(jobVehicle)
    SetVehicleEngineOn(jobVehicle, false, true, true)
    Entity(jobVehicle).state:set('pulse_job_owner', GetPlayerServerId(PlayerId()), true)

    local vb = AddBlipForEntity(jobVehicle)
    SetBlipSprite(vb, 225)
    SetBlipColour(vb, 3)
    SetBlipAsShortRange(vb, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName('Job vehicle')
    EndTextCommandSetBlipName(vb)
    notify('~b~Job~s~ Your vehicle is waiting in the bay.')
end

-- Only the clocked-in worker may drive a job vehicle: anyone else who takes
-- the wheel is stepped back out.
CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
            local owner = Entity(veh).state and Entity(veh).state.pulse_job_owner
            if owner and owner ~= GetPlayerServerId(PlayerId()) then
                TaskLeaveVehicle(ped, veh, 0)
                notify('~y~Job~s~ This vehicle belongs to another worker.')
            end
        end
    end
end)

-- ── Stations: blips, markers, prompts, UI ───────────────────────────────────
local function rebuildStationBlips()
    for _, b in ipairs(stationBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    stationBlips = {}
    for jobKey, list in pairs(stationData.stations or {}) do
        local meta = stationData.blips and stationData.blips[jobKey]
        if meta then
            for _, st in ipairs(list) do
                local b = AddBlipForCoord(st.x, st.y, st.z)
                SetBlipSprite(b, meta.sprite or 280)
                SetBlipColour(b, meta.color or 5)
                SetBlipScale(b, 0.8)
                SetBlipAsShortRange(b, true)
                BeginTextCommandSetBlipName('STRING')
                AddTextComponentSubstringPlayerName(meta.label or jobKey)
                EndTextCommandSetBlipName(b)
                stationBlips[#stationBlips + 1] = b
            end
        end
    end
end

RegisterNetEvent('pulse_jobs:stations', function(payload)
    if type(payload) ~= 'table' then return end
    stationData = payload
    rebuildStationBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_jobs:requestStations')
end)

RegisterNetEvent('pulse_jobs:stationInfoResult', function(payload)
    stationUiOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'station', data = payload })
end)

RegisterNUICallback('stationClose', function(_, cb)
    stationUiOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNUICallback('clockIn', function(data, cb)
    stationUiOpen = false
    SetNuiFocus(false, false)
    TriggerServerEvent('pulse_jobs:clockIn', data or {})
    cb({})
end)

RegisterNUICallback('clockOut', function(_, cb)
    stationUiOpen = false
    SetNuiFocus(false, false)
    TriggerServerEvent('pulse_jobs:clockOut')
    cb({})
end)

-- Station proximity loop.
CreateThread(function()
    while true do
        local sleep = 900
        if not stationUiOpen then
            local pos = GetEntityCoords(PlayerPedId())
            for jobKey, list in pairs(stationData.stations or {}) do
                for idx, st in ipairs(list) do
                    local dist = #(pos - vector3(st.x, st.y, st.z))
                    if dist < 40.0 then
                        sleep = 0
                        DrawMarker(2, st.x, st.y, st.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            0.5, 0.5, 0.5, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                        if dist <= (stationData.radius or 2.5) then
                            local meta = stationData.blips and stationData.blips[jobKey]
                            BeginTextCommandDisplayHelp('STRING')
                            AddTextComponentSubstringPlayerName(('Press ~INPUT_CONTEXT~ : %s'):format(meta and meta.label or jobKey))
                            EndTextCommandDisplayHelp(0, false, true, -1)
                            if IsControlJustReleased(0, 38) then
                                TriggerServerEvent('pulse_jobs:stationInfo', { job = jobKey, station = idx })
                                Wait(400)
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

-- ── Optional legacy commands ────────────────────────────────────────────────
if Config.AllowCommands then
    RegisterCommand('delivery', function(_, args) TriggerServerEvent('pulse_jobs:clockIn', { job = 'delivery', opt = args[1] }) end, false)
    RegisterCommand('taxi', function() TriggerServerEvent('pulse_jobs:clockIn', { job = 'taxi' }) end, false)
    RegisterCommand('trucking', function() TriggerServerEvent('pulse_jobs:clockIn', { job = 'trucking' }) end, false)
    RegisterCommand('garbage', function() TriggerServerEvent('pulse_jobs:clockIn', { job = 'garbage' }) end, false)
end

RegisterCommand(Config.Taxi.callCommand, function()
    local data = {}
    local wp = GetFirstBlipInfoId(8)
    if DoesBlipExist(wp) then
        local c = GetBlipInfoIdCoord(wp)
        data.dx, data.dy, data.dz = c.x, c.y, c.z
    end
    TriggerServerEvent('pulse_jobs:taxiCall', data)
end, false)

RegisterCommand('rate', function(_, args)
    TriggerServerEvent('pulse_jobs:rateDriver', tonumber(args[1]))
end, false)

RegisterCommand('jobstation', function(_, args)
    local action = args[1]
    if action == 'add' then
        local jobKey = args[2]
        local label = table.concat(args, ' ', 3)
        if label == '' then label = 'Station' end
        local pos = GetEntityCoords(PlayerPedId())
        TriggerServerEvent('pulse_jobs:adminStation', {
            action = 'add', job = jobKey, label = label,
            x = pos.x, y = pos.y, z = pos.z, heading = GetEntityHeading(PlayerPedId()),
        })
    elseif action == 'remove' then
        local pos = GetEntityCoords(PlayerPedId())
        TriggerServerEvent('pulse_jobs:adminStation', { action = 'remove', x = pos.x, y = pos.y })
    elseif action == 'list' then
        TriggerServerEvent('pulse_jobs:adminStation', { action = 'list' })
    else
        notify('~b~Jobs~s~ Usage: /jobstation add <taxi|delivery|trucking|garbage> <name>, /jobstation remove, /jobstation list')
    end
end, false)

-- ── Delivery ────────────────────────────────────────────────────────────────
local function deliveryHud(streakPct)
    if not deliveryRun then return end
    local pkg = (deliveryRun.types and deliveryRun.types[deliveryIdx]) or 'Standard'
    sendHud({
        title = 'Delivery', tier = deliveryRun.tier,
        rows = {
            { k = 'Stop', v = ('%d/%d'):format(deliveryIdx, #deliveryStops) },
            { k = 'Package', v = pkg, accent = pkg ~= 'Standard' },
            { k = 'Streak', v = ('+%d%%'):format(streakPct or 0), accent = (streakPct or 0) > 0 },
            { k = 'Cargo', v = ('%d%%'):format(math.floor(100 - damagePct() + 0.5)) },
        },
    })
end

RegisterNetEvent('pulse_jobs:beginDelivery', function(run)
    endRun()
    job = 'delivery'
    deliveryRun = run
    deliveryStops = run.stops or {}
    deliveryIdx = 1
    spawnJobVehicle(run.vehicle, run.bay, 'DELIVER')
    markBodyStart()
    notify(('~g~Delivery~s~ %d stops at $%d each. Priority runs on a tight clock; fragile hates dents.'):format(#deliveryStops, run.pay or 0))
    local s = deliveryStops[1]
    if s then setBlip(s.x, s.y, s.z, 478, 'Delivery stop 1/' .. #deliveryStops, true) end
    deliveryHud(0)
end)

RegisterNetEvent('pulse_jobs:nextStop', function(data)
    deliveryIdx = data.index
    local s = deliveryStops[deliveryIdx]
    if s then setBlip(s.x, s.y, s.z, 478, ('Delivery stop %d/%d'):format(deliveryIdx, #deliveryStops), true) end
    local pkg = (deliveryRun and deliveryRun.types and deliveryRun.types[deliveryIdx]) or 'Standard'
    if pkg ~= 'Standard' then
        notify(('~b~Delivery~s~ Next package is %s.'):format(pkg))
    end
    deliveryHud(data.streak)
end)

local function deliverPackage()
    local ped = PlayerPedId()
    local box = nil
    local hash = loadModel('prop_cs_cardbox_01')
    if hash then
        RequestAnimDict('anim@heists@box_carry@')
        local deadline = GetGameTimer() + 3000
        while not HasAnimDictLoaded('anim@heists@box_carry@') and GetGameTimer() < deadline do Wait(25) end
        box = CreateObject(hash, 0.0, 0.0, 0.0, true, true, false)
        AttachEntityToEntity(box, ped, GetPedBoneIndex(ped, 60309), 0.05, 0.1, -0.3, 100.0, 90.0, 0.0, true, true, false, true, 1, true)
        if HasAnimDictLoaded('anim@heists@box_carry@') then
            TaskPlayAnim(ped, 'anim@heists@box_carry@', 'idle', 3.0, -1, -1, 51, 0, false, false, false)
        end
        SetModelAsNoLongerNeeded(hash)
    end
    Wait(((deliveryRun and deliveryRun.handoverSeconds) or 3) * 1000)
    ClearPedTasks(ped)
    if box and DoesEntityExist(box) then DeleteObject(box) end
    TriggerServerEvent('pulse_jobs:stopReached', { damagePct = damagePct() })
end

-- ── Taxi ────────────────────────────────────────────────────────────────────
local function estimatedFare()
    if not taxiRates then return 0 end
    local km = meter.dist / 1000.0
    local fare = taxiRates.base + taxiRates.perKm * km + taxiRates.waitPerMin * (meter.wait / 60.0)
    local hour = GetClockHours()
    local night = hour >= taxiRates.nightStart or hour < taxiRates.nightEnd
    if night then fare = fare * (1 + taxiRates.nightPct / 100) end
    if meterSurge > 0 then fare = fare * (1 + meterSurge / 100) end
    return math.floor(fare * (taxiRates.tierMult or 1) + 0.5), night
end

local function taxiHud()
    if not taxiRates then return end
    local fare, night = estimatedFare()
    local hired = taxiStage == 'drive'
    SendNUIMessage({
        action = 'meter',
        data = {
            fare = hired and fare or 0,
            km = hired and (meter.dist / 1000.0) or 0,
            wait = hired and meter.wait or 0,
            night = night,
            nightPct = taxiRates.nightPct,
            surgePct = meterSurge,
            hired = hired,
            shiftTotal = shiftTotal,
            tier = taxiRates.tier,
        },
    })
end

RegisterNetEvent('pulse_jobs:taxiPaid', function(data)
    shiftTotal = tonumber(data and data.shiftTotal) or shiftTotal
    taxiHud()
end)

RegisterNetEvent('pulse_jobs:beginTaxi', function(run)
    endRun()
    job = 'taxi'
    shiftTotal = 0
    taxiRates = run.rates
    spawnJobVehicle(run.vehicle, run.bay, 'PLSCAB')
    awaitingCab = true
    notify('~g~Taxi~s~ On shift. Take your cab out; fares start when you are behind the wheel.')
end)

-- Fares begin once the driver actually takes the cab out.
CreateThread(function()
    while true do
        Wait(800)
        if job == 'taxi' and awaitingCab and jobVehicle and DoesEntityExist(jobVehicle) then
            if GetPedInVehicleSeat(jobVehicle, -1) == PlayerPedId() then
                awaitingCab = false
                TriggerServerEvent('pulse_jobs:taxiReady')
            end
        end
    end
end)

RegisterNetEvent('pulse_jobs:taxiFare', function(fare)
    if job ~= 'taxi' then return end
    taxiMode = 'npc'
    taxiPickup, taxiDrop = fare.pickup, fare.drop
    taxiStage = 'pickup'
    meterSurge = tonumber(fare.surgePct) or 0
    meter = { dist = 0, wait = 0 }
    lastPos = nil
    clearPassenger()
    setBlip(taxiPickup.x, taxiPickup.y, taxiPickup.z, 280, 'Taxi pickup', true)
    if meterSurge > 0 then
        notify(('~b~Taxi~s~ New fare on the board. ~y~Surge pricing +%d%%~s~.'):format(meterSurge))
    else
        notify('~b~Taxi~s~ New fare on the board. Head to the pickup.')
    end
    taxiHud()
end)

CreateThread(function()
    while true do
        Wait(math.random(40000, 75000))
        if job == 'taxi' and taxiMode == 'npc' and taxiStage == 'drive' then
            chatLine(randomLine(Config.Taxi.chatter.mid))
        end
    end
end)

RegisterNetEvent('pulse_jobs:playerFareStarted', function(data)
    if job ~= 'taxi' then return end
    taxiMode = 'player'
    taxiStage = 'drive'
    meterSurge = tonumber(data.surgePct) or 0
    meter = { dist = 0, wait = 0 }
    lastPos = nil
    markBodyStart()
    clearBlip()
    clearPassenger()
    notify(('~b~Taxi~s~ %s hopped in. Meter running; they choose the destination.'):format(data.passenger or 'A passenger'))
    taxiHud()
end)

RegisterNetEvent('pulse_jobs:playerFareEnded', function()
    if job ~= 'taxi' then return end
    taxiStage = nil
    taxiMode = nil
end)

RegisterNetEvent('pulse_jobs:taxiCallPing', function(call)
    if job ~= 'taxi' then return end
    local b = AddBlipForCoord(call.x + 0.0, call.y + 0.0, (call.z or 30.0) + 0.0)
    SetBlipSprite(b, 280)
    SetBlipColour(b, 3)
    SetBlipFlashes(b, true)
    SetBlipAsShortRange(b, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName('Taxi call')
    EndTextCommandSetBlipName(b)
    SetTimeout((call.expire or 120) * 1000, function()
        if DoesBlipExist(b) then RemoveBlip(b) end
    end)
end)

local function spawnNpcPassenger()
    local hash = loadModel('a_m_m_business_01')
    if not hash then return nil end
    local ped = CreatePed(4, hash, taxiPickup.x, taxiPickup.y, taxiPickup.z, 0.0, true, false)
    SetModelAsNoLongerNeeded(hash)
    SetBlockingOfNonTemporaryEvents(ped, true)
    return ped
end

CreateThread(function()
    while true do
        Wait(1000)
        if job == 'taxi' and taxiStage == 'drive' then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 then
                local pos = GetEntityCoords(veh)
                local speed = GetEntitySpeed(veh)
                if lastPos and speed > 0.5 then
                    meter.dist = meter.dist + #(pos - lastPos)
                elseif speed <= 0.5 then
                    meter.wait = meter.wait + 1
                end
                lastPos = pos
            end
            taxiHud()
        end
    end
end)

CreateThread(function()
    while true do
        Wait(4000)
        if job == 'taxi' and taxiStage == 'drive' then
            local hour = GetClockHours()
            local night = taxiRates and (hour >= taxiRates.nightStart or hour < taxiRates.nightEnd) or false
            TriggerServerEvent('pulse_jobs:meterTick', { dist = meter.dist, wait = meter.wait, night = night })
        end
    end
end)

-- Passenger side: riding another player's cab.
CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh ~= 0 and not paxDriver and job == nil then
            local driverPed = GetPedInVehicleSeat(veh, -1)
            if driverPed ~= 0 and driverPed ~= ped and IsPedAPlayer(driverPed) then
                local idx = NetworkGetPlayerIndexFromPed(driverPed)
                if idx and idx ~= -1 then
                    paxDriver = GetPlayerServerId(idx)
                    TriggerServerEvent('pulse_jobs:paxEntered', { driver = paxDriver })
                end
            end
        elseif veh == 0 and paxDriver then
            TriggerServerEvent('pulse_jobs:paxExited', { driver = paxDriver })
            paxDriver = nil
        end
    end
end)

-- ── AI cab service (passenger side) ─────────────────────────────────────────
local npcCab = nil

local function npcCabCleanup(driveOff)
    if not npcCab then return end
    if npcCab.blip and DoesBlipExist(npcCab.blip) then RemoveBlip(npcCab.blip) end
    if driveOff and npcCab.driver and DoesEntityExist(npcCab.driver) and npcCab.veh and DoesEntityExist(npcCab.veh) then
        TaskVehicleDriveWander(npcCab.driver, npcCab.veh, 15.0, 786603)
        SetPedAsNoLongerNeeded(npcCab.driver)
        SetVehicleAsNoLongerNeeded(npcCab.veh)
    else
        if npcCab.driver and DoesEntityExist(npcCab.driver) then DeletePed(npcCab.driver) end
        if npcCab.veh and DoesEntityExist(npcCab.veh) then DeleteVehicle(npcCab.veh) end
    end
    npcCab = nil
    hideHud()
end

local function npcRideFare()
    if not npcCab then return 0, false end
    local r = npcCab.rates
    local km = npcCab.meter.dist / 1000.0
    local hour = GetClockHours()
    local night = hour >= r.nightStart or hour < r.nightEnd
    local fare = r.base + r.perKm * km + r.waitPerMin * (npcCab.meter.wait / 60.0)
    if night then fare = fare * (1 + r.nightPct / 100) end
    if (r.surgePct or 0) > 0 then fare = fare * (1 + r.surgePct / 100) end
    return math.floor(fare + 0.5), night
end

local function npcRideMeterHud()
    if not npcCab then return end
    local fare, night = npcRideFare()
    SendNUIMessage({
        action = 'meter',
        data = {
            fare = fare, km = npcCab.meter.dist / 1000.0, wait = npcCab.meter.wait,
            night = night, nightPct = npcCab.rates.nightPct,
            surgePct = npcCab.rates.surgePct or 0,
            hired = true, shiftTotal = fare, tier = 'Ride',
        },
    })
end

local function waypointCoords()
    local wp = GetFirstBlipInfoId(8)
    if not DoesBlipExist(wp) then return nil end
    return GetBlipInfoIdCoord(wp)
end

RegisterNetEvent('pulse_jobs:npcCab', function(data)
    if npcCab then return end
    local me = PlayerPedId()
    local myPos = GetEntityCoords(me)

    local vehHash = loadModel(data.vehicle or 'taxi')
    local pedHash = loadModel(data.driverModel or 's_m_m_gentransport')
    if not vehHash or not pedHash then
        TriggerServerEvent('pulse_jobs:npcRideCancel')
        return
    end

    local found, nodePos, heading = GetClosestVehicleNodeWithHeading(myPos.x + 120.0, myPos.y + 120.0, myPos.z, 1, 3.0, 0)
    if not found then
        found, nodePos, heading = GetClosestVehicleNodeWithHeading(myPos.x - 120.0, myPos.y - 120.0, myPos.z, 1, 3.0, 0)
    end
    if not found then
        TriggerServerEvent('pulse_jobs:npcRideCancel')
        notify('~y~Taxi~s~ No cab could reach you out here.')
        return
    end

    local veh = CreateVehicle(vehHash, nodePos.x, nodePos.y, nodePos.z, heading or 0.0, true, false)
    local driver = CreatePedInsideVehicle(veh, 26, pedHash, -1, true, false)
    SetModelAsNoLongerNeeded(vehHash)
    SetModelAsNoLongerNeeded(pedHash)
    SetBlockingOfNonTemporaryEvents(driver, true)
    SetVehicleNumberPlateText(veh, 'PLSCAB')
    SetVehicleEngineOn(veh, true, true, false)

    local b = AddBlipForEntity(veh)
    SetBlipSprite(b, 198)
    SetBlipColour(b, 5)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName('Your taxi')
    EndTextCommandSetBlipName(b)

    npcCab = {
        veh = veh, driver = driver, blip = b, stage = 'arriving',
        rates = data.rates, meter = { dist = 0, wait = 0 }, lastPos = nil,
        arriveRadius = data.arriveRadius or 14.0,
        waitDeadline = GetGameTimer() + (data.waitSeconds or 90) * 1000,
    }
    TaskVehicleDriveToCoordLongrange(driver, veh, myPos.x, myPos.y, myPos.z, 16.0, 786603, 22.0)

    CreateThread(function()
        while npcCab do
            Wait(500)
            local cab = npcCab
            if not cab or not DoesEntityExist(cab.veh) or not DoesEntityExist(cab.driver) then
                TriggerServerEvent('pulse_jobs:npcRideCancel')
                npcCabCleanup(false)
                break
            end
            local ped = PlayerPedId()
            local inCab = GetVehiclePedIsIn(ped, false) == cab.veh

            if cab.stage == 'arriving' then
                if #(GetEntityCoords(cab.veh) - GetEntityCoords(ped)) < 22.0 then
                    TaskVehicleTempAction(cab.driver, cab.veh, 27, 6000)
                    cab.stage = 'waiting'
                    notify('~b~Taxi~s~ Your cab is here. Hop in.')
                end
            elseif cab.stage == 'waiting' then
                if inCab then
                    local dest = waypointCoords()
                    if dest then
                        cab.dest = dest
                        cab.stage = 'ride'
                        cab.meter = { dist = 0, wait = 0 }
                        cab.lastPos = nil
                        TaskVehicleDriveToCoordLongrange(cab.driver, cab.veh, dest.x, dest.y, dest.z, 17.0, 786603, 16.0)
                        notify('~b~Taxi~s~ Meter running. Sit tight.')
                    else
                        notify('~y~Taxi~s~ Set a waypoint on your map so the driver knows where to go.')
                        Wait(2500)
                    end
                elseif GetGameTimer() > cab.waitDeadline then
                    TriggerServerEvent('pulse_jobs:npcRideCancel')
                    notify('~y~Taxi~s~ The cab gave up waiting and left.')
                    npcCabCleanup(true)
                    break
                end
            elseif cab.stage == 'ride' then
                if not inCab then
                    TriggerServerEvent('pulse_jobs:npcRideTick', { dist = cab.meter.dist, wait = cab.meter.wait, night = select(2, npcRideFare()) })
                    TriggerServerEvent('pulse_jobs:npcRideEnd')
                    npcCabCleanup(true)
                    break
                end
                if #(GetEntityCoords(cab.veh) - vector3(cab.dest.x, cab.dest.y, cab.dest.z)) < cab.arriveRadius then
                    TaskVehicleTempAction(cab.driver, cab.veh, 27, 8000)
                    cab.stage = 'arrived'
                    local fare = npcRideFare()
                    notify(('~b~Taxi~s~ Here we are. $%d, payable when you step out.'):format(fare))
                end
            elseif cab.stage == 'arrived' then
                if not inCab then
                    TriggerServerEvent('pulse_jobs:npcRideTick', { dist = cab.meter.dist, wait = cab.meter.wait, night = select(2, npcRideFare()) })
                    TriggerServerEvent('pulse_jobs:npcRideEnd')
                    npcCabCleanup(true)
                    break
                end
            end
        end
    end)
end)

CreateThread(function()
    local syncTick = 0
    while true do
        Wait(1000)
        if npcCab and (npcCab.stage == 'ride' or npcCab.stage == 'arrived') then
            local veh = npcCab.veh
            if DoesEntityExist(veh) then
                local pos = GetEntityCoords(veh)
                local speed = GetEntitySpeed(veh)
                if npcCab.lastPos and speed > 0.5 then
                    npcCab.meter.dist = npcCab.meter.dist + #(pos - npcCab.lastPos)
                elseif speed <= 0.5 then
                    npcCab.meter.wait = npcCab.meter.wait + 1
                end
                npcCab.lastPos = pos
                npcRideMeterHud()
                syncTick = syncTick + 1
                if syncTick % 4 == 0 then
                    TriggerServerEvent('pulse_jobs:npcRideTick', {
                        dist = npcCab.meter.dist, wait = npcCab.meter.wait,
                        night = select(2, npcRideFare()),
                    })
                end
            end
        end
    end
end)

-- ── Trucking ────────────────────────────────────────────────────────────────
local function truckHud()
    if not truckRun then return end
    sendHud({
        title = 'Trucking', tier = truckRun.tier,
        rows = {
            { k = 'Leg', v = ('%d/%d'):format(truckRun.leg, #truckRun.legs) },
            { k = 'Class', v = truckRun.class or 'Standard', accent = truckRun.hazmat },
            { k = 'Cargo', v = ('%d%%'):format(math.floor(100 - damagePct() + 0.5)) },
            { k = 'Chain', v = #truckRun.legs > 1 and ('+%d%%'):format(truckRun.chainBonusPct or 0) or 'single' },
        },
    })
end

RegisterNetEvent('pulse_jobs:beginTrucking', function(run)
    endRun()
    job = 'trucking'
    truckRun = {
        legs = run.legs or {}, leg = 1, tier = run.tier,
        chainBonusPct = run.chainBonusPct, class = run.cargoClass, hazmat = run.hazmat,
    }
    spawnJobVehicle(run.vehicle, run.bay, 'HAULER')
    markBodyStart()
    local first = truckRun.legs[1]
    if run.hazmat then
        notify(('~g~Trucking~s~ %s contract, %d leg(s). ~y~Over 10%% cargo damage voids a leg.~s~'):format(run.cargoClass or 'Hazmat', #truckRun.legs))
    else
        notify(('~g~Trucking~s~ %s contract, %d leg(s), $%d per leg. First stop: %s.'):format(run.cargoClass or 'Standard', #truckRun.legs, run.pay or 0, first and first.label or ''))
    end
    if first then setBlip(first.x, first.y, first.z, 477, 'Haul: ' .. (first.label or ''), true) end
    truckHud()
end)

RegisterNetEvent('pulse_jobs:nextLeg', function(data)
    if not truckRun then return end
    truckRun.leg = data.index
    markBodyStart()
    local d = data.dest
    if d then setBlip(d.x, d.y, d.z, 477, 'Haul: ' .. (d.label or ''), true) end
    truckHud()
end)

-- ── Garbage ─────────────────────────────────────────────────────────────────
local function garbageHud()
    if not garbRun then return end
    sendHud({
        title = 'Garbage', tier = garbRun.tier,
        rows = {
            { k = 'Bag', v = ('%d/%d'):format(math.min(garbRun.idx, #garbRun.points), #garbRun.points) },
            { k = 'Per bag', v = ('$%d'):format(garbRun.pay or 0) },
            { k = 'Bonus', v = ('$%d at depot'):format(garbRun.bonus or 0) },
        },
    })
end

RegisterNetEvent('pulse_jobs:beginGarbage', function(run)
    endRun()
    job = 'garbage'
    garbRun = {
        points = run.points or {}, idx = 1, phase = 'collect',
        pay = run.pay, bonus = run.bonus, bagProp = run.bagProp, tier = run.tier,
    }
    spawnJobVehicle(run.vehicle, run.bay, 'TRASH')
    local p = garbRun.points[1]
    notify(('~g~Garbage~s~ %d bags on the route, $%d each. Bring the truck back for the bonus.'):format(#garbRun.points, run.pay or 0))
    if p then setBlip(p.x, p.y, p.z, 318, 'Collection point 1/' .. #garbRun.points, true) end
    garbageHud()
end)

RegisterNetEvent('pulse_jobs:nextBag', function(data)
    if not garbRun then return end
    garbRun.idx = data.index
    local p = garbRun.points[garbRun.idx]
    if p then setBlip(p.x, p.y, p.z, 318, ('Collection point %d/%d'):format(garbRun.idx, #garbRun.points), true) end
    garbageHud()
end)

RegisterNetEvent('pulse_jobs:garbageReturnPhase', function()
    if not garbRun then return end
    garbRun.phase = 'return'
    clearBlip()
    -- Route back to the nearest garbage station.
    local pos = GetEntityCoords(PlayerPedId())
    local best, bestDist = nil, math.huge
    for _, st in ipairs((stationData.stations and stationData.stations.garbage) or {}) do
        local d = #(pos - vector3(st.x, st.y, st.z))
        if d < bestDist then best, bestDist = st, d end
    end
    if best then setBlip(best.x, best.y, best.z, 318, 'Sanitation depot', true) end
    garbageHud()
end)

local function collectBag()
    local ped = PlayerPedId()
    local hash = loadModel(garbRun.bagProp or 'prop_cs_rub_binbag_01')
    if hash then
        RequestAnimDict('anim@heists@box_carry@')
        local deadline = GetGameTimer() + 3000
        while not HasAnimDictLoaded('anim@heists@box_carry@') and GetGameTimer() < deadline do Wait(25) end
        carryingBag = CreateObject(hash, 0.0, 0.0, 0.0, true, true, false)
        AttachEntityToEntity(carryingBag, ped, GetPedBoneIndex(ped, 60309), 0.1, 0.1, -0.2, 90.0, 0.0, 0.0, true, true, false, true, 1, true)
        if HasAnimDictLoaded('anim@heists@box_carry@') then
            TaskPlayAnim(ped, 'anim@heists@box_carry@', 'idle', 3.0, -1, -1, 51, 0, false, false, false)
        end
        SetModelAsNoLongerNeeded(hash)
    end
    notify('~b~Garbage~s~ Bag up. Toss it in the back of the truck.')
end

RegisterNetEvent('pulse_jobs:finished', function() endRun() end)
RegisterNetEvent('pulse_jobs:cancelled', function() endRun() end)
RegisterNetEvent('pulse_jobs:notify', function(msg)
    if msg then notify(msg) end
end)

-- ── Shared work prompts ─────────────────────────────────────────────────────
local function promptAt(x, y, z, radius, text)
    local pos = GetEntityCoords(PlayerPedId())
    local dist = #(pos - vector3(x, y, z))
    if dist < 60.0 then
        DrawMarker(2, x, y, z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
            0.6, 0.6, 0.6, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
        if dist <= radius then
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(text)
            EndTextCommandDisplayHelp(0, false, true, -1)
            return IsControlJustReleased(0, 38)
        end
    end
    return false
end

CreateThread(function()
    while true do
        local sleep = 800
        if job == 'delivery' and deliveryIdx > 0 then
            local s = deliveryStops[deliveryIdx]
            if s then
                sleep = 0
                if promptAt(s.x, s.y, s.z, Config.Delivery.stopRadius, 'Press ~INPUT_CONTEXT~ to deliver the package') then
                    deliverPackage()
                    Wait(400)
                end
            end
        elseif job == 'taxi' and taxiMode == 'npc' and taxiStage == 'pickup' and taxiPickup then
            sleep = 0
            if promptAt(taxiPickup.x, taxiPickup.y, taxiPickup.z, Config.Taxi.pickupRadius, 'Press ~INPUT_CONTEXT~ to pick up your passenger') then
                local veh = GetVehiclePedIsIn(PlayerPedId(), false)
                if veh == 0 or (not Config.Taxi.anyVehicle and GetVehicleClass(veh) ~= 20 and GetEntityModel(veh) ~= joaat('taxi')) then
                    notify('~y~Taxi~s~ You need a taxi to pick up fares.')
                else
                    passenger = spawnNpcPassenger()
                    if passenger then
                        local seat = GetVehicleModelNumberOfSeats(GetEntityModel(veh)) >= 4 and 2 or 0
                        TaskEnterVehicle(passenger, veh, 12000, seat, 1.5, 1, 0)
                    end
                    taxiStage = 'drive'
                    meter = { dist = 0, wait = 0 }
                    lastPos = nil
                    markBodyStart()
                    TriggerServerEvent('pulse_jobs:taxiPickedUp')
                    setBlip(taxiDrop.x, taxiDrop.y, taxiDrop.z, 280, 'Taxi dropoff', true)
                    notify('~b~Taxi~s~ Passenger aboard. Smooth driving earns the tip.')
                    SetTimeout(2500, function() chatLine(randomLine(Config.Taxi.chatter.pickup)) end)
                    Wait(600)
                end
            end
        elseif job == 'taxi' and taxiMode == 'npc' and taxiStage == 'drive' and taxiDrop then
            sleep = 0
            if promptAt(taxiDrop.x, taxiDrop.y, taxiDrop.z, Config.Taxi.dropRadius, 'Press ~INPUT_CONTEXT~ to drop off your passenger') then
                chatLine(randomLine(Config.Taxi.chatter.drop))
                clearPassenger()
                TriggerServerEvent('pulse_jobs:taxiDropped', { damagePct = damagePct() })
                taxiStage = nil
                Wait(600)
            end
        elseif job == 'trucking' and truckRun then
            local d = truckRun.legs[truckRun.leg]
            if d then
                sleep = 0
                if promptAt(d.x, d.y, d.z, Config.Trucking.dropRadius, 'Press ~INPUT_CONTEXT~ to unload the cargo') then
                    TriggerServerEvent('pulse_jobs:haulDelivered', { damagePct = damagePct() })
                    Wait(600)
                end
            end
        elseif job == 'garbage' and garbRun and garbRun.phase == 'collect' then
            local p = garbRun.points[garbRun.idx]
            if p then
                sleep = 0
                if not carryingBag then
                    if promptAt(p.x, p.y, p.z, Config.Garbage.pointRadius, 'Press ~INPUT_CONTEXT~ to grab a bag') then
                        collectBag()
                        Wait(400)
                    end
                elseif jobVehicle and DoesEntityExist(jobVehicle) then
                    local rear = GetOffsetFromEntityInWorldCoords(jobVehicle, 0.0, -4.5, 0.0)
                    if promptAt(rear.x, rear.y, rear.z, 2.5, 'Press ~INPUT_CONTEXT~ to load the bag') then
                        dropBag()
                        TriggerServerEvent('pulse_jobs:bagCollected')
                        Wait(400)
                    end
                end
            end
        elseif job == 'garbage' and garbRun and garbRun.phase == 'return' and jobVehicle and DoesEntityExist(jobVehicle) then
            for _, st in ipairs((stationData.stations and stationData.stations.garbage) or {}) do
                local pos = GetEntityCoords(PlayerPedId())
                if #(pos - vector3(st.x, st.y, st.z)) < 60.0 then
                    sleep = 0
                    if promptAt(st.x, st.y, st.z, 8.0, 'Press ~INPUT_CONTEXT~ to turn in the truck') then
                        TriggerServerEvent('pulse_jobs:garbageReturn')
                        Wait(600)
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
