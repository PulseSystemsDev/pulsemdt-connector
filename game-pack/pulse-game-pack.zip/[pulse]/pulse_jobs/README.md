# pulse_jobs

`pulse_jobs` provides station-based civilian delivery, taxi, trucking, and garbage jobs with PulseMDT-backed payouts and job history.

## Requirements

- `pulsemdt` with characters and economy enabled
- `pulse_core` recommended
- `pulse_notify` optional

## Installation

Configure stations, routes, vehicles, and payouts in `config.lua`, then start `pulse_jobs` after `pulsemdt`.

Grant station administrators access when using `/jobstation`:

```cfg
add_ace group.admin pulse.jobs allow
ensure pulse_jobs
```

## Usage

Players normally clock in at world stations. Set `Config.AllowCommands = true` to also enable `/delivery`, `/taxi`, `/trucking`, and `/garbage`. Taxi users can request a ride with the configured call command (default `/taxicall`) and rate a driver with `/rate <serverId>`.

Use `/jobstation add|remove|list` to manage dashboard-backed station locations.
