const RESOURCE = 'pulse_jobs';
const hud = document.getElementById('hud');
const titleEl = document.getElementById('title');
const tierEl = document.getElementById('tier');
const rowsEl = document.getElementById('rows');
const meterEl = document.getElementById('meter');
const stationEl = document.getElementById('station');

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

let stationCtx = null;

function closeStation(notifyClient = true) {
  stationEl.classList.add('hidden');
  stationCtx = null;
  if (notifyClient) post('stationClose');
}

function renderStation(d) {
  stationCtx = d;
  document.getElementById('sBadge').textContent = (d.job || 'JOB').toUpperCase();
  document.getElementById('sTitle').textContent = { taxi: 'Taxi Depot', delivery: 'Courier Depot', trucking: 'Freight Yard', garbage: 'Sanitation Depot' }[d.job] || 'Job Station';
  document.getElementById('sStation').textContent = d.stationLabel || '';
  document.getElementById('sDesc').textContent = d.description || '';

  const c = d.career || {};
  document.getElementById('sTier').textContent = c.tier || '';
  document.getElementById('sCareerMeta').textContent =
    `${c.done ?? 0} completed | $${Math.floor(c.earned ?? 0).toLocaleString()} earned | +${c.bonusPct ?? 0}% pay`;
  const progress = c.nextAt ? Math.min(100, Math.round(((c.done ?? 0) / c.nextAt) * 100)) : 100;
  document.getElementById('sProgress').style.width = `${progress}%`;
  document.getElementById('sNext').textContent =
    c.nextLabel ? `${c.nextAt - (c.done ?? 0)} more to ${c.nextLabel}` : 'Top tier reached';

  const ratesEl = document.getElementById('sRates');
  ratesEl.innerHTML = '';
  for (const r of d.rates || []) {
    const row = document.createElement('div');
    row.className = 'r';
    const k = document.createElement('span');
    k.className = 'k';
    k.textContent = r.k;
    const v = document.createElement('span');
    v.className = 'v' + (r.accent ? ' accent' : '');
    v.textContent = r.v;
    row.append(k, v);
    ratesEl.appendChild(row);
  }

  const choicesEl = document.getElementById('sChoices');
  choicesEl.innerHTML = '';
  const clockIn = document.getElementById('sClockIn');
  const clockOut = document.getElementById('sClockOut');
  const note = document.getElementById('sNote');
  clockIn.classList.add('hidden');
  clockOut.classList.add('hidden');
  note.textContent = '';

  if (!d.enabled) {
    note.textContent = 'This job is not offered on this server.';
  } else if (d.onDuty) {
    clockOut.classList.remove('hidden');
    note.textContent = 'Clocking out ends the run and returns the vehicle.';
  } else if (d.otherDuty) {
    note.textContent = `You are clocked in as ${d.otherDuty}. Clock out there first.`;
  } else if (d.job === 'delivery' && d.lengths) {
    for (const l of d.lengths) {
      const btn = document.createElement('button');
      btn.className = 's-choice';
      btn.innerHTML = '<span class="c-main"><span class="c-title"></span><span class="c-sub"></span></span><span class="c-pay">Start</span>';
      btn.querySelector('.c-title').textContent = l.label;
      btn.querySelector('.c-sub').textContent = l.detail;
      btn.addEventListener('click', () => {
        post('clockIn', { job: d.job, station: d.station, opt: l.id });
        closeStation(false);
      });
      choicesEl.appendChild(btn);
    }
    note.textContent = 'Pick a route length to clock in.';
  } else if (d.job === 'trucking' && d.contracts) {
    for (const ct of d.contracts) {
      const btn = document.createElement('button');
      btn.className = 's-choice';
      const title = document.createElement('span');
      title.className = 'c-title';
      title.textContent = `${ct.class} cargo, ${ct.legs} leg${ct.legs === 1 ? '' : 's'}`;
      if (ct.hazmat) {
        const hz = document.createElement('span');
        hz.className = 'hz';
        hz.textContent = ' !';
        title.appendChild(hz);
      }
      const sub = document.createElement('span');
      sub.className = 'c-sub';
      sub.textContent = ct.route;
      const main = document.createElement('span');
      main.className = 'c-main';
      main.append(title, sub);
      const pay = document.createElement('span');
      pay.className = 'c-pay';
      pay.textContent = `~$${ct.est.toLocaleString()}`;
      btn.append(main, pay);
      btn.addEventListener('click', () => {
        post('clockIn', { job: d.job, station: d.station, opt: ct.id });
        closeStation(false);
      });
      choicesEl.appendChild(btn);
    }
    note.textContent = 'Accept a contract to clock in. Hazmat voids any leg over 10% damage.';
  } else {
    clockIn.classList.remove('hidden');
  }

  stationEl.classList.remove('hidden');
}

document.getElementById('sClose').addEventListener('click', closeStation);
document.getElementById('sClockIn').addEventListener('click', () => {
  if (stationCtx) {
    post('clockIn', { job: stationCtx.job, station: stationCtx.station });
    closeStation(false);
  }
});
document.getElementById('sClockOut').addEventListener('click', () => {
  post('clockOut');
  closeStation(false);
});
document.addEventListener('keydown', (e) => {
  if (!stationEl.classList.contains('hidden') && e.key === 'Escape') closeStation();
});

function fmtWait(sec) {
  const s = Math.max(0, Math.floor(Number(sec) || 0));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function renderMeter(d) {
  document.getElementById('mFare').textContent =
    '$' + Number(d.fare || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const distEl = document.getElementById('mDist');
  distEl.innerHTML = '';
  distEl.append(document.createTextNode((Number(d.km) || 0).toFixed(1)));
  const unit = document.createElement('small');
  unit.textContent = 'km';
  distEl.append(unit);
  document.getElementById('mWait').textContent = fmtWait(d.wait);
  document.getElementById('mTariff').textContent = d.night ? '2' : '1';
  document.getElementById('mShift').textContent = '$' + Math.floor(Number(d.shiftTotal) || 0).toLocaleString();
  document.getElementById('mTier').textContent = d.tier || '';
  document.getElementById('mLampHired').classList.toggle('on', !!d.hired);
  document.getElementById('mLampFree').classList.toggle('on', !d.hired);
  const surge = Number(d.surgePct) || 0;
  document.getElementById('mExtra').textContent =
    surge > 0 ? `SURGE +${surge}%` : d.night ? `NIGHT +${d.nightPct || 0}%` : '';
  meterEl.classList.remove('hidden');
  hud.classList.add('hidden');
}

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'hide') {
    hud.classList.add('hidden');
    meterEl.classList.add('hidden');
  } else if (m.action === 'station') {
    renderStation(m.data || {});
  } else if (m.action === 'meter') {
    renderMeter(m.data || {});
  } else if (m.action === 'job') {
    const d = m.data || {};
    titleEl.textContent = d.title || 'Job';
    tierEl.textContent = d.tier || '';
    rowsEl.innerHTML = '';
    for (const r of d.rows || []) {
      const row = document.createElement('div');
      row.className = 'row';
      const k = document.createElement('span');
      k.className = 'k';
      k.textContent = r.k;
      const v = document.createElement('span');
      v.className = 'v' + (r.accent ? ' accent' : '');
      v.textContent = r.v;
      row.append(k, v);
      rowsEl.appendChild(row);
    }
    hud.classList.remove('hidden');
    meterEl.classList.add('hidden');
  }
});
