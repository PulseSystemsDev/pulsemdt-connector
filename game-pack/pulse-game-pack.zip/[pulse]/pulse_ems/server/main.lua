local function getDiscordId(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then
            return id:sub(9)
        end
    end
    return nil
end

local function requireDuty(src)
    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'ems', 'fire') end)
    return authorized
end

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_ems') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)
local function treatmentAllowed()
    if not Config.AllowTreatmentEntry then return false end
    local v = RCFG.settings and RCFG.settings.allowTreatmentEntry
    if v == nil then return true end
    return v == true
end

RegisterNetEvent('pulse_ems:check', function(data)
    local src = source
    if not RCFG.enabled then
        TriggerClientEvent('pulse_ems:result', src, { error = 'Medical records are disabled on this server.' })
        return
    end
    if not requireDuty(src) then
        TriggerClientEvent('pulse_ems:result', src, { error = 'An on-duty EMS or Fire role is required to check patients.' })
        return
    end

    local targetSrc = tonumber(data and data.target)
    if not targetSrc then
        TriggerClientEvent('pulse_ems:result', src, { error = 'No patient nearby.' })
        return
    end

    local discordId = getDiscordId(targetSrc)
    if not discordId then
        TriggerClientEvent('pulse_ems:result', src, { error = 'Patient has no linked identity.' })
        return
    end

    local ok = pcall(function()
        exports.pulsemdt:ApiRequest('GET', '/medical?discordId=' .. discordId, nil, function(code, res)
            if code == 200 and type(res) == 'table' then
                res.target = targetSrc
                res.allowTreatment = treatmentAllowed()
                TriggerClientEvent('pulse_ems:result', src, res)
            elseif code == 0 then
                TriggerClientEvent('pulse_ems:result', src, { error = 'Records are offline right now.' })
            else
                TriggerClientEvent('pulse_ems:result', src, { error = 'Lookup failed.' })
            end
        end)
    end)

    if not ok then
        TriggerClientEvent('pulse_ems:result', src, { error = 'Records are unavailable right now.' })
    end
end)

RegisterNetEvent('pulse_ems:addTreatment', function(data)
    local src = source
    if not RCFG.enabled or not treatmentAllowed() then return end
    if not requireDuty(src) then return end

    local targetSrc = tonumber(data and data.target)
    local details = tostring(data and data.details or ''):gsub('^%s+', ''):gsub('%s+$', '')
    if not targetSrc or details == '' then return end

    local discordId = getDiscordId(targetSrc)
    if not discordId then return end

    pcall(function()
        exports.pulsemdt:ApiWrite('POST', '/medical', {
            discordId    = discordId,
            entry_type   = 'treatment',
            details      = details,
            providerId   = getDiscordId(src),
            providerName = GetPlayerName(src),
        }, function(code)
            local ok = code == 200 or code == 0
            TriggerClientEvent('pulse_ems:treatmentSaved', src, {
                ok = ok,
                offline = code == 0,
                target = targetSrc,
            })
        end)
    end)
end)
