# pulse_ems

`pulse_ems` gives on-duty EMS and fire personnel an in-game view of a nearby patient's PulseMDT medical record and can append treatment notes.

## Requirements

- `pulsemdt`
- The patient must have a linked active character
- `pulse_notify` optional

## Installation

Start `pulse_ems` after `pulsemdt`, then configure the command, key, range, and treatment-entry policy in `config.lua`.

## Usage

- `/patient` checks the nearest patient by default.
- `H` opens the patient check by default.

Only on-duty EMS or fire roles can access records. Set `Config.AllowTreatmentEntry` to control whether users can save treatment details.
