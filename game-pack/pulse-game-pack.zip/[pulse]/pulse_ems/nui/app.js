const RESOURCE = 'pulse_ems';
let currentTarget = null;
let lastSaved = null;

const overlay = document.getElementById('overlay');
const pnameEl = document.getElementById('pname');
const notShared = document.getElementById('notShared');
const bodyEl = document.getElementById('body');
const vitalsEl = document.getElementById('vitals');
const allergiesEl = document.getElementById('allergies');
const conditionsEl = document.getElementById('conditions');
const historyEl = document.getElementById('history');
const addBlock = document.getElementById('addBlock');
const treatEl = document.getElementById('treat');

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function vital(k, val, cls) {
  const v = document.createElement('div');
  v.className = 'v' + (cls ? ' ' + cls : '');
  v.innerHTML = `<div class="k"></div><div class="val"></div>`;
  v.querySelector('.k').textContent = k;
  v.querySelector('.val').textContent = val;
  return v;
}

function fmtDate(s) {
  if (!s) return '';
  const d = new Date(s);
  if (isNaN(d)) return s;
  return d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function render(res, allowTreatment) {
  currentTarget = res.target ?? null;
  overlay.classList.remove('hidden');
  treatEl.value = '';

  if (!res.found) {
    pnameEl.textContent = 'Unidentified patient';
    notShared.textContent = 'No medical record is on file for this patient.';
    notShared.classList.remove('hidden');
    bodyEl.classList.add('hidden');
    return;
  }
  if (res.shared === false) {
    pnameEl.textContent = res.name || 'Patient';
    notShared.textContent = 'This patient has not shared their medical record with EMS.';
    notShared.classList.remove('hidden');
    bodyEl.classList.add('hidden');
    return;
  }

  notShared.classList.add('hidden');
  bodyEl.classList.remove('hidden');
  pnameEl.textContent = res.name || 'Patient';

  vitalsEl.innerHTML = '';
  vitalsEl.append(vital('Blood type', res.bloodType || 'Unknown'));
  vitalsEl.append(vital('Sex', res.gender || 'Unknown'));
  vitalsEl.append(vital('Organ donor', res.organDonor ? 'Yes' : 'No', res.organDonor ? 'donor' : ''));

  allergiesEl.textContent = res.allergies && res.allergies.trim() ? res.allergies : 'None on file.';
  conditionsEl.textContent = res.conditions && res.conditions.trim() ? res.conditions : 'None on file.';

  historyEl.innerHTML = '';
  const hist = Array.isArray(res.history) ? res.history : [];
  if (hist.length === 0) {
    const li = document.createElement('li');
    li.className = 'empty';
    li.textContent = 'No history on file.';
    historyEl.append(li);
  } else {
    for (const h of hist) {
      const li = document.createElement('li');
      const text = document.createElement('div');
      text.textContent = h.details;
      const meta = document.createElement('div');
      meta.className = 'meta';
      const who = document.createElement('span');
      who.textContent = h.provider_name || 'Unknown provider';
      const when = document.createElement('span');
      when.textContent = fmtDate(h.created_at);
      meta.append(who, when);
      li.append(text, meta);
      historyEl.append(li);
    }
  }

  addBlock.style.display = allowTreatment ? '' : 'none';
}

function close() {
  overlay.classList.add('hidden');
  currentTarget = null;
  post('close');
}

function save() {
  const details = treatEl.value.trim();
  if (details === '' || currentTarget === null) return;
  lastSaved = details;
  post('addTreatment', { target: currentTarget, details });
  treatEl.value = '';
}

function prependEntry(details, offline) {
  const empty = historyEl.querySelector('.empty');
  if (empty) empty.remove();
  const li = document.createElement('li');
  const text = document.createElement('div');
  text.textContent = details;
  const meta = document.createElement('div');
  meta.className = 'meta';
  const who = document.createElement('span');
  who.textContent = 'You';
  const when = document.createElement('span');
  when.textContent = offline ? 'Pending sync' : 'Just now';
  meta.append(who, when);
  li.append(text, meta);
  historyEl.prepend(li);
}

window.addEventListener('message', (e) => {
  const d = e.data || {};
  if (d.action === 'record') render(d.data || {}, d.allowTreatment !== false);
  if (d.action === 'treatmentSaved') {
    if (d.data && d.data.ok && lastSaved) prependEntry(lastSaved, d.data.offline);
    lastSaved = null;
  }
});

document.getElementById('save').addEventListener('click', save);
document.getElementById('done').addEventListener('click', close);
document.getElementById('x').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (overlay.classList.contains('hidden')) return;
  if (e.key === 'Escape') close();
});
