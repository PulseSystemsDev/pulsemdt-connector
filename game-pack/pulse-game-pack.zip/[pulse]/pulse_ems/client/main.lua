local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function nearestPlayerServerId()
    local me = PlayerPedId()
    local myCoords = GetEntityCoords(me)
    local closest, closestDist = nil, Config.Range + 0.0
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= me and DoesEntityExist(ped) then
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= closestDist then
                closest, closestDist = pid, dist
            end
        end
    end
    if closest then return GetPlayerServerId(closest) end
    return nil
end

local function checkPatient()
    local target = nearestPlayerServerId()
    if not target then
        notify('~y~PulseMDT EMS~s~ No patient within range.')
        return
    end
    TriggerServerEvent('pulse_ems:check', { target = target })
end

RegisterCommand(Config.Command, function()
    checkPatient()
end, false)

if Config.OpenKey then
    RegisterKeyMapping(Config.Command, 'PulseMDT EMS: Check nearest patient', 'keyboard', Config.OpenKey)
end

RegisterNUICallback('addTreatment', function(data, cb)
    if data and data.target and data.details and tostring(data.details) ~= '' then
        TriggerServerEvent('pulse_ems:addTreatment', { target = data.target, details = data.details })
    end
    cb({})
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNetEvent('pulse_ems:result', function(res)
    res = res or {}
    if res.error then
        notify('~r~PulseMDT EMS~s~ ' .. res.error)
        return
    end
    local allowTreatment = Config.AllowTreatmentEntry
    if res.allowTreatment ~= nil then allowTreatment = res.allowTreatment == true end
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'record',
        data = res,
        allowTreatment = allowTreatment,
    })
end)

RegisterNetEvent('pulse_ems:treatmentSaved', function(info)
    SendNUIMessage({ action = 'treatmentSaved', data = info or {} })
    if info and info.ok then
        notify(info.offline and '~y~PulseMDT EMS~s~ Treatment saved (will sync).' or '~g~PulseMDT EMS~s~ Treatment recorded.')
    end
end)
