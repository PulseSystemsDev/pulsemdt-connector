-- PulseMDT :: pulse_ems (EMS medical records)
--
-- Reaches the CAD through the main `pulsemdt` resource, so no API key here.
-- Configure connection settings once in pulsemdt/config.lua.
--
-- v1 is the medical-records terminal: an on-duty medic checks the nearest
-- patient's shared record and can log a treatment. It deliberately does NOT add
-- its own injury/down/revive model, so it won't clash with an ambulance job you
-- already run. Patient identity resolves through the civilian's active character
-- in the PulseMDT portal.

Config = {}

-- Command a medic types to check the nearest patient. `/patient` also works
-- with the key below.
Config.Command = 'patient'

-- Key that checks the nearest patient. Set to false to disable.
Config.OpenKey = 'H'

-- How close (metres) a patient must be to check them.
Config.Range = 3.0

-- Allow medics to log treatment entries onto the record.
Config.AllowTreatmentEntry = true
