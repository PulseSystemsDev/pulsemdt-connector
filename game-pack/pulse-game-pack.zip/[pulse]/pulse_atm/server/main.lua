local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_atm') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function transferAllowed()
    if not Config.AllowTransfer then return false end
    local v = RCFG.settings and RCFG.settings.allowTransfer
    if v == nil then return true end
    return v == true
end

local function notify(src, msg)
    TriggerClientEvent('pulse_atm:notify', src, msg)
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then
        cb(id)
        return
    end
    local discordId
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then discordId = ident:sub(9) break end
    end
    if not discordId then
        cb(nil)
        return
    end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

RegisterNetEvent('pulse_atm:open', function()
    local src = source
    if not RCFG.enabled then
        notify(src, '~y~This ATM is out of service.')
        return
    end
    getCharId(src, function(charId)
        if not charId then
            notify(src, '~r~No active character.')
            return
        end
        exports.pulsemdt:ApiRequest('GET', '/money?charId=' .. charId, nil, function(code, res)
            if code == 200 and res and res.enabled ~= false then
                TriggerClientEvent('pulse_atm:show', src, {
                    cash = res.cash or 0,
                    bank = res.bank or 0,
                    allowTransfer = transferAllowed(),
                })
            elseif code == 200 then
                notify(src, '~y~The economy is disabled on this server.')
            else
                notify(src, '~r~Banking is unavailable right now.')
            end
        end)
    end)
end)

RegisterNetEvent('pulse_atm:tx', function(data)
    local src = source
    if not RCFG.enabled then return end
    local kind = data and data.kind
    local amount = tonumber(data and data.amount)
    if (kind ~= 'deposit' and kind ~= 'withdraw') or not amount or amount <= 0 then return end
    getCharId(src, function(charId)
        if not charId then return end
        exports.pulsemdt:ApiRequest('POST', '/money', {
            charId = charId,
            move   = kind,
            amount = amount,
        }, function(code, res)
            if code == 200 and res and res.ok then
                TriggerClientEvent('pulse_atm:update', src, { ok = true, cash = res.cash, bank = res.bank })
            elseif code == 402 then
                TriggerClientEvent('pulse_atm:update', src, { ok = false, message = 'Insufficient funds.' })
            else
                TriggerClientEvent('pulse_atm:update', src, { ok = false, message = 'Transaction failed.' })
            end
        end)
    end)
end)

RegisterNetEvent('pulse_atm:transfer', function(data)
    local src = source
    if not RCFG.enabled or not transferAllowed() then return end
    local target = tonumber(data and data.target)
    local amount = tonumber(data and data.amount)
    if not target or not amount or amount <= 0 or not GetPlayerName(target) then return end

    local srcPed, tgtPed = GetPlayerPed(src), GetPlayerPed(target)
    if #(GetEntityCoords(srcPed) - GetEntityCoords(tgtPed)) > Config.TransferRange + 2.0 then
        TriggerClientEvent('pulse_atm:update', src, { ok = false, message = 'That player is too far away.' })
        return
    end

    getCharId(src, function(fromId)
        if not fromId then return end
        getCharId(target, function(toId)
            if not toId then
                TriggerClientEvent('pulse_atm:update', src, { ok = false, message = 'That player has no active character.' })
                return
            end
            exports.pulsemdt:ApiRequest('POST', '/money', {
                charId = fromId,
                transferToCharId = toId,
                amount = amount,
            }, function(code, res)
                if code == 200 and res and res.ok then
                    TriggerClientEvent('pulse_atm:update', src, { ok = true, cash = res.cash, bank = res.bank, message = 'Transfer sent.' })
                    notify(target, ('~g~You received a $%d bank transfer.'):format(amount))
                elseif code == 402 then
                    TriggerClientEvent('pulse_atm:update', src, { ok = false, message = 'Insufficient funds.' })
                else
                    TriggerClientEvent('pulse_atm:update', src, { ok = false, message = 'Transfer failed.' })
                end
            end)
        end)
    end)
end)
