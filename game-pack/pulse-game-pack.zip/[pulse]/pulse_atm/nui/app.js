const RESOURCE = 'pulse_atm';
let target = null;

const panel = document.getElementById('panel');
const bankEl = document.getElementById('bank');
const cashEl = document.getElementById('cash');
const amountEl = document.getElementById('amount');
const msgEl = document.getElementById('msg');
const transferBox = document.getElementById('transferBox');
const targetNameEl = document.getElementById('targetName');
const sendBtn = document.getElementById('send');

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function money(n) {
  return '$' + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function setBalances(cash, bank) {
  if (cash !== undefined) cashEl.textContent = money(cash);
  if (bank !== undefined) bankEl.textContent = money(bank);
}

function say(text, ok) {
  msgEl.textContent = text || '';
  msgEl.className = 'msg ' + (ok ? 'ok' : 'err');
}

function amount() {
  const v = Math.floor(Number(amountEl.value));
  return Number.isFinite(v) && v > 0 ? v : null;
}

function close() {
  panel.classList.add('hidden');
  post('close');
}

document.getElementById('deposit').addEventListener('click', () => {
  const a = amount();
  if (!a) { say('Enter an amount.', false); return; }
  say('');
  post('tx', { kind: 'deposit', amount: a });
});

document.getElementById('withdraw').addEventListener('click', () => {
  const a = amount();
  if (!a) { say('Enter an amount.', false); return; }
  say('');
  post('tx', { kind: 'withdraw', amount: a });
});

sendBtn.addEventListener('click', () => {
  const a = amount();
  if (!a) { say('Enter an amount.', false); return; }
  if (target === null) return;
  say('');
  post('transfer', { target, amount: a });
});

document.getElementById('x').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (panel.classList.contains('hidden')) return;
  if (e.key === 'Escape') close();
});

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'show') {
    const d = m.data || {};
    setBalances(d.cash, d.bank);
    amountEl.value = '';
    say('');
    target = d.target ?? null;
    const canTransfer = d.allowTransfer && target !== null;
    transferBox.classList.toggle('hidden', !d.allowTransfer);
    targetNameEl.textContent = target !== null ? (d.targetName || 'Nearby player') : 'No one nearby';
    sendBtn.disabled = !canTransfer;
    panel.classList.remove('hidden');
    setTimeout(() => amountEl.focus(), 40);
  } else if (m.action === 'update') {
    const d = m.data || {};
    if (d.ok) {
      setBalances(d.cash, d.bank);
      say(d.message || 'Done.', true);
      amountEl.value = '';
    } else {
      say(d.message || 'Transaction failed.', false);
    }
  }
});
