local atmHashes = {}
for _, model in ipairs(Config.AtmModels) do
    atmHashes[#atmHashes + 1] = joaat(model)
end

local atmOpen = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function nearestAtm()
    local pos = GetEntityCoords(PlayerPedId())
    for _, hash in ipairs(atmHashes) do
        local obj = GetClosestObjectOfType(pos.x, pos.y, pos.z, Config.Range, hash, false, false, false)
        if obj ~= 0 then return obj end
    end
    return nil
end

local function nearestPlayer()
    local me = PlayerPedId()
    local myCoords = GetEntityCoords(me)
    local closest, closestDist = nil, Config.TransferRange + 0.0
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= me and DoesEntityExist(ped) then
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= closestDist then
                closest, closestDist = pid, dist
            end
        end
    end
    if closest then return GetPlayerServerId(closest), GetPlayerName(closest) end
    return nil
end

CreateThread(function()
    while true do
        local sleep = 600
        if not atmOpen then
            local atm = nearestAtm()
            if atm then
                sleep = 0
                BeginTextCommandDisplayHelp('STRING')
                AddTextComponentSubstringPlayerName('Press ~INPUT_CONTEXT~ to use the ATM')
                EndTextCommandDisplayHelp(0, false, true, -1)
                if IsControlJustReleased(0, 38) then
                    TriggerServerEvent('pulse_atm:open')
                end
            end
        end
        Wait(sleep)
    end
end)

RegisterNetEvent('pulse_atm:show', function(data)
    atmOpen = true
    local targetId, targetName = nearestPlayer()
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'show',
        data = {
            cash = data.cash, bank = data.bank,
            allowTransfer = data.allowTransfer,
            target = targetId, targetName = targetName,
        },
    })
end)

RegisterNetEvent('pulse_atm:update', function(data)
    SendNUIMessage({ action = 'update', data = data or {} })
end)

RegisterNetEvent('pulse_atm:notify', function(msg)
    notify(msg)
end)

RegisterNUICallback('tx', function(data, cb)
    TriggerServerEvent('pulse_atm:tx', data or {})
    cb({})
end)

RegisterNUICallback('transfer', function(data, cb)
    TriggerServerEvent('pulse_atm:transfer', data or {})
    cb({})
end)

RegisterNUICallback('close', function(_, cb)
    atmOpen = false
    SetNuiFocus(false, false)
    cb({})
end)
