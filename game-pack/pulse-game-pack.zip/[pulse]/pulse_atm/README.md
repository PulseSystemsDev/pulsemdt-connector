# pulse_atm

`pulse_atm` adds interactive GTA ATM banking backed by the PulseMDT economy. Players can view balances, deposit or withdraw cash, and optionally transfer money to a nearby player.

## Requirements

- `pulsemdt`
- An active PulseMDT character; `pulse_core` is recommended
- `pulse_notify` is optional

## Installation

Keep the folder name `pulse_atm`, configure `config.lua`, and start it after its dependencies:

```cfg
ensure pulsemdt
ensure pulse_notify
ensure pulse_core
ensure pulse_atm
```

## Configuration

`Config.AtmModels` controls which world props act as ATMs. `Config.Range` controls interaction distance. Transfers can be enabled with `Config.AllowTransfer`, and `Config.TransferRange` limits how close the recipient must be.

Players interact with a configured ATM in the world. Banking is unavailable when the PulseMDT economy is disabled or the player has no active character.
