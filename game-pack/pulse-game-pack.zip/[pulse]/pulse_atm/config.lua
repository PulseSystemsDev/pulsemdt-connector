-- PulseMDT :: pulse_atm (ATM & banking)
--
-- Deposit, withdraw, and transfer at any ATM prop. Money lives in the CAD and
-- requires the Economy feature (web dashboard, Features page). Reaches the CAD
-- through the main `pulsemdt` resource, so no API key here.

Config = {}

-- Prop models that count as an ATM.
Config.AtmModels = {
    'prop_atm_01',
    'prop_atm_02',
    'prop_atm_03',
    'prop_fleeca_atm',
}

-- Metres a player can stand from an ATM to use it.
Config.Range = 1.6

-- Allow wiring bank money to a nearby player. Can also be turned off from the
-- dashboard's Scripts page.
Config.AllowTransfer = true

-- Metres within which a transfer recipient must stand.
Config.TransferRange = 3.0
