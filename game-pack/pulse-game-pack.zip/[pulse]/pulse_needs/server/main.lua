local needsState = {}

local GROUPS = {}
for _, g in ipairs(Config.Groups) do GROUPS[#GROUPS + 1] = g.key end

local CATALOG_BY_KEY = {}
for _, item in ipairs(Config.Catalog) do CATALOG_BY_KEY[item.key] = item end

local GROUP_BY_KEY = {}
for _, g in ipairs(Config.Groups) do GROUP_BY_KEY[g.key] = g end

local RCFG = { enabled = true, settings = {} }

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_needs') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function setting(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    if v == nil then return fallback end
    return v
end
local function num(key, fallback) return tonumber(setting(key, fallback)) or fallback end
local function moduleEnabled() return RCFG.enabled ~= false end

local function effectiveStations()
    local byGroup = {}
    for _, key in ipairs(GROUPS) do byGroup[key] = {} end

    local raw = RCFG.settings and RCFG.settings.stationsJson
    local source = nil
    if type(raw) == 'string' and raw ~= '' then
        local ok, parsed = pcall(json.decode, raw)
        if ok and type(parsed) == 'table' then source = parsed end
    end
    if type(source) == 'table' then
        for _, s in ipairs(source) do
            if byGroup[s.job] and tonumber(s.x) then
                byGroup[s.job][#byGroup[s.job] + 1] = {
                    label = tostring(s.label or 'Vendor'),
                    x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                    heading = tonumber(s.heading) or 0.0,
                }
            end
        end
    end
    for _, key in ipairs(GROUPS) do
        if #byGroup[key] == 0 then
            for _, s in ipairs(Config.Stations[key] or {}) do
                byGroup[key][#byGroup[key] + 1] = s
            end
        end
    end
    return byGroup
end

local function broadcastStations(target)
    local byGroup = effectiveStations()
    local groups = {}
    local blips = {}
    for _, g in ipairs(Config.Groups) do
        groups[#groups + 1] = { key = g.key, label = g.label, items = g.items }
        blips[g.key] = g.blip
    end
    TriggerClientEvent('pulse_needs:stations', target or -1, {
        groups = groups, stations = byGroup, blips = blips,
        radius = Config.StationRadius, catalog = Config.Catalog,
    })
end

RegisterNetEvent('pulse_needs:requestStations', function()
    broadcastStations(source)
end)

local function notify(src, msg)
    TriggerClientEvent('pulse_needs:notify', src, msg)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local function nearAnyStation(src, group)
    local ped = GetPlayerPed(src)
    if ped == 0 then return false end
    local pos = GetEntityCoords(ped)
    for _, st in ipairs(effectiveStations()[group] or {}) do
        if #(pos - vector3(st.x, st.y, st.z)) <= Config.StationRadius then return true end
    end
    return false
end

local function pushHud(src)
    local st = needsState[src]
    if not st then return end
    TriggerClientEvent('pulse_needs:hud', src, { hunger = st.hunger, thirst = st.thirst })
end

local function pushStash(src)
    local st = needsState[src]
    if not st then return end
    TriggerClientEvent('pulse_needs:stash', src, { items = st.items })
end

RegisterNetEvent('pulse_needs:ready', function()
    local src = source
    getCharId(src, function(charId)
        if not charId then return end
        exports.pulsemdt:ApiRequest('GET', '/needs?charId=' .. charId, nil, function(code, res)
            local hunger, thirst, items = 100, 100, {}
            if code == 200 and res then
                hunger = tonumber(res.hunger) or 100
                thirst = tonumber(res.thirst) or 100
                for _, it in ipairs(res.items or {}) do
                    items[it.item_key] = tonumber(it.quantity) or 0
                end
            end
            needsState[src] = {
                charId = charId, hunger = hunger, thirst = thirst, items = items,
                lastSync = GetGameTimer(), lastNotifyHunger = GetGameTimer(), lastNotifyThirst = GetGameTimer(),
            }
            pushHud(src)
        end)
    end)
end)

CreateThread(function()
    while true do
        Wait(1000)
        if moduleEnabled() then
            local now = GetGameTimer()
            local hungerPerSec = num('hungerDecayPerMinute', Config.HungerDecayPerMinute) / 60.0
            local thirstPerSec = num('thirstDecayPerMinute', Config.ThirstDecayPerMinute) / 60.0
            for src, st in pairs(needsState) do
                if GetPlayerName(src) then
                    st.hunger = math.max(0, st.hunger - hungerPerSec)
                    st.thirst = math.max(0, st.thirst - thirstPerSec)

                    if st.hunger <= 0 or st.thirst <= 0 then
                        local drain = Config.StarveHealthDrainPerMinute / 60.0
                        local ped = GetPlayerPed(src)
                        if ped ~= 0 then
                            local health = GetEntityHealth(ped)
                            if health > 0 then SetEntityHealth(ped, math.max(0, math.floor(health - drain))) end
                        end
                    end

                    pushHud(src)

                    local lowThreshold = num('lowThreshold', Config.LowThreshold)
                    local notifyMs = num('notifyIntervalMinutes', Config.NotifyIntervalMinutes) * 60000
                    if st.hunger <= lowThreshold and now - st.lastNotifyHunger >= notifyMs then
                        st.lastNotifyHunger = now
                        notify(src, '~y~Hungry~s~ You should find something to eat.')
                    end
                    if st.thirst <= lowThreshold and now - st.lastNotifyThirst >= notifyMs then
                        st.lastNotifyThirst = now
                        notify(src, '~y~Thirsty~s~ You should find something to drink.')
                    end

                    if now - st.lastSync >= (Config.SyncIntervalSeconds * 1000) then
                        st.lastSync = now
                        local charId, hunger, thirst = st.charId, st.hunger, st.thirst
                        pcall(function()
                            exports.pulsemdt:ApiRequest('POST', '/needs', { action = 'sync', charId = charId, hunger = hunger, thirst = thirst }, nil)
                        end)
                    end
                else
                    needsState[src] = nil
                end
            end
        end
    end
end)

RegisterNetEvent('pulse_needs:openStash', function()
    pushStash(source)
end)

RegisterNetEvent('pulse_needs:buy', function(data)
    local src = source
    if not moduleEnabled() then notify(src, '~y~Vendors are disabled on this server.') return end
    local st = needsState[src]
    if not st then notify(src, '~r~Not ready yet, try again in a moment.') return end

    local group = data and data.group
    local itemKey = data and data.itemKey
    local groupMeta = GROUP_BY_KEY[group]
    local item = CATALOG_BY_KEY[itemKey]
    if not groupMeta or not item then notify(src, '~r~Unknown item.') return end

    local sellable = false
    for _, k in ipairs(groupMeta.items or {}) do if k == itemKey then sellable = true break end end
    if not sellable then notify(src, '~r~That vendor does not sell that.') return end
    if not nearAnyStation(src, group) then notify(src, '~r~You are not at that vendor.') return end

    local currentQty = st.items[itemKey] or 0
    local distinctCount = 0
    for _, qty in pairs(st.items) do if qty > 0 then distinctCount = distinctCount + 1 end end
    if currentQty >= Config.MaxQuantityPerItem then
        notify(src, '~y~You are carrying as much of that as you can.')
        return
    end
    if currentQty == 0 and distinctCount >= Config.MaxDistinctItems then
        notify(src, '~y~You cannot carry another kind of item right now.')
        return
    end

    exports.pulsemdt:ApiRequest('POST', '/money', {
        charId = st.charId, account = 'bank', amount = -item.price,
        reason = 'Bought ' .. item.label,
    }, function(mcode, mres)
        local charged = mcode == 200 and mres and mres.ok
        local free = mcode == 403
        if not charged and not free then
            if mcode == 402 then
                notify(src, ('~r~You need $%d to buy %s.'):format(item.price, item.label))
            else
                notify(src, '~r~The vendor is unavailable right now.')
            end
            return
        end
        st.items[itemKey] = currentQty + 1
        pcall(function()
            exports.pulsemdt:ApiRequest('POST', '/needs', { action = 'addItem', charId = st.charId, itemKey = itemKey, quantity = 1 }, nil)
        end)
        notify(src, ('~g~Bought~s~ %s.'):format(item.label))
        pushStash(src)
    end)
end)

RegisterNetEvent('pulse_needs:consume', function(data)
    local src = source
    local st = needsState[src]
    if not st then return end
    local itemKey = data and data.itemKey
    local item = CATALOG_BY_KEY[itemKey]
    local qty = st.items[itemKey] or 0
    if not item or qty <= 0 then notify(src, '~y~You are not carrying that.') return end

    st.items[itemKey] = qty - 1
    if item.restore == 'hunger' then
        st.hunger = math.min(100, st.hunger + item.amount)
    else
        st.thirst = math.min(100, st.thirst + item.amount)
    end
    pushHud(src)
    pushStash(src)
    notify(src, ('~g~Consumed~s~ %s.'):format(item.label))
    pcall(function()
        exports.pulsemdt:ApiRequest('POST', '/needs', { action = 'consumeItem', charId = st.charId, itemKey = itemKey }, nil)
    end)
end)

AddEventHandler('playerDropped', function()
    local src = source
    local st = needsState[src]
    if st then
        local charId, hunger, thirst = st.charId, st.hunger, st.thirst
        pcall(function()
            exports.pulsemdt:ApiRequest('POST', '/needs', { action = 'sync', charId = charId, hunger = hunger, thirst = thirst }, nil)
        end)
    end
    needsState[src] = nil
end)
