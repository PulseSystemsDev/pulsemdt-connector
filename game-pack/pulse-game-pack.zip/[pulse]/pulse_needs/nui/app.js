const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'pulse_needs';

const hungerFill = document.getElementById('hungerFill');
const thirstFill = document.getElementById('thirstFill');

const vendor = document.getElementById('vendor');
const vTitle = document.getElementById('vTitle');
const vItems = document.getElementById('vItems');
const vClose = document.getElementById('vClose');

const stash = document.getElementById('stash');
const sItems = document.getElementById('sItems');
const sEmpty = document.getElementById('sEmpty');
const sClose = document.getElementById('sClose');

function post(name, body) {
  return fetch(`https://${resource}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  });
}

vClose.addEventListener('click', () => { vendor.classList.add('hidden'); post('closeVendor'); });
sClose.addEventListener('click', () => { stash.classList.add('hidden'); post('closeStash'); });

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action === 'hud') {
    hungerFill.style.width = `${Math.max(0, Math.min(100, data.hunger))}%`;
    thirstFill.style.width = `${Math.max(0, Math.min(100, data.thirst))}%`;
  } else if (data.action === 'vendor') {
    vTitle.textContent = data.label || 'Vendor';
    vItems.innerHTML = '';
    (data.items || []).forEach((item) => {
      const row = document.createElement('div');
      row.className = 'v-item';
      row.innerHTML = `
        <div>
          <div class="name">${item.label}</div>
          <div class="sub">$${item.price} &middot; +${item.amount} ${item.restore}</div>
        </div>
        <button type="button">Buy</button>
      `;
      row.querySelector('button').addEventListener('click', () => {
        post('buyItem', { group: data.group, itemKey: item.key });
      });
      vItems.appendChild(row);
    });
    vendor.classList.remove('hidden');
  } else if (data.action === 'stash') {
    sItems.innerHTML = '';
    const catalogByKey = {};
    (data.catalog || []).forEach((item) => { catalogByKey[item.key] = item; });
    const owned = Object.entries(data.items || {}).filter(([, qty]) => qty > 0);
    sEmpty.classList.toggle('hidden', owned.length > 0);
    owned.forEach(([key, qty]) => {
      const item = catalogByKey[key];
      if (!item) return;
      const row = document.createElement('div');
      row.className = 'v-item';
      const verb = item.restore === 'hunger' ? 'Eat' : 'Drink';
      row.innerHTML = `
        <div>
          <div class="name">${item.label} &times;${qty}</div>
          <div class="sub">+${item.amount} ${item.restore}</div>
        </div>
        <button type="button">${verb}</button>
      `;
      row.querySelector('button').addEventListener('click', () => {
        post('consumeItem', { itemKey: key });
      });
      sItems.appendChild(row);
    });
    stash.classList.remove('hidden');
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!vendor.classList.contains('hidden')) { vendor.classList.add('hidden'); post('closeVendor'); }
  if (!stash.classList.contains('hidden')) { stash.classList.add('hidden'); post('closeStash'); }
});
