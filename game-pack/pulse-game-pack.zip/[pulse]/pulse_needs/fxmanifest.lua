fx_version 'cerulean'
game 'gta5'

name 'pulse_needs'
description 'PulseMDT - Hunger, thirst, and a food/drink carry-slot'
version '0.1.0'
author 'PulseMDT'
url 'https://pulsemdt.com'

dependency 'pulsemdt'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
}

lua54 'yes'
