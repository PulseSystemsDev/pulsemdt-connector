local stationData = { groups = {}, stations = {}, blips = {}, radius = 2.5, catalog = {} }
local groupByKey = {}
local catalogByKey = {}
local stationBlips = {}
local menuOpen = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_needs:notify', function(msg)
    if msg then notify(msg) end
end)

RegisterNetEvent('pulse_needs:hud', function(data)
    SendNUIMessage({ action = 'hud', hunger = data.hunger, thirst = data.thirst })
end)

RegisterNetEvent('pulse_needs:stash', function(data)
    SendNUIMessage({ action = 'stash', items = data.items, catalog = stationData.catalog })
end)

local function rebuildStationBlips()
    for _, b in ipairs(stationBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    stationBlips = {}
    for key, list in pairs(stationData.stations or {}) do
        local meta = stationData.blips and stationData.blips[key]
        if meta then
            for _, st in ipairs(list) do
                local b = AddBlipForCoord(st.x, st.y, st.z)
                SetBlipSprite(b, meta.sprite or 106)
                SetBlipColour(b, meta.color or 47)
                SetBlipScale(b, 0.7)
                SetBlipAsShortRange(b, true)
                BeginTextCommandSetBlipName('STRING')
                AddTextComponentSubstringPlayerName(meta.label or key)
                EndTextCommandSetBlipName(b)
                stationBlips[#stationBlips + 1] = b
            end
        end
    end
end

RegisterNetEvent('pulse_needs:stations', function(payload)
    if type(payload) ~= 'table' then return end
    stationData = payload
    groupByKey = {}
    for _, g in ipairs(stationData.groups or {}) do groupByKey[g.key] = g end
    catalogByKey = {}
    for _, item in ipairs(stationData.catalog or {}) do catalogByKey[item.key] = item end
    rebuildStationBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_needs:requestStations')
    TriggerServerEvent('pulse_needs:ready')
end)

local function openVendor(groupKey)
    local group = groupByKey[groupKey]
    if not group then return end
    local items = {}
    for _, key in ipairs(group.items or {}) do
        local item = catalogByKey[key]
        if item then items[#items + 1] = item end
    end
    menuOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'vendor', group = groupKey, label = group.label, items = items })
end

RegisterNUICallback('buyItem', function(data, cb)
    TriggerServerEvent('pulse_needs:buy', { group = data.group, itemKey = data.itemKey })
    cb({})
end)

RegisterNUICallback('consumeItem', function(data, cb)
    TriggerServerEvent('pulse_needs:consume', { itemKey = data.itemKey })
    cb({})
end)

RegisterNUICallback('closeVendor', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNUICallback('closeStash', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

CreateThread(function()
    while true do
        local sleep = 900
        if not menuOpen then
            local pos = GetEntityCoords(PlayerPedId())
            for key, list in pairs(stationData.stations or {}) do
                local group = groupByKey[key]
                for _, st in ipairs(list) do
                    local dist = #(pos - vector3(st.x, st.y, st.z))
                    if dist < 30.0 then
                        sleep = 0
                        DrawMarker(2, st.x, st.y, st.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            0.4, 0.4, 0.4, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                        if dist <= (stationData.radius or 2.5) and group then
                            BeginTextCommandDisplayHelp('STRING')
                            AddTextComponentSubstringPlayerName(('Press ~INPUT_CONTEXT~ : %s'):format(group.label or key))
                            EndTextCommandDisplayHelp(0, false, true, -1)
                            if IsControlJustReleased(0, 38) then
                                openVendor(key)
                                Wait(400)
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

RegisterCommand(Config.StashCommand, function()
    if menuOpen then return end
    menuOpen = true
    SetNuiFocus(true, true)
    TriggerServerEvent('pulse_needs:openStash')
end, false)

if Config.StashKey then
    RegisterKeyMapping(Config.StashCommand, 'Open food & drink stash', 'keyboard', Config.StashKey)
end
