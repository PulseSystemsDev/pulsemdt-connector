-- PulseMDT :: pulse_needs (Hunger, thirst, and a food/drink carry-slot)
--
-- Hunger and thirst decay passively and live on the character, so they
-- survive a reconnect instead of resetting. Reaches the CAD through the main
-- `pulsemdt` resource, so no API key here.
--
-- There is no general inventory here on purpose: buying food or drink adds it
-- to a small carry-slot (capped by MaxDistinctItems/MaxQuantityPerItem below),
-- not a full item system, so this stays out of the way of whatever inventory
-- your server already runs.
--
-- Vendor locations are dashboard-editable from the Scripts page ("Food &
-- drink vendors"), the same mechanism pulse_jobs, pulse_dutystations, and
-- pulse_jailing use, or replace the defaults below directly.

Config = {}

-- Vendor groups. `items` lists which Config.Catalog keys that vendor type sells.
Config.Groups = {
    { key = 'food', label = 'Food Stall', items = { 'sandwich', 'burger' },
      blip = { sprite = 106, color = 47, label = 'Food Stall' } },
    { key = 'drink', label = 'Water Cooler', items = { 'water_bottle', 'soda' },
      blip = { sprite = 361, color = 3, label = 'Water Cooler' } },
}

-- Item catalog. `restore` is 'hunger' or 'thirst'; `amount` is how many points
-- eating/drinking it restores (0-100 scale).
Config.Catalog = {
    { key = 'water_bottle', label = 'Water Bottle', restore = 'thirst', amount = 35, price = 8 },
    { key = 'soda',         label = 'Soda',         restore = 'thirst', amount = 25, price = 6 },
    { key = 'sandwich',     label = 'Sandwich',     restore = 'hunger', amount = 40, price = 12 },
    { key = 'burger',       label = 'Burger',       restore = 'hunger', amount = 55, price = 18 },
}

-- Default vendors (replaced per group by dashboard stations when any exist).
Config.Stations = {
    food = {
        { label = 'Legion Square Food Stall', x = 195.8, y = -933.8, z = 30.7, heading = 90.0 },
    },
    drink = {
        { label = 'Legion Square Water Cooler', x = 202.0, y = -933.8, z = 30.7, heading = 90.0 },
    },
}

Config.StationRadius = 2.5

-- Points lost per minute. 100 -> 0 in about 100/rate minutes.
Config.HungerDecayPerMinute = 0.6
Config.ThirstDecayPerMinute = 0.9

-- Notify (and repeat) once a stat drops to or below this.
Config.LowThreshold = 25
Config.NotifyIntervalMinutes = 5

-- Health lost per minute while a stat sits at 0.
Config.StarveHealthDrainPerMinute = 2.0

-- Carry-slot caps: a stash, not an inventory.
Config.MaxDistinctItems = 3
Config.MaxQuantityPerItem = 5

-- Command/key to open the stash and eat or drink what you're carrying.
Config.StashCommand = 'stash'
Config.StashKey = false

-- How often (seconds) hunger/thirst are checkpointed to the CAD.
Config.SyncIntervalSeconds = 60
