# pulse_needs

`pulse_needs` adds persistent hunger and thirst, food/drink vendors, a compact carry stash, consumption effects, low-needs warnings, and optional starvation damage.

## Requirements

- `pulsemdt` with characters and economy enabled for purchases
- `pulse_core` recommended
- `pulse_notify` optional

## Installation

Configure vendors, catalog entries, decay, limits, and synchronization in `config.lua`, then start `pulse_needs` after `pulsemdt`.

## Usage and configuration

- `/stash` opens carried food and drink by default.
- `Config.StashKey` can enable a shortcut.
- `Config.Catalog` defines prices and restored hunger/thirst.
- Capacity, decay, warning threshold, health drain, and sync interval are configurable.

Station and selected behavior settings may be managed from the PulseMDT Scripts page.
