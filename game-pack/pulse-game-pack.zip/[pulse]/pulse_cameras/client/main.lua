local spawnedProps = {}
local placing = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function clearProps()
    for _, obj in ipairs(spawnedProps) do
        if DoesEntityExist(obj) then DeleteObject(obj) end
    end
    spawnedProps = {}
end

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local deadline = GetGameTimer() + 8000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return nil end
        Wait(25)
    end
    return hash
end

RegisterNetEvent('pulse_cameras:sync', function(cameras)
    clearProps()
    for _, cam in ipairs(cameras or {}) do
        local model = Config.Props[cam.type] or Config.Props.anpr
        local hash = loadModel(model)
        if hash then
            local obj = CreateObjectNoOffset(hash, cam.x, cam.y, cam.z, false, false, false)
            SetEntityHeading(obj, cam.heading or 0.0)
            FreezeEntityPosition(obj, true)
            SetModelAsNoLongerNeeded(hash)
            spawnedProps[#spawnedProps + 1] = obj
        end
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then clearProps() end
end)

local function groundAim()
    local camCoord = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local radX, radZ = math.rad(camRot.x), math.rad(camRot.z)
    local cosX = math.abs(math.cos(radX))
    local dir = vector3(-math.sin(radZ) * cosX, math.cos(radZ) * cosX, math.sin(radX))
    local dest = camCoord + dir * 30.0
    local ray = StartShapeTestRay(camCoord.x, camCoord.y, camCoord.z, dest.x, dest.y, dest.z, 1, PlayerPedId(), 0)
    local _, hit, endCoords = GetShapeTestResult(ray)
    if hit == 1 then return endCoords end
    return nil
end

RegisterNetEvent('pulse_cameras:startPlacement', function(data)
    if placing then return end
    local hash = loadModel(data.prop)
    if not hash then
        notify('~r~PulseMDT~s~ Camera prop model failed to load.')
        return
    end
    placing = true
    local heading = 0.0
    local ghost = nil
    notify('~b~PulseMDT~s~ Aim to position. ~y~LEFT/RIGHT~s~ rotate, ~g~E~s~ place, ~r~BACKSPACE~s~ cancel.')

    CreateThread(function()
        while placing do
            Wait(0)
            local target = groundAim()
            if target then
                if not ghost then
                    ghost = CreateObjectNoOffset(hash, target.x, target.y, target.z, false, false, false)
                    SetEntityAlpha(ghost, 160, false)
                    SetEntityCollision(ghost, false, false)
                    FreezeEntityPosition(ghost, true)
                end
                SetEntityCoordsNoOffset(ghost, target.x, target.y, target.z, false, false, false)
                PlaceObjectOnGroundProperly(ghost)
                SetEntityHeading(ghost, heading)

                if IsControlPressed(0, 174) then heading = (heading - 1.2) % 360 end
                if IsControlPressed(0, 175) then heading = (heading + 1.2) % 360 end

                if IsControlJustPressed(0, 38) then -- E
                    local pos = GetEntityCoords(ghost)
                    TriggerServerEvent('pulse_cameras:place', {
                        type = data.type, name = data.name,
                        x = pos.x, y = pos.y, z = pos.z, heading = heading,
                    })
                    placing = false
                end
            end
            if IsControlJustPressed(0, 177) then -- BACKSPACE
                placing = false
                notify('~y~PulseMDT~s~ Placement cancelled.')
            end
        end
        if ghost and DoesEntityExist(ghost) then DeleteObject(ghost) end
        SetModelAsNoLongerNeeded(hash)
    end)
end)

RegisterNetEvent('pulse_cameras:alert', function(hit)
    if not hit then return end
    local head = hit.camType == 'speed' and '~y~SPEED CAMERA~s~' or '~r~ANPR CAMERA~s~'
    notify(('%s\n%s\nPlate ~b~%s~s~ - %s'):format(head, hit.camera or '', hit.plate or '', hit.reason or ''))
    PlaySoundFrontend(-1, 'Event_Start_Text', 'GTAO_FM_Events_Soundset', false)

    if hit.x then
        local blip = AddBlipForCoord(hit.x + 0.0, hit.y + 0.0, (hit.z or 30.0) + 0.0)
        SetBlipSprite(blip, Config.Blip.sprite)
        SetBlipColour(blip, Config.Blip.color)
        SetBlipScale(blip, Config.Blip.scale + 0.0)
        SetBlipAsShortRange(blip, false)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName('Camera hit: ' .. (hit.plate or ''))
        EndTextCommandSetBlipName(blip)
        SetTimeout(Config.Blip.duration * 1000, function()
            if DoesBlipExist(blip) then RemoveBlip(blip) end
        end)
    end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1000)
    TriggerServerEvent('pulse_cameras:requestSync')
end)
