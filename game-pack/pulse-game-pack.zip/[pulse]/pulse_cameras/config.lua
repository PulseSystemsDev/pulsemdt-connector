-- PulseMDT :: pulse_cameras (Fixed ANPR & speed cameras)
--
-- Physical cameras placed in the world by an admin. ANPR cameras run every
-- passing plate against BOLOs, warrants, and stolen flags; speed cameras clock
-- passing vehicles. Hits alert AVAILABLE on-duty officers and are logged to
-- the CAD. Camera positions persist in cameras.json inside this resource.
--
-- Reaches the CAD through the main `pulsemdt` resource, so no API key here.
--
-- Admin commands (require the ace permission below):
--   /camadd <anpr|speed> [name]   place a new camera where you are aiming
--   /camlist                      list cameras in chat
--   /camremove <id>               remove a camera
--
-- Placement controls: LEFT/RIGHT arrows rotate, E confirm, BACKSPACE cancel.
--
-- Grant an admin access in server.cfg:
--   add_ace group.admin pulse.cameras allow

Config = {}

-- Ace permission required for the admin commands.
Config.AcePermission = 'pulse.cameras'

-- Prop models used for placed cameras.
Config.Props = {
    anpr  = 'prop_cctv_pole_01a',
    speed = 'prop_cctv_pole_04',
}

-- Metres around a camera in which vehicles are scanned.
Config.Radius = 30.0

-- Seconds between scan sweeps.
Config.ScanInterval = 4

-- Speed cameras: limit and units. Vehicles above limit + tolerance are flagged.
Config.SpeedUnits = 'mph'          -- 'mph' or 'kmh'
Config.SpeedLimit = 80
Config.SpeedTolerance = 5

-- Seconds before the same plate can trigger the same camera again.
Config.RehitCooldown = 300

-- Seconds a plate's ANPR result (clean or hit) is cached before rechecking,
-- to keep CAD traffic low on busy roads.
Config.PlateCacheTime = 300

-- Map blip shown to alerted officers.
Config.Blip = {
    sprite   = 184,
    color    = 1,
    scale    = 0.9,
    duration = 60,
}
