local cameras    = {}
local nextId     = 1
local recentHits = {}   -- "camId:plate" -> os.time of last alert
local plateCache = {}   -- plate -> { at = os.time, hit = table|false }

local SPEED_FACTOR = Config.SpeedUnits == 'kmh' and 3.6 or 2.236936

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_cameras') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)
local function setting(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    if v == nil then return fallback end
    return v
end

local function loadCameras()
    local raw = LoadResourceFile(GetCurrentResourceName(), 'cameras.json')
    if not raw then return end
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == 'table' then
        cameras = data
        for _, cam in ipairs(cameras) do
            if cam.id >= nextId then nextId = cam.id + 1 end
        end
    end
end

local function saveCameras()
    SaveResourceFile(GetCurrentResourceName(), 'cameras.json', json.encode(cameras), -1)
end

local function syncCameras(target)
    TriggerClientEvent('pulse_cameras:sync', target or -1, cameras)
end

loadCameras()

RegisterNetEvent('pulse_cameras:requestSync', function()
    syncCameras(source)
end)

local function isCameraAdmin(src)
    return IsPlayerAceAllowed(src, Config.AcePermission)
end

RegisterCommand('camadd', function(src, args)
    if src == 0 or not isCameraAdmin(src) then return end
    local camType = args[1] and args[1]:lower() or ''
    if camType ~= 'anpr' and camType ~= 'speed' then
        TriggerClientEvent('chat:addMessage', src, { args = { '^3PulseMDT', 'Usage: /camadd <anpr|speed> [name]' } })
        return
    end
    local name = table.concat(args, ' ', 2)
    if name == '' then name = camType:upper() .. ' Camera' end
    TriggerClientEvent('pulse_cameras:startPlacement', src, {
        type = camType,
        name = name,
        prop = Config.Props[camType],
    })
end, false)

RegisterNetEvent('pulse_cameras:place', function(data)
    local src = source
    if not isCameraAdmin(src) then return end
    if type(data) ~= 'table' or not tonumber(data.x) then return end
    local camType = data.type == 'speed' and 'speed' or 'anpr'
    local cam = {
        id      = nextId,
        type    = camType,
        name    = tostring(data.name or 'Camera'):sub(1, 60),
        x       = tonumber(data.x),
        y       = tonumber(data.y),
        z       = tonumber(data.z),
        heading = tonumber(data.heading) or 0.0,
    }
    nextId = nextId + 1
    cameras[#cameras + 1] = cam
    saveCameras()
    syncCameras()
    TriggerClientEvent('chat:addMessage', src, { args = { '^2PulseMDT', ('Camera #%d "%s" placed.'):format(cam.id, cam.name) } })
end)

RegisterCommand('camlist', function(src)
    if src == 0 or not isCameraAdmin(src) then return end
    if #cameras == 0 then
        TriggerClientEvent('chat:addMessage', src, { args = { '^3PulseMDT', 'No cameras placed.' } })
        return
    end
    for _, cam in ipairs(cameras) do
        TriggerClientEvent('chat:addMessage', src, {
            args = { '^3PulseMDT', ('#%d [%s] %s (%.0f, %.0f)'):format(cam.id, cam.type:upper(), cam.name, cam.x, cam.y) }
        })
    end
end, false)

RegisterCommand('camremove', function(src, args)
    if src == 0 or not isCameraAdmin(src) then return end
    local id = tonumber(args[1])
    if not id then
        TriggerClientEvent('chat:addMessage', src, { args = { '^3PulseMDT', 'Usage: /camremove <id>' } })
        return
    end
    for i, cam in ipairs(cameras) do
        if cam.id == id then
            table.remove(cameras, i)
            saveCameras()
            syncCameras()
            TriggerClientEvent('chat:addMessage', src, { args = { '^2PulseMDT', ('Camera #%d removed.'):format(id) } })
            return
        end
    end
    TriggerClientEvent('chat:addMessage', src, { args = { '^1PulseMDT', ('No camera with id %d.'):format(id) } })
end, false)

local function alertOfficers(cam, plate, reason, speed)
    local ok, officers = pcall(function()
        return exports.pulsemdt:GetAvailableOfficers()
    end)
    if not ok or type(officers) ~= 'table' then return end
    for _, officer in ipairs(officers) do
        TriggerClientEvent('pulse_cameras:alert', officer, {
            camera = cam.name,
            camType = cam.type,
            plate  = plate,
            reason = reason,
            speed  = speed,
            units  = Config.SpeedUnits,
            x = cam.x, y = cam.y, z = cam.z,
        })
    end
    exports.pulsemdt:ApiWrite('POST', '/logs', {
        event   = 'camera_hit',
        details = ('%s camera "%s" flagged plate %s: %s'):format(cam.type:upper(), cam.name, plate, reason),
    }, nil)
end

local function encodePlate(plate)
    return (plate:gsub('[^%w]', function(c) return string.format('%%%02X', string.byte(c)) end))
end

local function checkPlate(cam, plate)
    local now = os.time()
    local cached = plateCache[plate]
    if cached and (now - cached.at) < Config.PlateCacheTime then
        if cached.hit then alertOfficers(cam, plate, cached.hit) end
        return
    end
    exports.pulsemdt:ApiRequest('GET', '/ncic?plate=' .. encodePlate(plate), nil, function(code, res)
        if code ~= 200 or type(res) ~= 'table' then return end
        local reason = nil
        if res.bolo and res.bolo ~= json.null then
            reason = 'BOLO: ' .. (res.bolo.description or 'flagged')
        elseif res.warrants and #res.warrants > 0 then
            reason = 'Registered owner has an active warrant'
        elseif res.vehicle and res.vehicle ~= json.null and res.vehicle.status == 'stolen' then
            reason = 'Vehicle reported stolen'
        end
        plateCache[plate] = { at = now, hit = reason or false }
        if reason then alertOfficers(cam, plate, reason) end
    end)
end

CreateThread(function()
    while true do
        Wait(Config.ScanInterval * 1000)
        if #cameras > 0 and RCFG.enabled then
            local now = os.time()
            local speedLimit = tonumber(setting('speedLimit', Config.SpeedLimit)) or Config.SpeedLimit
            local tolerance  = tonumber(setting('speedTolerance', Config.SpeedTolerance)) or Config.SpeedTolerance
            local rehit      = tonumber(setting('rehitCooldownSeconds', Config.RehitCooldown)) or Config.RehitCooldown
            local vehicles = GetAllVehicles()
            for _, cam in ipairs(cameras) do
                local camPos = vector3(cam.x, cam.y, cam.z)
                for _, veh in ipairs(vehicles) do
                    if DoesEntityExist(veh) then
                        local pos = GetEntityCoords(veh)
                        if #(pos - camPos) <= Config.Radius then
                            local plate = (GetVehicleNumberPlateText(veh) or ''):gsub('%s+', ''):upper()
                            if plate ~= '' then
                                local key = cam.id .. ':' .. plate
                                if not recentHits[key] or (now - recentHits[key]) >= rehit then
                                    recentHits[key] = now
                                    if cam.type == 'speed' then
                                        local v = GetEntityVelocity(veh)
                                        local speed = math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) * SPEED_FACTOR
                                        if speed > (speedLimit + tolerance) then
                                            alertOfficers(cam, plate,
                                                ('Speeding: %.0f %s in a %d zone'):format(speed, Config.SpeedUnits, speedLimit),
                                                math.floor(speed))
                                        end
                                    else
                                        checkPlate(cam, plate)
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)
