# pulse_cameras

`pulse_cameras` adds persistent fixed ANPR and speed cameras. ANPR checks plates against PulseMDT records, while speed cameras alert available on-duty officers when configured limits are exceeded.

## Requirements

- `pulsemdt`
- OneSync recommended
- `pulse_notify` optional

## Installation

Start `pulse_cameras` after `pulsemdt`. Grant camera administrators access in `server.cfg`:

```cfg
add_ace group.admin pulse.cameras allow
ensure pulse_cameras
```

## Commands

- `/camadd <anpr|speed> [name]` places a camera.
- `/camlist` lists cameras.
- `/camremove <id>` removes a camera.

Use left/right arrows to rotate during placement, `E` to confirm, and Backspace to cancel. Configure props, scan radius, intervals, speed units, limit, tolerance, cooldowns, and alert blips in `config.lua`. Camera placements are stored locally in `cameras.json`.
