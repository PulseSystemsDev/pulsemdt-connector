local keyCache = {}
local hotwired = {}
local airLockout = {}
local cruiseActive = false
local busy = false
local remoteEnabled = true
local remoteLockpickSeconds = nil
local remoteHotwireSeconds = nil
local remoteFailAlarmChance = nil

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_vehiclekeys:notify', function(msg)
    if msg then notify(msg) end
end)

RegisterNetEvent('pulse_vehiclekeys:remoteConfig', function(cfg)
    cfg = cfg or {}
    remoteEnabled = cfg.enabled ~= false
    remoteLockpickSeconds = tonumber(cfg.lockpickSeconds)
    remoteHotwireSeconds = tonumber(cfg.hotwireSeconds)
    remoteFailAlarmChance = tonumber(cfg.failAlarmChance)
    if not remoteEnabled then
        keyCache = {}
        hotwired = {}
        cruiseActive = false
        for _, veh in ipairs(GetGamePool('CVehicle')) do
            if DoesEntityExist(veh) then SetVehicleDoorsLocked(veh, 1) end
        end
    end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    TriggerServerEvent('pulse_vehiclekeys:requestConfig')
end)

local function plateOf(veh)
    return (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', '')
end

local function requestKeyCheck(plate)
    if not remoteEnabled then return end
    local cached = keyCache[plate]
    if cached and (GetGameTimer() - cached.checkedAt) < 15000 then return end
    TriggerServerEvent('pulse_vehiclekeys:checkKey', plate)
end

RegisterNetEvent('pulse_vehiclekeys:keyResult', function(plate, res)
    keyCache[plate] = {
        hasKey = res.hasKey == true, isOwner = res.isOwner == true,
        class = res.class, wheelAngle = res.wheelAngle, checkedAt = GetGameTimer(),
    }
end)

RegisterNetEvent('pulse_vehiclekeys:lockAllowed', function(plate)
    for _, veh in ipairs(GetGamePool('CVehicle')) do
        if plateOf(veh) == plate then
            local locked = Entity(veh).state.keysLocked
            local newLocked = not (locked == false)
            Entity(veh).state:set('keysLocked', not newLocked, true)
            notify(newLocked and '~g~Vehicle unlocked.' or '~y~Vehicle locked.')
            return
        end
    end
end)

local function nearestVehicleDoor(range)
    local ped = PlayerPedId()
    if GetVehiclePedIsIn(ped, false) ~= 0 then return nil end
    local pos = GetEntityCoords(ped)
    local veh = GetClosestVehicle(pos.x, pos.y, pos.z, range, 0, 71)
    if veh == 0 or not DoesEntityExist(veh) then return nil end
    return veh
end

local function runSkillCheck(seconds, label)
    busy = true
    SendNUIMessage({ action = 'begin', label = label, seconds = seconds })
    SetNuiFocus(false, false)
    local start = GetGameTimer()
    local held = true
    while GetGameTimer() - start < seconds * 1000 do
        Wait(0)
        if not IsControlPressed(0, 38) then held = false break end
        SendNUIMessage({ action = 'progress', pct = math.floor(((GetGameTimer() - start) / (seconds * 1000)) * 100) })
    end
    SendNUIMessage({ action = 'end' })
    busy = false
    return held
end

local function tryLockpick(veh)
    if busy or not remoteEnabled then return end
    notify('~b~Hold ~INPUT_CONTEXT~ to lockpick the door.')
    local ok = runSkillCheck(remoteLockpickSeconds or Config.Lockpick.seconds, 'Lockpicking')
    local plate = plateOf(veh)
    if ok then
        Entity(veh).state:set('keysLocked', false, true)
        notify('~g~Door popped open.')
    else
        if math.random(1, 100) <= (remoteFailAlarmChance or Config.Lockpick.failAlarmChance) then
            notify('~r~The alarm went off!')
            SetVehicleAlarm(veh, true)
            StartVehicleAlarm(veh)
        else
            notify('~y~You did not get it open in time.')
        end
    end
end

local function tryHotwire(veh)
    if busy or not remoteEnabled then return end
    notify('~b~Hold ~INPUT_CONTEXT~ to hotwire the ignition.')
    local ok = runSkillCheck(remoteHotwireSeconds or Config.Hotwire.seconds, 'Hotwiring')
    if ok then
        SetVehicleEngineOn(veh, true, true, false)
        hotwired[NetworkGetNetworkIdFromEntity(veh)] = true
        notify('~g~Engine started.')
        local class = GetVehicleClass(veh)
        if class == 15 or class == 16 then
            local netId = NetworkGetNetworkIdFromEntity(veh)
            airLockout[netId] = GetGameTimer() + (Config.AirControlLockoutSeconds * 1000)
            notify('~y~It will take a moment to get a feel for the controls.')
        end
    else
        notify('~y~That did not work.')
    end
end

CreateThread(function()
    while true do
        Wait(Config.LockLoopMs)
        if remoteEnabled then
            local pos = GetEntityCoords(PlayerPedId())
            for _, veh in ipairs(GetGamePool('CVehicle')) do
                if DoesEntityExist(veh) and #(GetEntityCoords(veh) - pos) < 60.0 then
                    local locked = Entity(veh).state.keysLocked
                    if locked == false then
                        SetVehicleDoorsLocked(veh, 1)
                    else
                        SetVehicleDoorsLocked(veh, 2)
                    end
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(250)
        if remoteEnabled and not busy then
            local veh = nearestVehicleDoor(Config.InteractRange)
            if veh then
                local plate = plateOf(veh)
                requestKeyCheck(plate)
                local cached = keyCache[plate]
                local locked = Entity(veh).state.keysLocked ~= false
                if cached and cached.hasKey then
                    BeginTextCommandDisplayHelp('STRING')
                    AddTextComponentSubstringPlayerName(locked and 'Press ~INPUT_CONTEXT~ to unlock' or 'Press ~INPUT_CONTEXT~ to lock')
                    EndTextCommandDisplayHelp(0, false, true, -1)
                    if IsControlJustReleased(0, 38) then
                        TriggerServerEvent('pulse_vehiclekeys:toggleLock', plate)
                        Wait(400)
                    end
                elseif locked then
                    BeginTextCommandDisplayHelp('STRING')
                    AddTextComponentSubstringPlayerName('Hold ~INPUT_CONTEXT~ to lockpick')
                    EndTextCommandDisplayHelp(0, false, true, -1)
                    if IsControlPressed(0, 38) then
                        tryLockpick(veh)
                    end
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(500)
        if remoteEnabled then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                local netId = NetworkGetNetworkIdFromEntity(veh)
                local plate = plateOf(veh)
                requestKeyCheck(plate)
                local cached = keyCache[plate]
                local hasAccess = (cached and cached.hasKey) or hotwired[netId]
                if not hasAccess and not GetIsVehicleEngineRunning(veh) then
                    if not busy then
                        BeginTextCommandDisplayHelp('STRING')
                        AddTextComponentSubstringPlayerName('Hold ~INPUT_CONTEXT~ to hotwire')
                        EndTextCommandDisplayHelp(0, false, true, -1)
                        if IsControlPressed(0, 38) then
                            tryHotwire(veh)
                        end
                    end
                end

                local lockoutUntil = airLockout[netId]
                if lockoutUntil then
                    if GetGameTimer() < lockoutUntil then
                        DisableControlAction(2, 63, true)
                        DisableControlAction(2, 64, true)
                        DisableControlAction(2, 65, true)
                        DisableControlAction(2, 66, true)
                        DisableControlAction(2, 67, true)
                    else
                        airLockout[netId] = nil
                    end
                end
            end
        end
    end
end)

RegisterCommand(Config.LockCommand, function()
    if not remoteEnabled then notify('~y~Vehicle keys are disabled on this server.') return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then veh = nearestVehicleDoor(Config.InteractRange) end
    if not veh then notify('~y~No vehicle nearby.') return end
    TriggerServerEvent('pulse_vehiclekeys:toggleLock', plateOf(veh))
end, false)

RegisterCommand(Config.ShareKeyCommand, function(_, args)
    if not remoteEnabled then notify('~y~Vehicle keys are disabled on this server.') return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then notify('~y~Get in the vehicle first.') return end
    if not args[1] then notify(('~b~Usage: /%s <serverId>'):format(Config.ShareKeyCommand)) return end
    TriggerServerEvent('pulse_vehiclekeys:shareKey', { plate = plateOf(veh), serverId = args[1] })
end, false)

RegisterCommand(Config.RevokeKeyCommand, function(_, args)
    if not remoteEnabled then notify('~y~Vehicle keys are disabled on this server.') return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then notify('~y~Get in the vehicle first.') return end
    if not args[1] then notify(('~b~Usage: /%s <serverId>'):format(Config.RevokeKeyCommand)) return end
    TriggerServerEvent('pulse_vehiclekeys:revokeKey', { plate = plateOf(veh), serverId = args[1] })
end, false)

RegisterCommand(Config.TransferCommand, function(_, args)
    if not remoteEnabled then notify('~y~Vehicle keys are disabled on this server.') return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then notify('~y~Get in the vehicle first.') return end
    if not args[1] then notify(('~b~Usage: /%s <serverId>'):format(Config.TransferCommand)) return end
    TriggerServerEvent('pulse_vehiclekeys:transferOwnership', { plate = plateOf(veh), serverId = args[1] })
end, false)

local cruiseSpeed = 0.0

RegisterCommand(Config.CruiseCommand, function()
    if not remoteEnabled then notify('~y~Vehicle keys are disabled on this server.') return end
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then notify('~y~Get in a vehicle first.') return end
    cruiseActive = not cruiseActive
    if cruiseActive then cruiseSpeed = GetEntitySpeed(veh) end
    notify(cruiseActive and '~g~Cruise control on.' or '~y~Cruise control off.')
end, false)

CreateThread(function()
    while true do
        Wait(0)
        if remoteEnabled and cruiseActive then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh == 0 or GetPedInVehicleSeat(veh, -1) ~= ped then
                cruiseActive = false
            elseif IsControlPressed(0, 72) or IsDisabledControlPressed(0, 72) then
                cruiseActive = false
                notify('~y~Cruise control off.')
            else
                SetVehicleForwardSpeed(veh, math.max(cruiseSpeed, GetEntitySpeed(veh)))
            end
        else
            Wait(400)
        end
    end
end)

CreateThread(function()
    local wasInVehicle = nil
    while true do
        Wait(500)
        local ped = PlayerPedId()
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 and wasInVehicle and DoesEntityExist(wasInVehicle) then
            local cached = keyCache[plateOf(wasInVehicle)]
            if cached and cached.hasKey then
                local ok, angle = pcall(GetVehicleSteeringAngle, wasInVehicle)
                if ok and angle then
                    TriggerServerEvent('pulse_vehiclekeys:saveWheelAngle', { plate = plateOf(wasInVehicle), angle = angle })
                end
            end
        end
        wasInVehicle = veh ~= 0 and veh or nil
    end
end)
