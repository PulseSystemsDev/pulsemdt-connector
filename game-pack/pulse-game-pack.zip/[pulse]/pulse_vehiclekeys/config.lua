-- PulseMDT :: pulse_vehiclekeys (Keys, lockpicking, hotwiring, ownership)
--
-- Works on any vehicle with a plate registered in the CAD, whether it came
-- from the dealership, the framework bridge, or was entered by hand on the
-- civilian portal. Separate from pulse_garage/pulse_dealership on purpose:
-- those two own storage and purchase, this one owns how you actually
-- interact with a vehicle sitting in the world. Reaches the CAD through the
-- main `pulsemdt` resource, so no API key here.
--
-- Every vehicle is locked by default, including NPC traffic and parked cars,
-- so lockpicking and hotwiring actually matter. Key holders unlock their own
-- vehicle with a command; anyone else has to lockpick the door and then
-- hotwire the ignition.

Config = {}

-- Toggle lock/unlock on the vehicle you're in or standing next to (requires
-- a key).
Config.LockCommand = 'lock'
Config.LockKey = false

-- Share, revoke, or transfer keys for the vehicle you are currently in.
-- Targets an explicit player by server ID, not "nearest player" (same reason
-- pulse_jailing targets by ID: avoids ambiguity, this time about who should
-- receive the key rather than who gets jailed).
Config.ShareKeyCommand = 'sharekey'
Config.RevokeKeyCommand = 'revokekey'
Config.TransferCommand = 'transfervehicle'

-- Cruise control: holds current speed until you brake or toggle it off.
Config.CruiseCommand = 'cruise'

-- Range (metres) to interact with a vehicle door from outside it.
Config.InteractRange = 2.5

-- Lockpicking (getting past a locked door without a key).
Config.Lockpick = {
    seconds = 6,
    failAlarmChance = 40,   -- percent chance a failed attempt triggers the alarm
}

-- Hotwiring (starting the engine once inside, without a key).
Config.Hotwire = {
    seconds = 8,
}

-- How long (seconds) after a successful hotwire that helicopter/plane flight
-- controls stay restricted, simulating "getting a feel for a stolen aircraft".
Config.AirControlLockoutSeconds = 20

-- How often (ms) the world-vehicle lock loop runs.
Config.LockLoopMs = 2000
