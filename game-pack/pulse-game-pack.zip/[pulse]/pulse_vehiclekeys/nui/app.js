const skill = document.getElementById('skill');
const label = document.getElementById('label');
const fill = document.getElementById('fill');

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action === 'begin') {
    label.textContent = data.label || 'Working';
    fill.style.width = '0%';
    skill.classList.remove('hidden');
  } else if (data.action === 'progress') {
    fill.style.width = `${Math.max(0, Math.min(100, data.pct))}%`;
  } else if (data.action === 'end') {
    skill.classList.add('hidden');
  }
});
