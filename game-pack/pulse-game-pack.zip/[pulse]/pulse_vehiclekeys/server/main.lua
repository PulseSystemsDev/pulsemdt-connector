local function notify(src, msg)
    TriggerClientEvent('pulse_vehiclekeys:notify', src, msg)
end

local RCFG = { enabled = true, settings = {} }

local function remoteConfig()
    return {
        enabled = RCFG.enabled ~= false,
        lockpickSeconds = RCFG.settings and tonumber(RCFG.settings.lockpickSeconds) or nil,
        hotwireSeconds = RCFG.settings and tonumber(RCFG.settings.hotwireSeconds) or nil,
        failAlarmChance = RCFG.settings and tonumber(RCFG.settings.failAlarmChance) or nil,
    }
end

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_vehiclekeys') end)
    if ok and type(c) == 'table' then RCFG = c end
    TriggerClientEvent('pulse_vehiclekeys:remoteConfig', -1, remoteConfig())
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function moduleEnabled()
    return RCFG.enabled ~= false
end

RegisterNetEvent('pulse_vehiclekeys:requestConfig', function()
    TriggerClientEvent('pulse_vehiclekeys:remoteConfig', source, remoteConfig())
end)

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local function urlEncode(str)
    return (tostring(str):gsub('[^%w%-%.%_%~]', function(c)
        return string.format('%%%02X', string.byte(c))
    end))
end

RegisterNetEvent('pulse_vehiclekeys:checkKey', function(plate)
    local src = source
    if not moduleEnabled() then
        TriggerClientEvent('pulse_vehiclekeys:keyResult', src, plate, { hasKey = false, disabled = true })
        return
    end
    getCharId(src, function(charId)
        if not charId then TriggerClientEvent('pulse_vehiclekeys:keyResult', src, plate, { hasKey = false }) return end
        exports.pulsemdt:ApiRequest('GET', ('/vehiclekeys?plate=%s&charId=%d'):format(urlEncode(plate), charId), nil, function(code, res)
            TriggerClientEvent('pulse_vehiclekeys:keyResult', src, plate, (code == 200 and res) or { hasKey = false })
        end)
    end)
end)

RegisterNetEvent('pulse_vehiclekeys:toggleLock', function(plate)
    local src = source
    if not moduleEnabled() then return end
    getCharId(src, function(charId)
        if not charId then notify(src, '~r~No active character.') return end
        exports.pulsemdt:ApiRequest('GET', ('/vehiclekeys?plate=%s&charId=%d'):format(urlEncode(plate), charId), nil, function(code, res)
            if code == 200 and res and res.hasKey then
                TriggerClientEvent('pulse_vehiclekeys:lockAllowed', src, plate)
            else
                notify(src, '~r~You do not have a key for that vehicle.')
            end
        end)
    end)
end)

local function keyAction(src, action, plate, targetSrc)
    if not moduleEnabled() then return end
    getCharId(src, function(charId)
        if not charId then notify(src, '~r~No active character.') return end
        if not targetSrc or not GetPlayerName(targetSrc) then notify(src, '~r~No player with that server ID.') return end
        getCharId(targetSrc, function(targetCharId)
            if not targetCharId then notify(src, '~r~That player has no active character.') return end
            exports.pulsemdt:ApiRequest('POST', '/vehiclekeys', {
                action = action, plate = plate, charId = charId, targetCharId = targetCharId,
            }, function(code, res)
                if code == 200 and res and res.ok then
                    if action == 'shareKey' then
                        notify(src, ('~g~Keys~s~ Shared with %s.'):format(GetPlayerName(targetSrc)))
                        notify(targetSrc, ('~g~Keys~s~ %s shared vehicle keys with you.'):format(GetPlayerName(src)))
                    elseif action == 'revokeKey' then
                        notify(src, ('~g~Keys~s~ Revoked from %s.'):format(GetPlayerName(targetSrc)))
                    elseif action == 'transferOwnership' then
                        notify(src, ('~g~Keys~s~ Vehicle transferred to %s.'):format(GetPlayerName(targetSrc)))
                        notify(targetSrc, ('~g~Keys~s~ %s transferred a vehicle to you.'):format(GetPlayerName(src)))
                    end
                else
                    notify(src, '~r~That could not be done (are you the owner?).')
                end
            end)
        end)
    end)
end

RegisterNetEvent('pulse_vehiclekeys:shareKey', function(data)
    keyAction(source, 'shareKey', data.plate, tonumber(data.serverId))
end)

RegisterNetEvent('pulse_vehiclekeys:revokeKey', function(data)
    keyAction(source, 'revokeKey', data.plate, tonumber(data.serverId))
end)

RegisterNetEvent('pulse_vehiclekeys:transferOwnership', function(data)
    keyAction(source, 'transferOwnership', data.plate, tonumber(data.serverId))
end)

RegisterNetEvent('pulse_vehiclekeys:saveWheelAngle', function(data)
    local src = source
    if not moduleEnabled() then return end
    getCharId(src, function(charId)
        if not charId then return end
        exports.pulsemdt:ApiRequest('POST', '/vehiclekeys', {
            action = 'saveWheelAngle', plate = data.plate, charId = charId, angle = data.angle,
        }, nil)
    end)
end)
