# pulse_vehiclekeys

`pulse_vehiclekeys` connects PulseMDT vehicle ownership to locking, shared keys, ownership transfers, lockpicking, hotwiring, and cruise control.

## Requirements

- `pulsemdt` with vehicle records available
- An active PulseMDT character; `pulse_core` is recommended
- `pulse_notify` optional

## Installation

Configure commands and gameplay timings in `config.lua`, then start `pulse_vehiclekeys` after `pulsemdt`.

## Commands

- `/lock` locks or unlocks the current/nearby owned vehicle.
- `/sharekey <serverId>` shares a key.
- `/revokekey <serverId>` revokes a shared key.
- `/transfervehicle <serverId>` transfers ownership.
- `/cruise` toggles cruise control.

The lock shortcut can be enabled with `Config.LockKey`. Lockpick and hotwire duration, difficulty, failure behavior, interaction range, aircraft safety lockout, and ownership polling are configured in `config.lua`. Supported timings may also be overridden from PulseMDT.
