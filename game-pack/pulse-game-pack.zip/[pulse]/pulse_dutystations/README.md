# pulse_dutystations

`pulse_dutystations` adds physical clock-in and clock-out stations for police, EMS, and fire roles connected to PulseMDT shifts.

## Requirements

- `pulsemdt`
- `pulse_notify` optional

## Installation

Configure groups and default station coordinates in `config.lua`, then start `pulse_dutystations` after `pulsemdt`.

Grant station administrators the `pulse.dutystations` ACE permission:

```cfg
add_ace group.admin pulse.dutystations allow
ensure pulse_dutystations
```

## Administration

Use `/dutystation` with its in-game subcommands to add, remove, or list stations. The resource can use dashboard-managed stations and falls back to the local `Config.Stations` list. `Config.StationRadius` sets interaction distance.
