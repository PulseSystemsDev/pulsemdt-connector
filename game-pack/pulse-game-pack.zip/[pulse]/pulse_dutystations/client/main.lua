local stationData = { enabled = true, groups = {}, stations = {}, blips = {}, radius = 2.5 }
local groupByKey = {}
local stationBlips = {}
local dutyDept = nil
local lastPress = 0

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_dutystations:notify', function(msg)
    if msg then notify(msg) end
end)

RegisterNetEvent('pulsemdt:shiftStarted', function(shift)
    dutyDept = shift and shift.department or nil
end)

RegisterNetEvent('pulsemdt:shiftEnded', function()
    dutyDept = nil
end)

local function rebuildStationBlips()
    for _, b in ipairs(stationBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    stationBlips = {}
    for key, list in pairs(stationData.stations or {}) do
        local meta = stationData.blips and stationData.blips[key]
        if meta then
            for _, st in ipairs(list) do
                local b = AddBlipForCoord(st.x, st.y, st.z)
                SetBlipSprite(b, meta.sprite or 60)
                SetBlipColour(b, meta.color or 3)
                SetBlipScale(b, 0.8)
                SetBlipAsShortRange(b, true)
                BeginTextCommandSetBlipName('STRING')
                AddTextComponentSubstringPlayerName(meta.label or key)
                EndTextCommandSetBlipName(b)
                stationBlips[#stationBlips + 1] = b
            end
        end
    end
end

RegisterNetEvent('pulse_dutystations:stations', function(payload)
    if type(payload) ~= 'table' then return end
    stationData = payload
    groupByKey = {}
    for _, g in ipairs(stationData.groups or {}) do groupByKey[g.key] = g end
    rebuildStationBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_dutystations:requestStations')
end)

CreateThread(function()
    while true do
        local sleep = 900
        local pos = GetEntityCoords(PlayerPedId())
        for key, list in pairs(stationData.stations or {}) do
            local group = groupByKey[key]
            for _, st in ipairs(list) do
                local dist = #(pos - vector3(st.x, st.y, st.z))
                if dist < 40.0 then
                    sleep = 0
                    DrawMarker(2, st.x, st.y, st.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                        0.5, 0.5, 0.5, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                    if dist <= (stationData.radius or 2.5) and group then
                        local onDutyHere = dutyDept and dutyDept:lower() == tostring(group.department or ''):lower()
                        local prompt = onDutyHere and ('Press ~INPUT_CONTEXT~ to clock out of %s'):format(group.department)
                            or ('Press ~INPUT_CONTEXT~ to clock in as %s'):format(group.department)
                        BeginTextCommandDisplayHelp('STRING')
                        AddTextComponentSubstringPlayerName(prompt)
                        EndTextCommandDisplayHelp(0, false, true, -1)
                        if IsControlJustReleased(0, 38) and GetGameTimer() - lastPress > 1500 then
                            lastPress = GetGameTimer()
                            if onDutyHere then
                                TriggerServerEvent('pulsemdt:shiftOff', {})
                            else
                                TriggerServerEvent('pulsemdt:shiftOn', { department = group.department, role = group.role })
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

RegisterCommand('dutystation', function(_, args)
    local action = args[1]
    if action == 'add' then
        local groupKey = args[2]
        local label = table.concat(args, ' ', 3)
        if label == '' then label = 'Station' end
        local pos = GetEntityCoords(PlayerPedId())
        TriggerServerEvent('pulse_dutystations:adminStation', {
            action = 'add', group = groupKey, label = label,
            x = pos.x, y = pos.y, z = pos.z, heading = GetEntityHeading(PlayerPedId()),
        })
    elseif action == 'remove' then
        local pos = GetEntityCoords(PlayerPedId())
        TriggerServerEvent('pulse_dutystations:adminStation', { action = 'remove', x = pos.x, y = pos.y })
    elseif action == 'list' then
        TriggerServerEvent('pulse_dutystations:adminStation', { action = 'list' })
    else
        notify('~b~Duty Stations~s~ Usage: /dutystation add <police|ems|fire> <name>, /dutystation remove, /dutystation list')
    end
end, false)
