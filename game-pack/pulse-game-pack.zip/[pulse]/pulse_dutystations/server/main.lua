local adminStations = nil

local GROUPS = {}
for _, g in ipairs(Config.Groups) do GROUPS[#GROUPS + 1] = g.key end

local RCFG = { enabled = true, settings = {} }

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_dutystations') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function moduleEnabled()
    return RCFG.enabled ~= false
end

local function effectiveStations()
    local byGroup = {}
    for _, key in ipairs(GROUPS) do byGroup[key] = {} end

    local source = adminStations
    if not source then
        local raw = RCFG.settings and RCFG.settings.stationsJson
        if type(raw) == 'string' and raw ~= '' then
            local ok, parsed = pcall(json.decode, raw)
            if ok and type(parsed) == 'table' then source = parsed end
        end
    end
    if type(source) == 'table' then
        for _, s in ipairs(source) do
            if byGroup[s.job] and tonumber(s.x) then
                byGroup[s.job][#byGroup[s.job] + 1] = {
                    label = tostring(s.label or 'Station'),
                    x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                    heading = tonumber(s.heading) or 0.0,
                }
            end
        end
    end
    for _, key in ipairs(GROUPS) do
        if #byGroup[key] == 0 then
            for _, s in ipairs(Config.Stations[key] or {}) do
                byGroup[key][#byGroup[key] + 1] = s
            end
        end
    end
    return byGroup
end

local function broadcastStations(target)
    local byGroup = effectiveStations()
    local groups = {}
    local blips = {}
    for _, g in ipairs(Config.Groups) do
        groups[#groups + 1] = { key = g.key, department = g.department, role = g.role }
        blips[g.key] = g.blip
    end
    local payload = {
        enabled = moduleEnabled(),
        groups = groups,
        stations = moduleEnabled() and byGroup or {},
        blips = blips,
        radius = Config.StationRadius,
    }
    TriggerClientEvent('pulse_dutystations:stations', target or -1, payload)
end

RegisterNetEvent('pulse_dutystations:requestStations', function()
    broadcastStations(source)
end)

RegisterNetEvent('pulse_dutystations:adminStation', function(data)
    local src = source
    if not IsPlayerAceAllowed(src, 'pulse.dutystations') then
        TriggerClientEvent('pulse_dutystations:notify', src, '~r~Duty Stations~s~ You lack the pulse.dutystations permission.')
        return
    end
    local action = data and data.action
    local body = {
        action = action,
        job = data.group,
        label = data.label,
        x = data.x, y = data.y, z = data.z, heading = data.heading,
    }
    local ok = pcall(function()
        exports.pulsemdt:ApiRequest('POST', '/duty-stations', body, function(code, res)
            if code == 200 and res and res.stations then
                adminStations = res.stations
                broadcastStations()
                if action == 'add' then
                    TriggerClientEvent('pulse_dutystations:notify', src, ('~g~Duty Stations~s~ Station "%s" added for %s.'):format(data.label or 'Station', data.group))
                elseif action == 'remove' then
                    TriggerClientEvent('pulse_dutystations:notify', src, '~g~Duty Stations~s~ Station removed.')
                elseif action == 'list' then
                    if #res.stations == 0 then
                        TriggerClientEvent('pulse_dutystations:notify', src, '~b~Duty Stations~s~ No dashboard-managed stations; defaults are in use.')
                    end
                    for _, s in ipairs(res.stations) do
                        TriggerClientEvent('chat:addMessage', src, {
                            args = { '^3Duty Stations', ('%s: %s (%.0f, %.0f)'):format(s.job, s.label, s.x, s.y) }
                        })
                    end
                end
            elseif code == 0 then
                TriggerClientEvent('pulse_dutystations:notify', src, '~r~Duty Stations~s~ The CAD is offline; try again later.')
            else
                TriggerClientEvent('pulse_dutystations:notify', src, '~r~Duty Stations~s~ ' .. ((res and res.error) or 'Station change failed.'))
            end
        end)
    end)
    if not ok then
        TriggerClientEvent('pulse_dutystations:notify', src, '~r~Duty Stations~s~ Station management is unavailable right now.')
    end
end)
