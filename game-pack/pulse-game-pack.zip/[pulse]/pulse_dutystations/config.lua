-- PulseMDT :: pulse_dutystations (Physical duty clock-in)
--
-- Walk up to a station and interact to start (or end) a shift, the same
-- shift the tablet's "go on duty" button starts. This does not replace the
-- tablet; it's a second, physical way in for servers that want officers and
-- medics to badge in at a real building instead of opening a menu.
--
-- Stations below are the defaults. Server owners can replace them per group
-- from the dashboard (Scripts page, "Duty stations") or in-game with
-- /dutystation add|remove|list (requires ace: add_ace group.admin pulse.dutystations allow).

Config = {}

-- Marker/prompt radius at stations.
Config.StationRadius = 2.5

-- Duty groups. `department` and `role` are sent to the CAD exactly like the
-- tablet's on-duty form; they only need to match what your departments are
-- actually named if you want shift records to line up with them.
Config.Groups = {
    { key = 'police', label = 'Police', department = 'Police', role = 'Officer',
      blip = { sprite = 60, color = 3, label = 'Police HQ' } },
    { key = 'ems', label = 'EMS', department = 'EMS', role = 'Medic',
      blip = { sprite = 61, color = 1, label = 'EMS Station' } },
    { key = 'fire', label = 'Fire', department = 'Fire', role = 'Firefighter',
      blip = { sprite = 436, color = 17, label = 'Fire Station' } },
}

-- Default stations (replaced per group by dashboard stations when any exist).
Config.Stations = {
    police = {
        { label = 'Mission Row PD',       x = 441.8,  y = -982.3,  z = 30.7, heading = 90.0 },
    },
    ems = {
        { label = 'Pillbox Hill Medical', x = 307.9,  y = -1433.3, z = 29.9, heading = 355.0 },
    },
    fire = {
        { label = 'Davis Fire Station',   x = 1193.5, y = -1464.5, z = 34.9, heading = 265.0 },
    },
}
