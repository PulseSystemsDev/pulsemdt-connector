local function openInput()
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'openInput' })
end

RegisterCommand(Config.Command, function(_, args)
    local serial = table.concat(args, ' '):gsub('%s+', '')
    if serial ~= '' then
        TriggerServerEvent('pulse_firearms:lookup', { serial = serial })
    else
        openInput()
    end
end, false)

if Config.OpenKey then
    RegisterKeyMapping(Config.Command, 'PulseMDT: Run firearm serial', 'keyboard', Config.OpenKey)
end

RegisterNUICallback('lookup', function(data, cb)
    if data and data.serial and tostring(data.serial) ~= '' then
        TriggerServerEvent('pulse_firearms:lookup', { serial = data.serial })
    end
    cb({})
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNetEvent('pulse_firearms:result', function(res)
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'result', data = res or {} })
end)
