const RESOURCE = 'pulse_firearms';

const overlay = document.getElementById('overlay');
const inputView = document.getElementById('inputView');
const resultView = document.getElementById('resultView');
const serialEl = document.getElementById('serial');
const statusEl = document.getElementById('status');
const detailsEl = document.getElementById('details');

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function showInput() {
  overlay.classList.remove('hidden');
  resultView.classList.add('hidden');
  inputView.classList.remove('hidden');
  serialEl.value = '';
  setTimeout(() => serialEl.focus(), 40);
}

function row(label, value) {
  const d = document.createElement('div');
  const dt = document.createElement('dt');
  const dd = document.createElement('dd');
  dt.textContent = label;
  dd.textContent = value;
  d.append(dt, dd);
  return d;
}

function showResult(res) {
  overlay.classList.remove('hidden');
  inputView.classList.add('hidden');
  resultView.classList.remove('hidden');
  detailsEl.innerHTML = '';

  if (res.error) {
    statusEl.className = 'status none';
    statusEl.textContent = res.error;
    return;
  }
  if (!res.found) {
    statusEl.className = 'status none';
    statusEl.textContent = 'No registration on file';
    detailsEl.append(row('Serial', res.serial || '-'));
    return;
  }
  if (res.stolen) {
    statusEl.className = 'status stolen';
    statusEl.textContent = 'FLAGGED - Reported stolen';
  } else {
    statusEl.className = 'status ok';
    statusEl.textContent = 'Registered';
  }
  detailsEl.append(row('Serial', res.serial || '-'));
  detailsEl.append(row('Model', res.model || 'Unknown'));
  detailsEl.append(row('Owner', res.owner || 'Unknown'));
  detailsEl.append(row('Status', (res.status || 'registered').replace(/^\w/, (c) => c.toUpperCase())));
}

function close() {
  overlay.classList.add('hidden');
  post('close');
}

function run() {
  const serial = serialEl.value.trim();
  if (serial === '') return;
  inputView.classList.add('hidden');
  post('lookup', { serial });
}

window.addEventListener('message', (e) => {
  const d = e.data || {};
  if (d.action === 'openInput') showInput();
  if (d.action === 'result') showResult(d.data || {});
});

document.getElementById('run').addEventListener('click', run);
document.getElementById('cancel').addEventListener('click', close);
document.getElementById('done').addEventListener('click', close);
document.getElementById('x').addEventListener('click', close);
document.getElementById('again').addEventListener('click', showInput);
serialEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') run(); });
document.addEventListener('keydown', (e) => {
  if (overlay.classList.contains('hidden')) return;
  if (e.key === 'Escape') close();
});
