-- PulseMDT :: pulse_firearms (Firearm & serial lookup)
--
-- Reaches the CAD through the main `pulsemdt` resource, so no API key here.
-- Configure connection settings once in pulsemdt/config.lua.

Config = {}

-- Command an on-duty officer types to run a serial. `/runserial ABC123` looks up
-- directly; `/runserial` with no argument opens the input box.
Config.Command = 'runserial'

-- Optional key that opens the serial input box. Set to false to disable.
-- Uses FiveM key names, e.g. 'G', 'H', 'F5'.
Config.OpenKey = false
