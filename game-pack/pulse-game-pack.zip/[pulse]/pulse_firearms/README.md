# pulse_firearms

`pulse_firearms` lets an on-duty officer look up a firearm serial number through PulseMDT and displays the registration result in a focused NUI panel.

## Requirements

- `pulsemdt`
- `pulse_notify` optional

## Installation

Start `pulse_firearms` after `pulsemdt`. No API key belongs in this resource; it uses the configured `pulsemdt` core connection.

## Usage

- `/runserial ABC123` looks up a serial directly.
- `/runserial` opens the serial input.

Change the command with `Config.Command`. Set `Config.OpenKey` to a FiveM key name to enable a shortcut, or leave it `false`. The user must be on duty in an eligible law-enforcement role.
