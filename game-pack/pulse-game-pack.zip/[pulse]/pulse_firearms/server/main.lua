local function encode(str)
    return (tostring(str):gsub('[^%w%-%.]', function(c)
        return string.format('%%%02X', string.byte(c))
    end))
end

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_firearms') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

RegisterNetEvent('pulse_firearms:lookup', function(data)
    local src = source

    if not RCFG.enabled then
        TriggerClientEvent('pulse_firearms:result', src, { error = 'Serial lookups are disabled on this server.' })
        return
    end

    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'police', 'law') end)
    if not authorized then
        TriggerClientEvent('pulse_firearms:result', src, { error = 'An on-duty law-enforcement role is required to run a serial.' })
        return
    end

    local serial = tostring(data and data.serial or ''):gsub('%s+', ''):upper()
    if serial == '' then
        TriggerClientEvent('pulse_firearms:result', src, { error = 'Enter a serial number.' })
        return
    end

    local ok = pcall(function()
        exports.pulsemdt:ApiRequest('GET', '/firearm?serial=' .. encode(serial), nil, function(code, res)
            if code == 200 and type(res) == 'table' then
                TriggerClientEvent('pulse_firearms:result', src, res)
            elseif code == 0 then
                TriggerClientEvent('pulse_firearms:result', src, { error = 'Dispatch is offline. Try again shortly.' })
            else
                TriggerClientEvent('pulse_firearms:result', src, { error = 'Lookup failed.' })
            end
        end)
    end)

    if not ok then
        TriggerClientEvent('pulse_firearms:result', src, { error = 'Dispatch is unavailable right now.' })
    end
end)
