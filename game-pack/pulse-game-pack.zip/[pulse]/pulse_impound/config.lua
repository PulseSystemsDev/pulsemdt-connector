-- PulseMDT :: pulse_impound (Tow & impound)
--
-- On-duty officers impound the nearest vehicle with a reason; it is stored in
-- impound.json inside this resource and the owner releases it at the lot by
-- paying the fee from their bank (free when the Economy feature is off).
-- Ownership resolves through the CAD's vehicle registrations. The fee can be
-- changed live from the dashboard's Scripts page.

Config = {}

-- Officer command: /impound [reason...]
Config.Command = 'impound'

-- The impound lot (Davis). Walk into the marker to retrieve your vehicle.
Config.Lot = {
    point = { x = 409.0, y = -1623.0, z = 29.3 },
    spawn = { x = 396.5, y = -1643.5, z = 29.3, heading = 230.0 },
    radius = 3.0,
    blip = { sprite = 68, color = 47, scale = 0.85, label = 'Impound Lot' },
}

-- Fee charged from the bank to release a vehicle.
Config.Fee = 300

-- Metres within which /impound picks up a vehicle.
Config.Range = 6.0
