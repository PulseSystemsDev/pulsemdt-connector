local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function nearestVehicle()
    local ped = PlayerPedId()
    local inVeh = GetVehiclePedIsIn(ped, false)
    if inVeh ~= 0 then return inVeh end
    local pos = GetEntityCoords(ped)
    return GetClosestVehicle(pos.x, pos.y, pos.z, Config.Range, 0, 71)
end

RegisterCommand(Config.Command, function(_, args)
    local veh = nearestVehicle()
    if not veh or veh == 0 or not DoesEntityExist(veh) then
        notify('~y~PulseMDT~s~ No vehicle nearby.')
        return
    end
    local plate = (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', '')
    local model = GetDisplayNameFromVehicleModel(GetEntityModel(veh))
    TriggerServerEvent('pulse_impound:doImpound', {
        netId = VehToNet(veh),
        plate = plate,
        model = model,
        reason = table.concat(args, ' '),
    })
end, false)

RegisterNetEvent('pulse_impound:notify', function(msg)
    if msg then notify(msg) end
end)

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local deadline = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return nil end
        Wait(25)
    end
    return hash
end

RegisterNetEvent('pulse_impound:spawn', function(data)
    local hash = loadModel(data.model)
    if not hash then
        notify('~r~PulseMDT~s~ Your vehicle model failed to load; contact staff.')
        return
    end
    local s = data.spawn
    local veh = CreateVehicle(hash, s.x, s.y, s.z, s.heading or 0.0, true, false)
    SetModelAsNoLongerNeeded(hash)
    SetVehicleNumberPlateText(veh, data.plate)
    SetVehicleOnGroundProperly(veh)
end)

CreateThread(function()
    local b = Config.Lot.blip
    local blip = AddBlipForCoord(Config.Lot.point.x, Config.Lot.point.y, Config.Lot.point.z)
    SetBlipSprite(blip, b.sprite)
    SetBlipColour(blip, b.color)
    SetBlipScale(blip, b.scale + 0.0)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(b.label)
    EndTextCommandSetBlipName(blip)

    local p = Config.Lot.point
    while true do
        local sleep = 800
        local pos = GetEntityCoords(PlayerPedId())
        local dist = #(pos - vector3(p.x, p.y, p.z))
        if dist < 40.0 then
            sleep = 0
            DrawMarker(2, p.x, p.y, p.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                0.6, 0.6, 0.6, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
            if dist <= Config.Lot.radius then
                BeginTextCommandDisplayHelp('STRING')
                AddTextComponentSubstringPlayerName('Press ~INPUT_CONTEXT~ to retrieve your impounded vehicle')
                EndTextCommandDisplayHelp(0, false, true, -1)
                if IsControlJustReleased(0, 38) then
                    TriggerServerEvent('pulse_impound:retrieve')
                    Wait(1500)
                end
            end
        end
        Wait(sleep)
    end
end)
