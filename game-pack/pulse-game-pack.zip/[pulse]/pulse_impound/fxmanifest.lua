fx_version 'cerulean'
game 'gta5'

name 'pulse_impound'
description 'PulseMDT - Tow & impound'
version '0.1.0'
author 'PulseMDT'
url 'https://pulsemdt.com'

dependency 'pulsemdt'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

lua54 'yes'
