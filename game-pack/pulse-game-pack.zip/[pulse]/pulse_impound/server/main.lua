local impounds = {}   -- array of { plate, model, reason, by, at }

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_impound') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function fee()
    local v = RCFG.settings and tonumber(RCFG.settings.impoundFee)
    if v ~= nil then return v end
    return Config.Fee
end

local function load()
    local raw = LoadResourceFile(GetCurrentResourceName(), 'impound.json')
    if raw then
        local ok, data = pcall(json.decode, raw)
        if ok and type(data) == 'table' then impounds = data end
    end
end
load()

local function save()
    SaveResourceFile(GetCurrentResourceName(), 'impound.json', json.encode(impounds), -1)
end

local function notify(src, msg)
    TriggerClientEvent('pulse_impound:notify', src, msg)
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then discordId = ident:sub(9) break end
    end
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local function encodePlate(plate)
    return (plate:gsub('[^%w]', function(c) return string.format('%%%02X', string.byte(c)) end))
end

RegisterNetEvent('pulse_impound:doImpound', function(data)
    local src = source
    if not RCFG.enabled then
        notify(src, '~y~Impounding is disabled on this server.')
        return
    end
    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'police', 'law', 'dmv') end)
    if not authorized then
        notify(src, '~r~An on-duty law-enforcement or DMV role is required to impound vehicles.')
        return
    end

    local netId = tonumber(data and data.netId)
    local plate = tostring(data and data.plate or ''):gsub('^%s+', ''):gsub('%s+$', '')
    local model = tostring(data and data.model or 'Vehicle'):sub(1, 40)
    local reason = tostring(data and data.reason or ''):sub(1, 120)
    if reason == '' then reason = 'Impounded by law enforcement' end
    if not netId or plate == '' then return end

    local veh = NetworkGetEntityFromNetworkId(netId)
    if not veh or veh == 0 or not DoesEntityExist(veh) then
        notify(src, '~r~That vehicle is gone.')
        return
    end
    if #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(veh)) > Config.Range + 6.0 then
        return
    end

    for _, rec in ipairs(impounds) do
        if rec.plate == plate then
            notify(src, '~y~That plate is already impounded.')
            return
        end
    end

    DeleteEntity(veh)
    impounds[#impounds + 1] = {
        plate = plate, model = model, reason = reason,
        by = GetPlayerName(src), at = os.time(),
    }
    save()
    notify(src, ('~g~Impounded~s~ %s (%s). Release fee $%d.'):format(plate, reason, fee()))
    exports.pulsemdt:ApiWrite('POST', '/logs', {
        event = 'impound',
        details = ('%s impounded plate %s: %s'):format(GetPlayerName(src), plate, reason),
    }, nil)
end)

RegisterNetEvent('pulse_impound:retrieve', function()
    local src = source
    if not RCFG.enabled then
        notify(src, '~y~The impound lot is closed.')
        return
    end
    if #impounds == 0 then
        notify(src, '~y~No vehicles are impounded.')
        return
    end

    getCharId(src, function(charId)
        if not charId then
            notify(src, '~r~No active character.')
            return
        end

        local function tryIndex(i)
            local rec = impounds[i]
            if not rec then
                notify(src, '~y~None of the impounded vehicles are registered to you.')
                return
            end
            exports.pulsemdt:ApiRequest('GET', '/ncic?plate=' .. encodePlate(rec.plate), nil, function(code, res)
                local ownerId = code == 200 and res and res.owner and res.owner ~= json.null and res.owner.id or nil
                if ownerId == charId then
                    local amount = fee()
                    local function release()
                        for idx, r in ipairs(impounds) do
                            if r.plate == rec.plate then table.remove(impounds, idx) break end
                        end
                        save()
                        TriggerClientEvent('pulse_impound:spawn', src, {
                            model = rec.model, plate = rec.plate, spawn = Config.Lot.spawn,
                        })
                        notify(src, ('~g~Released~s~ %s.'):format(rec.plate))
                        exports.pulsemdt:ApiWrite('POST', '/logs', {
                            event = 'impound_release',
                            details = ('Plate %s released from impound'):format(rec.plate),
                        }, nil)
                    end
                    if amount <= 0 then
                        release()
                        return
                    end
                    exports.pulsemdt:ApiRequest('POST', '/money', {
                        charId = charId, account = 'bank', amount = -amount,
                        reason = 'Impound release: ' .. rec.plate,
                    }, function(mcode, mres)
                        if mcode == 200 and mres and mres.ok then
                            release()
                        elseif mcode == 403 then
                            release()   -- economy off: release is free
                        elseif mcode == 402 then
                            notify(src, ('~r~You need $%d in the bank to release %s.'):format(amount, rec.plate))
                        else
                            notify(src, '~r~The impound lot is unavailable right now.')
                        end
                    end)
                else
                    tryIndex(i + 1)
                end
            end)
        end
        tryIndex(1)
    end)
end)
