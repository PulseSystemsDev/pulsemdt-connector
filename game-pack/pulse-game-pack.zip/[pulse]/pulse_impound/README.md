# pulse_impound

`pulse_impound` lets authorized on-duty law-enforcement or DMV staff remove nearby vehicles and lets owners release them from a configured impound lot for a fee.

## Requirements

- `pulsemdt`
- An active PulseMDT character for paid release; `pulse_core` is recommended
- OneSync recommended
- `pulse_notify` optional

## Installation

Configure the lot and fee in `config.lua`, then start `pulse_impound` after `pulsemdt`.

## Usage

- `/impound [reason]` impounds the nearest vehicle.
- Visit the configured lot to retrieve an impounded vehicle.

`Config.Fee` sets the local release fee, `Config.Range` sets the officer's vehicle-selection range, and `Config.Lot` defines the release location. Active records are stored in `impound.json` and significant actions are logged to PulseMDT.
