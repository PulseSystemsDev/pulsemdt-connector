const pill = document.getElementById('pill');
const fill = document.getElementById('fill');
const pct = document.getElementById('pct');

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'show') pill.classList.remove('hidden');
  else if (m.action === 'hide') pill.classList.add('hidden');
  else if (m.action === 'fuel') {
    const p = Math.max(0, Math.min(100, Number(m.data?.pct) || 0));
    fill.style.transform = `scaleX(${p / 100})`;
    fill.classList.toggle('low', p <= 25 && p > 10);
    fill.classList.toggle('empty', p <= 10);
    pct.textContent = String(p);
  }
});
