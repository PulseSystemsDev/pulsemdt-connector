# pulse_fuel

`pulse_fuel` adds vehicle fuel consumption, configurable fuel stations, and bank-funded refueling through the PulseMDT economy.

## Requirements

- `pulsemdt`
- An active PulseMDT character for paid fuel; `pulse_core` is recommended
- `pulse_notify` optional

## Installation

Configure `config.lua` and start `pulse_fuel` after `pulsemdt`.

## Configuration

Settings cover tank capacity, consumption per minute, price per liter, starting fuel range, pump interaction radius, fill duration, and station locations. PulseMDT dashboard settings can override price and the drain multiplier.

When the economy is disabled by the server, supported refueling flows can operate without charging the player.
