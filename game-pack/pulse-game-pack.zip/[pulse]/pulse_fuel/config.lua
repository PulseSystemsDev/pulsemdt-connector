-- PulseMDT :: pulse_fuel
--
-- Vehicles burn fuel while driving; refueling at a gas station charges the
-- bank through the CAD economy (free when the Economy feature is off). Price
-- and drain rate can also be changed live from the dashboard's Scripts page.

Config = {}

-- Litres in a full tank.
Config.TankSize = 65

-- Base litres burned per minute at full throttle (scaled by RPM).
Config.DrainPerMinute = 2.4

-- Dashboard "Drain multiplier" scales this further; 1 = default.
Config.PricePerLiter = 2

-- Fresh unowned vehicles start with a random fuel level in this range (%).
Config.StartFuel = { min = 40, max = 90 }

-- Metres from a pump that allows refueling.
Config.PumpRadius = 4.0

-- Seconds to fill from empty to full.
Config.FillSeconds = 12

-- Gas stations (pump areas). Add or remove freely.
Config.Stations = {
    { x = 49.4,    y = 2778.8,  z = 58.0 },
    { x = 263.9,   y = 2606.5,  z = 44.9 },
    { x = 1039.9,  y = 2671.1,  z = 39.5 },
    { x = 1207.3,  y = 2660.2,  z = 37.9 },
    { x = 2539.7,  y = 2594.2,  z = 37.9 },
    { x = 2679.9,  y = 3264.0,  z = 55.2 },
    { x = 2005.1,  y = 3774.9,  z = 32.4 },
    { x = 1687.2,  y = 4929.4,  z = 42.1 },
    { x = 1701.3,  y = 6416.0,  z = 32.8 },
    { x = 179.9,   y = 6602.8,  z = 31.9 },
    { x = -94.5,   y = 6419.6,  z = 31.5 },
    { x = -2554.9, y = 2334.4,  z = 33.1 },
    { x = -1800.4, y = 803.7,   z = 138.7 },
    { x = -1437.6, y = -276.7,  z = 46.2 },
    { x = -526.0,  y = -1211.0, z = 18.2 },
    { x = -724.6,  y = -935.2,  z = 19.2 },
    { x = -70.2,   y = -1761.8, z = 29.5 },
    { x = 265.6,   y = -1261.3, z = 29.3 },
    { x = 819.7,   y = -1028.8, z = 26.4 },
    { x = 1208.9,  y = -1402.6, z = 35.2 },
    { x = 1181.4,  y = -330.8,  z = 69.3 },
    { x = 620.8,   y = 269.1,   z = 103.1 },
    { x = 2581.3,  y = 362.0,   z = 108.5 },
    { x = 176.6,   y = -1562.0, z = 29.3 },
}
