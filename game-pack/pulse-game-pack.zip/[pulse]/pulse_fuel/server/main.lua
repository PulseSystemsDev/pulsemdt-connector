local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_fuel') end)
    if ok and type(c) == 'table' then RCFG = c end
    TriggerClientEvent('pulse_fuel:remoteConfig', -1, {
        enabled = RCFG.enabled ~= false,
        pricePerLiter = RCFG.settings and tonumber(RCFG.settings.pricePerLiter) or nil,
        drainMultiplier = RCFG.settings and tonumber(RCFG.settings.drainMultiplier) or nil,
    })
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

RegisterNetEvent('pulse_fuel:requestConfig', function()
    local src = source
    TriggerClientEvent('pulse_fuel:remoteConfig', src, {
        enabled = RCFG.enabled ~= false,
        pricePerLiter = RCFG.settings and tonumber(RCFG.settings.pricePerLiter) or nil,
        drainMultiplier = RCFG.settings and tonumber(RCFG.settings.drainMultiplier) or nil,
    })
end)

-- Charges for a refuel: the client asks to buy N litres, the server prices it
-- and deducts from the bank. code paths: paid, free (economy off), declined.
RegisterNetEvent('pulse_fuel:buy', function(data)
    local src = source
    if RCFG.enabled == false then return end
    local liters = tonumber(data and data.liters)
    if not liters or liters <= 0 or liters > Config.TankSize + 5 then return end

    local price = RCFG.settings and tonumber(RCFG.settings.pricePerLiter) or Config.PricePerLiter
    local cost = math.floor(liters * price + 0.5)

    if cost <= 0 then
        TriggerClientEvent('pulse_fuel:approved', src, { liters = liters, cost = 0 })
        return
    end

    getCharId(src, function(charId)
        if not charId then
            TriggerClientEvent('pulse_fuel:declined', src, 'Load or select a character before buying fuel.')
            return
        end
        exports.pulsemdt:ApiRequest('POST', '/money', {
            charId = charId, account = 'bank', amount = -cost, reason = 'Fuel',
        }, function(code, res)
            if code == 200 and res and res.ok then
                TriggerClientEvent('pulse_fuel:approved', src, { liters = liters, cost = cost })
            elseif code == 403 then
                TriggerClientEvent('pulse_fuel:approved', src, { liters = liters, cost = 0 })
            elseif code == 402 then
                TriggerClientEvent('pulse_fuel:declined', src, 'You cannot afford that fuel.')
            else
                TriggerClientEvent('pulse_fuel:declined', src, 'The pump is not working right now.')
            end
        end)
    end)
end)
