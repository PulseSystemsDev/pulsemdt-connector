local DECOR = 'pulse_fuel_level'
DecorRegister(DECOR, 1)

local remoteEnabled = true
local remotePrice = nil
local remoteDrain = nil
local refueling = false
local hudShown = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function price()
    return remotePrice or Config.PricePerLiter
end

local function drainMult()
    return remoteDrain or 1.0
end

local function getFuel(veh)
    if DecorExistOn(veh, DECOR) then
        return DecorGetFloat(veh, DECOR)
    end
    local start = math.random(Config.StartFuel.min, Config.StartFuel.max) / 100.0 * Config.TankSize
    DecorSetFloat(veh, DECOR, start)
    return start
end

local function setFuel(veh, liters)
    liters = math.max(0.0, math.min(Config.TankSize + 0.0, liters))
    DecorSetFloat(veh, DECOR, liters)
    SetVehicleFuelLevel(veh, liters / Config.TankSize * 100.0)
    return liters
end

local function nearStation()
    local pos = GetEntityCoords(PlayerPedId())
    for _, s in ipairs(Config.Stations) do
        if #(pos - vector3(s.x, s.y, s.z)) <= Config.PumpRadius then
            return true
        end
    end
    return false
end

local function sendHud(liters)
    local pct = math.floor(liters / Config.TankSize * 100 + 0.5)
    SendNUIMessage({ action = 'fuel', data = { pct = pct } })
    if not hudShown then
        hudShown = true
        SendNUIMessage({ action = 'show' })
    end
end

local function hideHud()
    if hudShown then
        hudShown = false
        SendNUIMessage({ action = 'hide' })
    end
end

RegisterNetEvent('pulse_fuel:remoteConfig', function(cfg)
    if type(cfg) ~= 'table' then return end
    remoteEnabled = cfg.enabled ~= false
    remotePrice = tonumber(cfg.pricePerLiter)
    remoteDrain = tonumber(cfg.drainMultiplier)
    if not remoteEnabled then hideHud() end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1000)
    TriggerServerEvent('pulse_fuel:requestConfig')
end)

-- Drain + HUD loop.
CreateThread(function()
    while true do
        Wait(1000)
        if remoteEnabled then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then
                local fuel = getFuel(veh)
                if GetIsVehicleEngineRunning(veh) and not refueling then
                    local rpm = GetVehicleCurrentRpm(veh)
                    local burn = (Config.DrainPerMinute / 60.0) * (0.25 + rpm * 0.75) * drainMult()
                    fuel = setFuel(veh, fuel - burn)
                    if fuel <= 0.0 then
                        SetVehicleEngineOn(veh, false, true, true)
                        notify('~r~Fuel~s~ The tank is empty.')
                    end
                end
                sendHud(fuel)
            else
                hideHud()
            end
        end
    end
end)

-- Refuel prompt loop.
CreateThread(function()
    while true do
        local sleep = 700
        if remoteEnabled and not refueling then
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            if veh == 0 then
                local pos = GetEntityCoords(ped)
                veh = GetClosestVehicle(pos.x, pos.y, pos.z, 4.0, 0, 71)
            end
            if veh ~= 0 and DoesEntityExist(veh) and nearStation() then
                sleep = 0
                local fuel = getFuel(veh)
                local missing = Config.TankSize - fuel
                if missing >= 1.0 then
                    local cost = math.floor(missing * price() + 0.5)
                    BeginTextCommandDisplayHelp('STRING')
                    AddTextComponentSubstringPlayerName(('Press ~INPUT_CONTEXT~ to refuel (~g~$%d~s~)'):format(cost))
                    EndTextCommandDisplayHelp(0, false, true, -1)
                    if IsControlJustReleased(0, 38) then
                        TriggerServerEvent('pulse_fuel:buy', { liters = missing })
                        Wait(600)
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

RegisterNetEvent('pulse_fuel:approved', function(data)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then
        local pos = GetEntityCoords(ped)
        veh = GetClosestVehicle(pos.x, pos.y, pos.z, 4.0, 0, 71)
    end
    if veh == 0 or not DoesEntityExist(veh) then return end

    refueling = true
    local liters = tonumber(data.liters) or 0
    local start = getFuel(veh)
    local target = math.min(Config.TankSize + 0.0, start + liters)
    local seconds = math.max(2, math.floor(Config.FillSeconds * (liters / Config.TankSize)))
    local perTick = (target - start) / (seconds * 4)

    SetVehicleEngineOn(veh, false, true, true)
    for _ = 1, seconds * 4 do
        if not DoesEntityExist(veh) then break end
        start = setFuel(veh, start + perTick)
        sendHud(start)
        Wait(250)
    end
    refueling = false
    if (tonumber(data.cost) or 0) > 0 then
        notify(('~g~Fuel~s~ Tank filled: $%d.'):format(data.cost))
    else
        notify('~g~Fuel~s~ Tank filled.')
    end
end)

RegisterNetEvent('pulse_fuel:declined', function(msg)
    notify('~r~Fuel~s~ ' .. (msg or 'Refuel declined.'))
end)
