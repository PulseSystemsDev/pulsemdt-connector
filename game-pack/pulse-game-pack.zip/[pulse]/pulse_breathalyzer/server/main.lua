local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_breathalyzer') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function legalLimit()
    local v = RCFG.settings and tonumber(RCFG.settings.legalLimit)
    if v ~= nil then return v end
    return Config.LegalLimit
end

local function getDiscordId(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then return id:sub(9) end
    end
    return nil
end

RegisterNetEvent('pulse_breathalyzer:test', function(data)
    local src = source
    if not RCFG.enabled then
        TriggerClientEvent('pulse_breathalyzer:result', src, { error = 'The breathalyzer is disabled on this server.' })
        return
    end
    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'police', 'law') end)
    if not authorized then
        TriggerClientEvent('pulse_breathalyzer:result', src, { error = 'An on-duty law-enforcement role is required to run a test.' })
        return
    end

    local target = tonumber(data and data.target)
    if not target or not GetPlayerName(target) then
        TriggerClientEvent('pulse_breathalyzer:result', src, { error = 'No person nearby.' })
        return
    end
    if #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(GetPlayerPed(target))) > Config.Range + 3.0 then
        return
    end

    local bac = tonumber(Player(target).state.bac) or 0.0
    local limit = legalLimit()
    local over = bac >= limit

    TriggerClientEvent('pulse_breathalyzer:result', src, {
        name = GetPlayerName(target),
        bac = bac,
        limit = limit,
        over = over,
    })
    TriggerClientEvent('pulse_breathalyzer:tested', target, { bac = bac, over = over })

    exports.pulsemdt:ApiWrite('POST', '/logs', {
        discordId = getDiscordId(src),
        event = 'dui_test',
        details = ('%s breathalyzed %s: BAC %.3f (%s, limit %.2f)'):format(
            GetPlayerName(src), GetPlayerName(target), bac, over and 'OVER LIMIT' or 'under limit', limit),
    }, nil)
end)
