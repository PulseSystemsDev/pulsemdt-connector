# pulse_breathalyzer

`pulse_breathalyzer` lets an on-duty law-enforcement officer test the nearest player's blood alcohol content. Over-limit results are logged to PulseMDT.

## Requirements

- `pulsemdt`
- A script that sets the tested player's `bac` state bag; without one the reading is `0.00`
- `pulse_notify` is optional

## Installation

Keep the folder name `pulse_breathalyzer`, edit `config.lua`, then add `ensure pulse_breathalyzer` after `pulsemdt` in `server.cfg`.

## Usage and configuration

- `/breathalyze` tests the nearest player by default.
- `Config.Command` changes the command.
- `Config.Range` sets the maximum test distance.
- `Config.LegalLimit` sets the over-limit threshold.

The officer must be on duty with an eligible law-enforcement role.
