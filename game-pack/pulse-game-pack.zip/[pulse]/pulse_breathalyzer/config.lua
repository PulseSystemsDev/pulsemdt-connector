-- PulseMDT :: pulse_breathalyzer
--
-- An on-duty officer tests the nearest person. The reading comes from the
-- player statebag `bac` (a number set by whatever alcohol/drink script your
-- server runs, e.g. `Player(source).state.bac = 0.12`); with no alcohol
-- script it reads 0.00. Over-limit results are logged to the CAD. The legal
-- limit can also be changed from the dashboard's Scripts page.

Config = {}

-- Command an on-duty officer uses to test the nearest person.
Config.Command = 'breathalyze'

-- How close (metres) the person must be.
Config.Range = 3.0

-- BAC at or above this is over the limit.
Config.LegalLimit = 0.08
