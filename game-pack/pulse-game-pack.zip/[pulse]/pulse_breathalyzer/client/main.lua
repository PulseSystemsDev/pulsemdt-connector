local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function nearestPlayerServerId()
    local me = PlayerPedId()
    local myCoords = GetEntityCoords(me)
    local closest, closestDist = nil, Config.Range + 0.0
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= me and DoesEntityExist(ped) then
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= closestDist then
                closest, closestDist = pid, dist
            end
        end
    end
    if closest then return GetPlayerServerId(closest) end
    return nil
end

RegisterCommand(Config.Command, function()
    local target = nearestPlayerServerId()
    if not target then
        notify('~y~PulseMDT~s~ No person within range.')
        return
    end
    local ped = PlayerPedId()
    RequestAnimDict('mp_cp_stolen_tut')
    local deadline = GetGameTimer() + 3000
    while not HasAnimDictLoaded('mp_cp_stolen_tut') and GetGameTimer() < deadline do Wait(25) end
    if HasAnimDictLoaded('mp_cp_stolen_tut') then
        TaskPlayAnim(ped, 'mp_cp_stolen_tut', 'b_inspect_jewel', 3.0, -1, 2500, 49, 0, false, false, false)
    end
    TriggerServerEvent('pulse_breathalyzer:test', { target = target })
end, false)

RegisterNetEvent('pulse_breathalyzer:result', function(res)
    res = res or {}
    if res.error then
        notify('~r~PulseMDT~s~ ' .. res.error)
        return
    end
    if res.over then
        notify(('~r~BREATHALYZER~s~\n%s blew ~r~%.3f~s~ (limit %.2f)\n~r~OVER THE LIMIT~s~'):format(res.name, res.bac, res.limit))
    else
        notify(('~g~BREATHALYZER~s~\n%s blew ~g~%.3f~s~ (limit %.2f)'):format(res.name, res.bac, res.limit))
    end
end)

RegisterNetEvent('pulse_breathalyzer:tested', function(res)
    res = res or {}
    notify(('~b~PulseMDT~s~ You blew %.3f%s'):format(res.bac or 0, res.over and ' ~r~(over the limit)~s~' or ''))
end)
