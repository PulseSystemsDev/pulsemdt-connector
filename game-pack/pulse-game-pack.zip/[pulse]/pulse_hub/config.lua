-- PulseMDT :: pulse_hub (Officer utility hub)
--
-- One menu for on-duty conveniences: patrol garage, armory, and quick actions.
-- Every entry is permission-checked SERVER-SIDE against the officer's CAD
-- department and rank, so what an officer can access is governed by what
-- staff set on the web dashboard.
--
-- Duty on/off stays in the MDT tablet; the hub requires being on duty.
-- Reaches the CAD through the main `pulsemdt` resource, so no API key here.

Config = {}

-- Command that opens the hub while on duty.
Config.Command = 'leo'

-- Key that opens the hub. Set to false to disable.
Config.OpenKey = 'F10'

-- Rank levels. An officer's CAD role is matched (case-insensitive) against
-- these names; unlisted roles get level 1. Higher level = more access.
Config.RankLevels = {
    ['Cadet']      = 0,
    ['Officer']    = 1,
    ['Corporal']   = 2,
    ['Sergeant']   = 3,
    ['Lieutenant'] = 4,
    ['Captain']    = 5,
    ['Chief']      = 6,
}

-- Patrol garage. minRank uses the levels above. Restrict an entry to specific
-- departments with `departments = { 'Police' }` (omit for all departments).
Config.Garage = {
    { label = 'Police Cruiser',        model = 'police',   minRank = 0, jobs = { 'police', 'law' } },
    { label = 'Police Buffalo',        model = 'police2',  minRank = 1, jobs = { 'police', 'law' } },
    { label = 'Police Interceptor',    model = 'police3',  minRank = 2, jobs = { 'police', 'law' } },
    { label = 'Unmarked Cruiser',      model = 'police4',  minRank = 3, jobs = { 'police', 'law' } },
    { label = 'Police Riot Van',       model = 'riot',     minRank = 4, jobs = { 'police', 'law' } },
    { label = 'Ambulance',             model = 'ambulance', minRank = 0, jobs = { 'ems', 'fire' }, departments = { 'EMS', 'Fire' } },
    { label = 'Fire Truck',            model = 'firetruk', minRank = 0, jobs = { 'fire' }, departments = { 'Fire' } },
}

-- Armory loadouts. Weapon names are GTA weapon hashes by name.
Config.Armory = {
    {
        label = 'Standard Issue', minRank = 0, jobs = { 'police', 'law' },
        weapons = {
            { weapon = 'WEAPON_COMBATPISTOL', ammo = 120 },
            { weapon = 'WEAPON_STUNGUN',      ammo = 5 },
            { weapon = 'WEAPON_NIGHTSTICK',   ammo = 0 },
            { weapon = 'WEAPON_FLASHLIGHT',   ammo = 0 },
        },
    },
    {
        label = 'Patrol Rifle', minRank = 2, jobs = { 'police', 'law' },
        weapons = {
            { weapon = 'WEAPON_CARBINERIFLE', ammo = 180 },
        },
    },
    {
        label = 'Tactical', minRank = 4, jobs = { 'police', 'law' },
        weapons = {
            { weapon = 'WEAPON_SPECIALCARBINE', ammo = 240 },
            { weapon = 'WEAPON_PUMPSHOTGUN',    ammo = 32 },
            { weapon = 'WEAPON_SMOKEGRENADE',   ammo = 3 },
        },
    },
}

-- Quick actions shown in the hub.
Config.Actions = {
    armor  = true,   -- apply body armor
    heal   = true,   -- restore health
    repair = true,   -- repair current vehicle
    despawn = true,  -- delete current patrol vehicle
    panic  = true,   -- alert dispatch with the officer's position
}
