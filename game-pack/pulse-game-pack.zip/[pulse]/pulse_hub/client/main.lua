local hubOpen = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function sendNUI(action, data)
    SendNUIMessage({ action = action, data = data or {} })
end

local function closeHub()
    if not hubOpen then return end
    hubOpen = false
    SetNuiFocus(false, false)
    sendNUI('close', {})
end

RegisterCommand(Config.Command, function()
    if hubOpen then
        closeHub()
    else
        TriggerServerEvent('pulse_hub:open')
    end
end, false)

if Config.OpenKey then
    RegisterKeyMapping(Config.Command, 'PulseMDT: Officer hub', 'keyboard', Config.OpenKey)
end

RegisterNetEvent('pulse_hub:menu', function(menu)
    hubOpen = true
    SetNuiFocus(true, true)
    sendNUI('menu', menu)
end)

RegisterNetEvent('pulse_hub:denied', function(msg)
    notify('~y~PulseMDT~s~ ' .. (msg or 'Access denied.'))
end)

RegisterNetEvent('pulse_hub:notify', function(msg)
    notify('~g~PulseMDT~s~ ' .. (msg or ''))
end)

RegisterNUICallback('close', function(_, cb)
    closeHub()
    cb({})
end)

RegisterNUICallback('spawnVehicle', function(data, cb)
    if data and data.index then TriggerServerEvent('pulse_hub:spawnVehicle', data.index) end
    closeHub()
    cb({})
end)

RegisterNUICallback('giveLoadout', function(data, cb)
    if data and data.index then TriggerServerEvent('pulse_hub:giveLoadout', data.index) end
    cb({})
end)

RegisterNUICallback('action', function(data, cb)
    if data and data.action then TriggerServerEvent('pulse_hub:action', data.action) end
    cb({})
end)

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local deadline = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return nil end
        Wait(25)
    end
    return hash
end

local spawnedVehicle = nil

RegisterNetEvent('pulse_hub:doSpawnVehicle', function(model, callsign)
    local hash = loadModel(model)
    if not hash then
        notify('~r~PulseMDT~s~ Vehicle model failed to load.')
        return
    end
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)

    if spawnedVehicle and DoesEntityExist(spawnedVehicle) then
        DeleteVehicle(spawnedVehicle)
    end

    local veh = CreateVehicle(hash, pos.x, pos.y, pos.z, heading, true, false)
    SetModelAsNoLongerNeeded(hash)
    if callsign and callsign ~= '' then
        SetVehicleNumberPlateText(veh, tostring(callsign):sub(1, 8))
    end
    SetVehicleEngineOn(veh, true, true, false)
    SetPedIntoVehicle(ped, veh, -1)
    spawnedVehicle = veh
    notify('~g~PulseMDT~s~ Vehicle ready.')
end)

RegisterNetEvent('pulse_hub:doAction', function(action)
    local ped = PlayerPedId()
    if action == 'armor' then
        SetPedArmour(ped, 100)
        notify('~g~PulseMDT~s~ Body armor applied.')
    elseif action == 'heal' then
        SetEntityHealth(ped, GetEntityMaxHealth(ped))
        ClearPedBloodDamage(ped)
        notify('~g~PulseMDT~s~ Patched up.')
    elseif action == 'repair' then
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 then
            notify('~y~PulseMDT~s~ You are not in a vehicle.')
            return
        end
        SetVehicleFixed(veh)
        SetVehicleDirtLevel(veh, 0.0)
        SetVehicleEngineHealth(veh, 1000.0)
        notify('~g~PulseMDT~s~ Vehicle repaired.')
    elseif action == 'despawn' then
        local veh = GetVehiclePedIsIn(ped, false)
        if veh == 0 and spawnedVehicle and DoesEntityExist(spawnedVehicle) then
            veh = spawnedVehicle
        end
        if veh ~= 0 and DoesEntityExist(veh) then
            DeleteVehicle(veh)
            if veh == spawnedVehicle then spawnedVehicle = nil end
            notify('~g~PulseMDT~s~ Vehicle returned.')
        else
            notify('~y~PulseMDT~s~ No patrol vehicle to return.')
        end
    end
end)
