local function getOfficer(src)
    local ok, officer = pcall(function()
        return exports.pulsemdt:GetOfficer(src)
    end)
    if ok then return officer end
    return nil
end

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_hub') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local ACTION_SETTING = { armor = 'actionArmor', heal = 'actionHeal', repair = 'actionRepair', despawn = 'actionDespawn', panic = 'actionPanic' }
local function actionAllowed(action)
    if not Config.Actions[action] then return false end
    local v = RCFG.settings and RCFG.settings[ACTION_SETTING[action] or '']
    if v == nil then return true end
    return v == true
end

local function effectiveActions()
    local out = {}
    for action in pairs(ACTION_SETTING) do
        out[action] = actionAllowed(action)
    end
    return out
end

local function rankLevel(role)
    if type(role) ~= 'string' then return 1 end
    for name, level in pairs(Config.RankLevels) do
        if name:lower() == role:lower() then return level end
    end
    return 1
end

local function deptAllowed(entry, department)
    if not entry.departments then return true end
    for _, d in ipairs(entry.departments) do
        if d:lower() == tostring(department or ''):lower() then return true end
    end
    return false
end

local function cadJobsAllowed(src, entry)
    if type(entry.jobs) ~= 'table' or #entry.jobs == 0 then return true end
    local ok, allowed = pcall(function()
        return exports.pulsemdt:HasCadJob(src, table.unpack(entry.jobs))
    end)
    return ok and allowed == true
end

local function allowedEntries(src, list, officer)
    local level = rankLevel(officer.role)
    local out = {}
    for i, entry in ipairs(list) do
        if level >= (entry.minRank or 0) and deptAllowed(entry, officer.department) and cadJobsAllowed(src, entry) then
            out[#out + 1] = { index = i, label = entry.label, minRank = entry.minRank or 0 }
        end
    end
    return out
end

RegisterNetEvent('pulse_hub:open', function()
    local src = source
    if not RCFG.enabled then
        TriggerClientEvent('pulse_hub:denied', src, 'The officer hub is disabled on this server.')
        return
    end
    local officer = getOfficer(src)
    if not officer then
        TriggerClientEvent('pulse_hub:denied', src, 'Go on duty in the MDT before opening the hub.')
        return
    end
    TriggerClientEvent('pulse_hub:menu', src, {
        officer = {
            name       = officer.characterName,
            department = officer.department,
            role       = officer.role,
            callsign   = officer.callsign,
        },
        garage  = allowedEntries(src, Config.Garage, officer),
        armory  = allowedEntries(src, Config.Armory, officer),
        actions = effectiveActions(),
    })
end)

RegisterNetEvent('pulse_hub:spawnVehicle', function(index)
    local src = source
    if not RCFG.enabled then return end
    local officer = getOfficer(src)
    if not officer then return end
    local entry = Config.Garage[tonumber(index) or -1]
    if not entry then return end
    if rankLevel(officer.role) < (entry.minRank or 0) or not deptAllowed(entry, officer.department) or not cadJobsAllowed(src, entry) then
        TriggerClientEvent('pulse_hub:denied', src, 'You do not have access to that vehicle.')
        return
    end
    TriggerClientEvent('pulse_hub:doSpawnVehicle', src, entry.model, officer.callsign)
end)

RegisterNetEvent('pulse_hub:giveLoadout', function(index)
    local src = source
    if not RCFG.enabled then return end
    local officer = getOfficer(src)
    if not officer then return end
    local entry = Config.Armory[tonumber(index) or -1]
    if not entry then return end
    if rankLevel(officer.role) < (entry.minRank or 0) or not deptAllowed(entry, officer.department) or not cadJobsAllowed(src, entry) then
        TriggerClientEvent('pulse_hub:denied', src, 'You do not have access to that loadout.')
        return
    end
    local ped = GetPlayerPed(src)
    for _, w in ipairs(entry.weapons) do
        GiveWeaponToPed(ped, joaat(w.weapon), w.ammo or 0, false, false)
    end
    TriggerClientEvent('pulse_hub:notify', src, ('%s loadout issued.'):format(entry.label))
end)

RegisterNetEvent('pulse_hub:action', function(action)
    local src = source
    if not RCFG.enabled then return end
    local officer = getOfficer(src)
    if not officer then return end
    if not actionAllowed(action) then return end

    if action == 'panic' then
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        exports.pulsemdt:ApiRequest('POST', '/panic', {
            officerName = officer.characterName, department = officer.department,
            role = officer.role, callsign = officer.callsign,
            x = coords.x, y = coords.y, z = coords.z,
        }, function(code)
            TriggerClientEvent('pulse_hub:notify', src, code == 200 and 'Panic alert sent to dispatch.' or 'Failed to send panic alert.')
        end)
        return
    end

    TriggerClientEvent('pulse_hub:doAction', src, action)
end)
