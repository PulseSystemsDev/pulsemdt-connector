# pulse_hub

`pulse_hub` is an on-duty officer utility menu with department-aware garage vehicles, armory items, and common field actions.

## Requirements

- `pulsemdt`
- `pulse_notify` optional

## Installation

Start `pulse_hub` after `pulsemdt`, then configure rank mappings, vehicles, armory entries, and actions in `config.lua`.

## Usage

- `/leo` opens the hub by default.
- `F10` opens the hub by default.

Every action is checked server-side against the user's current PulseMDT duty role and rank. Duty itself is managed through the MDT or a duty-station resource. Change the command or key with `Config.Command` and `Config.OpenKey`.
