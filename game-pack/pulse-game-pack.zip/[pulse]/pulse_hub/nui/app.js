const RESOURCE = 'pulse_hub';

const hub = document.getElementById('hub');
const panes = {
  garage: document.getElementById('tab-garage'),
  armory: document.getElementById('tab-armory'),
  actions: document.getElementById('tab-actions'),
};

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function item(label, sub, onClick) {
  const el = document.createElement('div');
  el.className = 'item';
  const l = document.createElement('span');
  l.textContent = label;
  el.appendChild(l);
  if (sub) {
    const s = document.createElement('span');
    s.className = 'rank';
    s.textContent = sub;
    el.appendChild(s);
  }
  el.addEventListener('click', onClick);
  return el;
}

function emptyItem(text) {
  const el = document.createElement('div');
  el.className = 'item empty';
  el.textContent = text;
  return el;
}

const ACTION_LABELS = {
  armor: 'Apply body armor',
  heal: 'Patch up injuries',
  repair: 'Repair current vehicle',
  despawn: 'Return patrol vehicle',
  panic: 'Trigger panic alert',
};

function render(menu) {
  document.getElementById('oName').textContent = menu.officer?.name || 'Officer Hub';
  const oMeta = document.getElementById('oMeta');
  oMeta.innerHTML = '';
  if (menu.officer?.callsign) {
    const cs = document.createElement('span');
    cs.className = 'callsign';
    cs.textContent = menu.officer.callsign;
    oMeta.appendChild(cs);
  }
  const rest = [menu.officer?.role, menu.officer?.department].filter(Boolean).join(' · ');
  if (rest) oMeta.appendChild(document.createTextNode(rest));

  panes.garage.innerHTML = '';
  const garage = menu.garage || [];
  if (garage.length === 0) panes.garage.appendChild(emptyItem('No vehicles available at your rank.'));
  for (const g of garage) {
    panes.garage.appendChild(item(g.label, null, () => post('spawnVehicle', { index: g.index })));
  }

  panes.armory.innerHTML = '';
  const armory = menu.armory || [];
  if (armory.length === 0) panes.armory.appendChild(emptyItem('No loadouts available at your rank.'));
  for (const a of armory) {
    panes.armory.appendChild(item(a.label, null, () => post('giveLoadout', { index: a.index })));
  }

  panes.actions.innerHTML = '';
  const actions = menu.actions || {};
  let any = false;
  for (const key of Object.keys(ACTION_LABELS)) {
    if (actions[key]) {
      any = true;
      panes.actions.appendChild(item(ACTION_LABELS[key], null, () => post('action', { action: key })));
    }
  }
  if (!any) panes.actions.appendChild(emptyItem('No quick actions enabled.'));

  hub.classList.remove('hidden');
}

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t === tab));
    for (const key of Object.keys(panes)) {
      panes[key].classList.toggle('hidden', key !== tab.dataset.tab);
    }
  });
});

function close() {
  hub.classList.add('hidden');
  post('close');
}

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'menu') render(m.data || {});
  if (m.action === 'close') hub.classList.add('hidden');
});

document.getElementById('x').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (hub.classList.contains('hidden')) return;
  if (e.key === 'Escape') close();
});
