local charCache  = {}   -- discordId -> array of character tables (offline fallback + ownership checks)
local activeChar = {}   -- src -> character table currently being played
local lastPos    = {}   -- src -> latest "x,y,z,h" string reported by the client

local conflicting = { 'qb-core', 'qbx_core', 'es_extended' }
local dormant = false
for _, res in ipairs(conflicting) do
    if GetResourceState(res) == 'started' then dormant = true break end
end
if dormant then
    print('^1[pulse_core]^7 A framework (QBCore/ESX/qbox) is running. pulse_core is for standalone servers only and will stay dormant.')
end

local function getDiscordId(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then
            return id:sub(9)
        end
    end
    return nil
end

local function ownedCharacter(discordId, charId)
    for _, c in ipairs(charCache[discordId] or {}) do
        if c.id == charId then return c end
    end
    return nil
end

local function validPedModel(model)
    for _, m in ipairs(Config.PedModels) do
        if m.model == model then return true end
    end
    return false
end

local function spawnPointLabels()
    local out = {}
    for i, p in ipairs(Config.SpawnPoints) do
        out[#out + 1] = { index = i, label = p.label }
    end
    return out
end

local function escapePattern(s)
    return (s:gsub('[%^%$%(%)%%%.%[%]%*%+%-%?]', '%%%0'))
end

-- Whole-word occupation match so short tokens cannot false-positive
-- ("dr" must not match "Driver", "fire" must not match "Firearms").
local function jobContainsWord(job, word)
    if word == '' then return false end
    return job:find('%f[%w]' .. escapePattern(word) .. '%f[%W]') ~= nil
end

local function jobMatches(char, group)
    local job = tostring(char.job or ''):lower()
    if job == '' then return false end
    for _, alias in ipairs(group.jobs or {}) do
        if jobContainsWord(job, alias:lower()) then return true end
    end
    return false
end

-- Extra spawn options a character's occupation unlocks (values are validated
-- again at select time, so these are display hints only).
local function jobSpawnsFor(char)
    local out = {}
    for g, group in ipairs(Config.JobSpawns or {}) do
        if jobMatches(char, group) then
            for i, spawn in ipairs(group.spawns or {}) do
                out[#out + 1] = {
                    value = ('job:%d:%d'):format(g, i),
                    label = spawn.label,
                    kind  = group.name or 'Duty station',
                }
            end
        end
    end
    return out
end

local function selectorText(value, fallback, maxLength)
    if type(value) ~= 'string' then return fallback end
    local clean = value:gsub('^%s+', ''):gsub('%s+$', '')
    if clean == '' then return fallback end
    return clean:sub(1, maxLength or 160)
end

local function selectorPayload()
    local cfg = type(Config.Selector) == 'table' and Config.Selector or {}
    local backgrounds = cfg.Backgrounds
    if type(backgrounds) ~= 'table' or #backgrounds == 0 then
        backgrounds = type(Config.Backgrounds) == 'table' and Config.Backgrounds or {}
    end

    local usableBackgrounds = {}
    for _, value in ipairs(backgrounds) do
        if type(value) == 'string' and value ~= '' and #value <= 500 then
            usableBackgrounds[#usableBackgrounds + 1] = value
        end
    end

    local accent = selectorText(cfg.AccentColor, '#2f9bd6', 20)
    if not accent:match('^#%x%x%x%x%x%x$') and not accent:match('^#%x%x%x$') then
        accent = '#2f9bd6'
    end

    local logo = cfg.LogoURL or Config.LogoURL
    if type(logo) ~= 'string' or logo == '' or #logo > 500 then logo = nil end

    return {
        serverName         = selectorText(cfg.ServerName, 'Pulse Roleplay', 80),
        screenLabel        = selectorText(cfg.ScreenLabel, 'Character selection', 60),
        title              = selectorText(cfg.Title, 'Choose your character', 100),
        subtitle           = selectorText(cfg.Subtitle, 'Select who you want to enter the city as, or create a new profile.', 220),
        visualTitle        = selectorText(cfg.VisualTitle, 'Welcome back', 100),
        visualSubtitle     = selectorText(cfg.VisualSubtitle, 'Pick up where you left off. Your character data stays synced with PulseMDT.', 220),
        logo               = logo,
        background         = #usableBackgrounds > 0 and usableBackgrounds[math.random(#usableBackgrounds)] or nil,
        backgroundPosition = selectorText(cfg.BackgroundPosition, 'center center', 60),
        accentColor        = accent,
    }
end

local function sendCharacters(src, offline)
    local discordId = getDiscordId(src)
    local chars = charCache[discordId] or {}
    for _, c in ipairs(chars) do
        c.job_spawns = jobSpawnsFor(c)
    end
    local selector = selectorPayload()
    TriggerClientEvent('pulse_core:characters', src, {
        characters    = chars,
        activeCharId  = activeChar[src] and activeChar[src].id or nil,
        offline       = offline == true,
        canCreate     = Config.AllowCreate,
        canDelete     = Config.AllowDelete,
        maxCharacters = Config.MaxCharacters,
        pedModels     = Config.PedModels,
        hasActive     = activeChar[src] ~= nil,
        spawnSelector = Config.SpawnSelector,
        allowLast     = Config.AllowLastPosition,
        spawnPoints   = spawnPointLabels(),
        selector      = selector,
        -- Kept for compatibility with the 0.1 NUI during rolling updates.
        logo          = selector.logo,
        background    = selector.background,
    })
end

RegisterNetEvent('pulse_core:requestCharacters', function()
    local src = source
    if dormant then return end
    local discordId = getDiscordId(src)
    if not discordId then
        TriggerClientEvent('pulse_core:fatal', src, 'Discord must be linked to FiveM to play here.', selectorPayload())
        return
    end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        if code == 200 and type(res) == 'table' and type(res.characters) == 'table' then
            charCache[discordId] = res.characters
            sendCharacters(src, false)
        elseif charCache[discordId] then
            sendCharacters(src, true)
        else
            local selector = selectorPayload()
            TriggerClientEvent('pulse_core:characters', src, {
                offline = true, characters = {}, unavailable = true,
                selector = selector, logo = selector.logo, background = selector.background,
            })
        end
    end)
end)

local function parsePos(str)
    if type(str) ~= 'string' then return nil end
    local x, y, z, h = str:match('^(-?[%d%.]+),(-?[%d%.]+),(-?[%d%.]+),(-?[%d%.]+)$')
    if not x then return nil end
    return { x = tonumber(x), y = tonumber(y), z = tonumber(z), heading = tonumber(h) }
end

-- Resolves the player's spawn choice against the server config; anything
-- invalid falls back safely (never trusts client coordinates).
local function resolveSpawn(char, choice)
    local pointIndex = tonumber(choice)
    if pointIndex and Config.SpawnPoints[pointIndex] then
        return Config.SpawnPoints[pointIndex]
    end
    if type(choice) == 'string' then
        local g, i = choice:match('^job:(%d+):(%d+)$')
        if g then
            local group = Config.JobSpawns[tonumber(g)]
            local spawn = group and group.spawns[tonumber(i)]
            if spawn and jobMatches(char, group) then return spawn end
        end
        if choice == 'last' and Config.AllowLastPosition then
            local last = parsePos(char.last_pos)
            if last then return last end
        end
    end
    return parsePos(char.last_pos) or Config.SpawnPoints[1] or Config.DefaultSpawn
end

RegisterNetEvent('pulse_core:selectCharacter', function(charId, spawnChoice)
    local src = source
    if dormant then return end
    local discordId = getDiscordId(src)
    if not discordId then return end
    local char = ownedCharacter(discordId, tonumber(charId))
    if not char then
        TriggerClientEvent('pulse_core:error', src, 'That character could not be found.')
        return
    end

    if activeChar[src] then
        TriggerEvent('pulse_core:characterUnloaded', src, activeChar[src])
    end
    activeChar[src] = char
    exports.pulsemdt:ApiWrite('POST', '/characters/active', { discordId = discordId, charId = char.id }, nil)

    local spawn = resolveSpawn(char, spawnChoice)
    TriggerClientEvent('pulse_core:spawnCharacter', src, char, spawn)
    TriggerEvent('pulse_core:characterLoaded', src, char)
end)

RegisterNetEvent('pulse_core:createCharacter', function(data)
    local src = source
    if dormant or not Config.AllowCreate then return end
    local discordId = getDiscordId(src)
    if not discordId then return end
    data = data or {}

    if #(charCache[discordId] or {}) >= Config.MaxCharacters then
        TriggerClientEvent('pulse_core:error', src, ('Character limit reached (%d).'):format(Config.MaxCharacters))
        return
    end

    local name = tostring(data.name or ''):gsub('^%s+', ''):gsub('%s+$', ''):gsub('%s+', ' ')
    if #name < 3 or #name > 60 or not name:match("^[%a][%a%s%-'%.]+$") or not name:find(' ') then
        TriggerClientEvent('pulse_core:error', src, 'Enter a valid first and last name.')
        return
    end
    local dob = tostring(data.dob or '')
    if not dob:match('^%d%d%d%d%-%d%d%-%d%d$') then
        TriggerClientEvent('pulse_core:error', src, 'Enter a valid date of birth.')
        return
    end
    local gender = data.gender == 'Female' and 'Female' or 'Male'
    local pedModel = validPedModel(data.pedModel) and data.pedModel or Config.PedModels[1].model

    exports.pulsemdt:ApiRequest('POST', '/characters', {
        discordId     = discordId,
        name          = name,
        date_of_birth = dob,
        gender        = gender,
        height        = tostring(data.height or ''):sub(1, 20),
        job           = tostring(data.job or 'Civilian'):sub(1, 60),
        ped_model     = pedModel,
    }, function(code, res)
        if code == 201 and res and res.id then
            local char = {
                id = res.id, name = name, date_of_birth = dob, gender = gender,
                height = data.height, job = data.job or 'Civilian',
                license_status = 'Valid', ped_model = pedModel,
            }
            charCache[discordId] = charCache[discordId] or {}
            charCache[discordId][#charCache[discordId] + 1] = char
            sendCharacters(src, false)
        elseif code == 0 then
            TriggerClientEvent('pulse_core:error', src, 'The CAD is offline; characters cannot be created right now.')
        else
            TriggerClientEvent('pulse_core:error', src, 'Character creation failed.')
        end
    end)
end)

RegisterNetEvent('pulse_core:deleteCharacter', function(charId)
    local src = source
    if dormant or not Config.AllowDelete then return end
    local discordId = getDiscordId(src)
    if not discordId then return end
    charId = tonumber(charId)
    local char = ownedCharacter(discordId, charId)
    if not char then return end
    if activeChar[src] and activeChar[src].id == charId then
        TriggerClientEvent('pulse_core:error', src, 'Switch off this character before deleting it.')
        return
    end

    exports.pulsemdt:ApiRequest('DELETE', '/characters/' .. charId .. '?discordId=' .. discordId, nil, function(code, res)
        if code == 200 then
            local list = charCache[discordId] or {}
            for i, c in ipairs(list) do
                if c.id == charId then table.remove(list, i) break end
            end
            sendCharacters(src, false)
        elseif code == 403 then
            TriggerClientEvent('pulse_core:error', src, (res and res.error) or 'Character deletion is staff-only on this server.')
        elseif code == 0 then
            TriggerClientEvent('pulse_core:error', src, 'The CAD is offline; try again later.')
        else
            TriggerClientEvent('pulse_core:error', src, 'Could not delete that character.')
        end
    end)
end)

RegisterNetEvent('pulse_core:unload', function()
    local src = source
    if dormant then return end
    if activeChar[src] then
        TriggerEvent('pulse_core:characterUnloaded', src, activeChar[src])
        activeChar[src] = nil
    end
end)

RegisterNetEvent('pulse_core:saveAppearance', function(jsonStr)
    local src = source
    if dormant then return end
    local char = activeChar[src]
    if not char or type(jsonStr) ~= 'string' or jsonStr == '' or #jsonStr > 100000 then return end
    local ok = pcall(json.decode, jsonStr)
    if not ok then return end
    local discordId = getDiscordId(src)
    if not discordId then return end
    char.appearance = jsonStr
    exports.pulsemdt:ApiWrite('PATCH', '/characters/' .. char.id, { discordId = discordId, appearance = jsonStr }, nil)
end)

RegisterNetEvent('pulse_core:reportPosition', function(pos)
    local src = source
    if dormant then return end
    local char = activeChar[src]
    if not char or type(pos) ~= 'string' or #pos > 120 or not parsePos(pos) then return end
    lastPos[src] = pos
    local discordId = getDiscordId(src)
    if not discordId then return end
    -- Interval saves are best-effort (dropped while offline); the disconnect
    -- save below queues, so the final position is never lost.
    exports.pulsemdt:ApiRequest('PATCH', '/characters/' .. char.id, { discordId = discordId, last_pos = pos }, nil)
end)

AddEventHandler('playerDropped', function()
    local src = source
    local char = activeChar[src]
    if char then
        TriggerEvent('pulse_core:characterUnloaded', src, char)
        -- The ped usually still exists during playerDropped; grabbing its live
        -- coords beats the last interval report (up to SaveInterval stale).
        local ped = GetPlayerPed(src)
        if ped and ped > 0 then
            local c = GetEntityCoords(ped)
            if c and (c.x ~= 0.0 or c.y ~= 0.0) then
                lastPos[src] = ('%.1f,%.1f,%.1f,%.1f'):format(c.x, c.y, c.z, GetEntityHeading(ped))
            end
        end
        local discordId = getDiscordId(src)
        if discordId and lastPos[src] then
            char.last_pos = lastPos[src]
            exports.pulsemdt:ApiWrite('PATCH', '/characters/' .. char.id, { discordId = discordId, last_pos = lastPos[src] }, nil)
        end
    end
    activeChar[src] = nil
    lastPos[src] = nil
end)

exports('GetCharacter', function(src)
    return activeChar[src]
end)

exports('GetCharacterId', function(src)
    return activeChar[src] and activeChar[src].id or nil
end)

exports('IsLoaded', function(src)
    return activeChar[src] ~= nil
end)

exports('GetAllLoaded', function()
    local out = {}
    for src, char in pairs(activeChar) do
        out[#out + 1] = { source = src, character = char }
    end
    return out
end)

-- ── Economy ─────────────────────────────────────────────────────────────────
-- Money lives in the CAD (characters.cash/bank) behind the guild's Economy
-- feature toggle; when that is off the API refuses and these no-op.
local economyEnabled = nil   -- nil = unknown, checked lazily

local function notifyMoney(src, msg)
    TriggerClientEvent('pulse_core:notify', src, msg)
end

local function adjustMoney(src, account, amount, reason, cb)
    local char = activeChar[src]
    if not char then
        if cb then cb(false, 'no_character') end
        return
    end
    exports.pulsemdt:ApiRequest('POST', '/money', {
        charId  = char.id,
        account = account == 'cash' and 'cash' or 'bank',
        amount  = amount,
        reason  = reason or 'Adjustment',
    }, function(code, res)
        if code == 200 and res and res.ok then
            economyEnabled = true
            if cb then cb(true, res) end
        elseif code == 403 then
            economyEnabled = false
            if cb then cb(false, 'disabled') end
        elseif code == 402 then
            if cb then cb(false, 'insufficient', res) end
        else
            if cb then cb(false, 'error') end
        end
    end)
end

exports('AddMoney', function(src, account, amount, reason, cb)
    if not (tonumber(amount) and tonumber(amount) > 0) then
        if cb then cb(false, 'invalid') end
        return
    end
    adjustMoney(src, account, tonumber(amount), reason, cb)
end)

exports('RemoveMoney', function(src, account, amount, reason, cb)
    if not (tonumber(amount) and tonumber(amount) > 0) then
        if cb then cb(false, 'invalid') end
        return
    end
    adjustMoney(src, account, -tonumber(amount), reason, cb)
end)

exports('GetMoney', function(src, cb)
    local char = activeChar[src]
    if not char then
        if cb then cb(nil) end
        return
    end
    exports.pulsemdt:ApiRequest('GET', '/money?charId=' .. char.id, nil, function(code, res)
        if code == 200 and res then
            economyEnabled = res.enabled ~= false
            if cb then cb(res.enabled ~= false and { cash = res.cash, bank = res.bank } or nil) end
        else
            if cb then cb(nil) end
        end
    end)
end)

RegisterNetEvent('pulse_core:requestBalance', function()
    local src = source
    local char = activeChar[src]
    if not char then return end
    exports.pulsemdt:ApiRequest('GET', '/money?charId=' .. char.id, nil, function(code, res)
        if code == 200 and res and res.enabled ~= false then
            economyEnabled = true
            notifyMoney(src, ('~b~Bank~s~ $%.2f  ~g~Cash~s~ $%.2f'):format(res.bank or 0, res.cash or 0))
        elseif code == 200 then
            economyEnabled = false
            notifyMoney(src, 'The economy is disabled on this server.')
        else
            notifyMoney(src, '~r~Balance unavailable right now.')
        end
    end)
end)

-- Payday loop: everyone with a loaded character earns a salary into their
-- bank. Amount and interval come from the dashboard (Scripts page) with
-- config.lua as fallback. Backs off while the guild's Economy feature is off
-- and rechecks roughly hourly.
local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_core') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)
local function remoteSetting(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    if v == nil then return fallback end
    return v
end

local function hasJob(char)
    local job = tostring(char.job or ''):gsub('^%s+', ''):gsub('%s+$', ''):lower()
    for _, v in ipairs(Config.JoblessValues) do
        if job == v:lower() then return false end
    end
    return true
end

-- Parses the dashboard's "police = 500, ems = 450" rules string into the
-- same shape as Config.Salary.jobRates.
local function parseSalaryRules(str)
    local rules = {}
    for pair in tostring(str or ''):gmatch('[^,]+') do
        local match, amount = pair:match('^%s*(.-)%s*=%s*(%d+%.?%d*)%s*$')
        if match and match ~= '' and tonumber(amount) then
            rules[#rules + 1] = { match = match:lower(), amount = tonumber(amount) }
        end
    end
    return rules
end

local function salaryFor(char, baseSalary, rules)
    local job = tostring(char.job or ''):lower()
    for _, rule in ipairs(rules) do
        if jobContainsWord(job, rule.match) then return rule.amount end
    end
    for _, rule in ipairs(Config.Salary.jobRates or {}) do
        if rule.match and jobContainsWord(job, tostring(rule.match):lower()) then return rule.amount end
    end
    return baseSalary
end

CreateThread(function()
    if dormant or not Config.Salary.enabled then return end
    local disabledChecks = 0
    while true do
        local interval = tonumber(remoteSetting('salaryIntervalMinutes', Config.Salary.intervalMinutes)) or Config.Salary.intervalMinutes
        Wait(math.max(1, interval) * 60000)
        local salary  = tonumber(remoteSetting('salaryAmount', Config.Salary.amount)) or Config.Salary.amount
        local welfare = tonumber(remoteSetting('welfareAmount', Config.Salary.welfareAmount)) or Config.Salary.welfareAmount
        local rules   = parseSalaryRules(remoteSetting('salaryRules', ''))
        if economyEnabled == false then
            disabledChecks = disabledChecks + 1
            local recheckEvery = math.max(1, math.floor(60 / math.max(1, interval)))
            if disabledChecks % recheckEvery ~= 0 then goto continue end
        end
        for src, char in pairs(activeChar) do
            local employed = hasJob(char)
            local amount = employed and salaryFor(char, salary, rules) or welfare
            if amount > 0 then
                local reason = employed and 'Salary' or 'Welfare check'
                adjustMoney(src, 'bank', amount, reason, function(ok)
                    if ok then
                        if employed then
                            notifyMoney(src, ('~g~Payday~s~ $%d deposited to your bank.'):format(amount))
                        else
                            notifyMoney(src, ('~b~Welfare~s~ $%d deposited to your bank.'):format(amount))
                        end
                    end
                end)
            end
        end
        ::continue::
    end
end)
