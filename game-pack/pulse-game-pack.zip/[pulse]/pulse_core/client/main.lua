local loaded = false
local selecting = false
local currentChar = nil

local conflicting = { 'qb-core', 'qbx_core', 'es_extended' }
local dormant = false
for _, res in ipairs(conflicting) do
    if GetResourceState(res) == 'started' then dormant = true break end
end

local function sendNUI(action, data)
    SendNUIMessage({ action = action, data = data or {} })
end

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function freezePlayer(state)
    local ped = PlayerPedId()
    FreezeEntityPosition(ped, state)
    SetEntityVisible(ped, not state, false)
    SetEntityInvincible(ped, state)
    SetPlayerInvincible(PlayerId(), state)
end

local function reportPosition()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local h = GetEntityHeading(ped)
    TriggerServerEvent('pulse_core:reportPosition',
        ('%.1f,%.1f,%.1f,%.1f'):format(c.x, c.y, c.z, h))
end

local function openSelector()
    if dormant or selecting then return end
    selecting = true
    DoScreenFadeOut(250)
    Wait(300)
    freezePlayer(true)
    SetNuiFocus(true, true)
    sendNUI('loading', {})
    TriggerServerEvent('pulse_core:requestCharacters')
end

CreateThread(function()
    if dormant then return end
    while not NetworkIsSessionStarted() do Wait(100) end
    pcall(function() exports.spawnmanager:setAutoSpawn(false) end)
    Wait(500)
    openSelector()
end)

RegisterNetEvent('pulse_core:characters', function(data)
    if not selecting then return end
    sendNUI('characters', data)
end)

RegisterNetEvent('pulse_core:error', function(msg)
    sendNUI('error', { message = msg })
end)

RegisterNetEvent('pulse_core:fatal', function(msg, selector)
    sendNUI('fatal', { message = msg, selector = selector })
end)

-- ── Appearance persistence (fivem-appearance / illenium-appearance) ─────────
local lastAppearanceJson = nil

local function appearanceResource()
    if not Config.Appearance.enabled then return nil end
    for _, res in ipairs({ 'fivem-appearance', 'illenium-appearance' }) do
        if GetResourceState(res) == 'started' then return res end
    end
    return nil
end

local function applyAppearance(jsonStr)
    local res = appearanceResource()
    if not res or type(jsonStr) ~= 'string' or jsonStr == '' then return false end
    local ok, data = pcall(json.decode, jsonStr)
    if not ok or type(data) ~= 'table' then return false end
    local applied = pcall(function()
        exports[res]:setPlayerAppearance(data)
    end)
    return applied
end

local function captureAppearance()
    local res = appearanceResource()
    if not res or not loaded then return end
    local ok, data = pcall(function()
        return exports[res]:getPedAppearance(PlayerPedId())
    end)
    if not ok or type(data) ~= 'table' then return end
    local encoded = json.encode(data)
    if encoded and encoded ~= lastAppearanceJson then
        lastAppearanceJson = encoded
        TriggerServerEvent('pulse_core:saveAppearance', encoded)
    end
end

local function openAppearanceCreator()
    local res = appearanceResource()
    if not res then return end
    pcall(function()
        exports[res]:startPlayerCustomization(function(appearance)
            if appearance then
                local encoded = json.encode(appearance)
                lastAppearanceJson = encoded
                TriggerServerEvent('pulse_core:saveAppearance', encoded)
            end
        end, { ped = true, headBlend = true, faceFeatures = true, headOverlays = true, components = true, props = true })
    end)
end

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) or not IsModelAPed(hash) then return false end
    RequestModel(hash)
    local deadline = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return false end
        Wait(50)
    end
    SetPlayerModel(PlayerId(), hash)
    SetModelAsNoLongerNeeded(hash)
    local ped = PlayerPedId()
    SetPedDefaultComponentVariation(ped)
    SetPedRandomComponentVariation(ped, 0)
    return true
end

RegisterNetEvent('pulse_core:spawnCharacter', function(char, spawn)
    selecting = false
    SetNuiFocus(false, false)
    sendNUI('close', {})

    if char.ped_model and char.ped_model ~= '' then
        loadModel(char.ped_model)
    end

    local ped = PlayerPedId()
    RequestCollisionAtCoord(spawn.x, spawn.y, spawn.z)
    SetEntityCoordsNoOffset(ped, spawn.x, spawn.y, spawn.z, false, false, false)
    SetEntityHeading(ped, spawn.heading or 0.0)
    local deadline = GetGameTimer() + 5000
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < deadline do Wait(50) end

    freezePlayer(false)
    currentChar = char
    loaded = true
    DoScreenFadeIn(400)
    reportPosition()

    if char.appearance and char.appearance ~= '' then
        lastAppearanceJson = char.appearance
        applyAppearance(char.appearance)
    elseif Config.Appearance.openCreatorOnNew and appearanceResource() then
        Wait(600)
        openAppearanceCreator()
    end

    TriggerEvent('pulse_core:clientCharacterLoaded', char)
    notify('~b~PulseMDT~s~ Welcome, ' .. char.name .. '.')
end)

RegisterNUICallback('select', function(data, cb)
    if data and data.charId then
        TriggerServerEvent('pulse_core:selectCharacter', data.charId, data.spawn)
    end
    cb({})
end)

RegisterNUICallback('create', function(data, cb)
    TriggerServerEvent('pulse_core:createCharacter', data or {})
    cb({})
end)

RegisterNUICallback('delete', function(data, cb)
    if data and data.charId then
        TriggerServerEvent('pulse_core:deleteCharacter', data.charId)
    end
    cb({})
end)

RegisterNUICallback('retry', function(_, cb)
    TriggerServerEvent('pulse_core:requestCharacters')
    cb({})
end)

RegisterNUICallback('cancel', function(_, cb)
    -- Only valid while switching (a character is already loaded underneath).
    if loaded then
        selecting = false
        SetNuiFocus(false, false)
        sendNUI('close', {})
        freezePlayer(false)
        DoScreenFadeIn(300)
    end
    cb({})
end)

if Config.SwitchCommand then
    RegisterCommand(Config.SwitchCommand, function()
        if dormant or selecting then return end
        openSelector()
    end, false)
end

RegisterCommand('balance', function()
    if dormant or not loaded then return end
    TriggerServerEvent('pulse_core:requestBalance')
end, false)

RegisterCommand('coords', function()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)
    local line = ('%.2f, %.2f, %.2f, %.2f'):format(pos.x, pos.y, pos.z, heading)
    TriggerEvent('chat:addMessage', {
        color = { 6, 182, 212 },
        args = { 'Coords', line .. ' (copy this into the dashboard station editor)' }
    })
    print('[pulse_core] coords: ' .. line)
end, false)

RegisterNetEvent('pulse_core:notify', function(msg)
    if msg then notify(msg) end
end)

CreateThread(function()
    if dormant then return end
    local tick = 0
    while true do
        Wait(Config.SaveInterval * 1000)
        if loaded and not selecting then
            reportPosition()
            -- Appearance changes come from clothing shops and the creator;
            -- a slow sweep catches anything those resources changed.
            tick = tick + 1
            if tick % 5 == 0 then captureAppearance() end
        end
    end
end)
