-- PulseMDT :: pulse_core (Standalone character framework)
--
-- A lightweight character framework for STANDALONE servers. Characters live in
-- your PulseMDT CAD, so the civilian web portal and the game always agree:
-- create a character in either place and it exists in both.
--
-- Do NOT run this alongside QBCore/ESX/qbox; those frameworks have their own
-- character system. pulse_core detects them and stays dormant with a warning.
--
-- Connection settings (API key, guild ID) live in pulsemdt/config.lua.
--
-- Other resources integrate via:
--   exports.pulse_core:GetCharacter(src)    -> active character table or nil
--   exports.pulse_core:GetCharacterId(src)  -> character id or nil
--   exports.pulse_core:IsLoaded(src)        -> boolean
--   Server event 'pulse_core:characterLoaded'   (src, character)
--   Server event 'pulse_core:characterUnloaded' (src, character)

Config = {}

-- Maximum characters a player may have. The web portal may enforce its own
-- limit as well; the lower of the two effectively applies.
Config.MaxCharacters = 5

-- Character selector branding. All text below is shown only in the NUI and
-- can be changed without editing HTML, CSS, or JavaScript.
--
-- LogoURL and Backgrounds accept either HTTPS URLs or local NUI paths. For a
-- local file, put it inside pulse_core/nui/images and use a path such as
-- 'images/community-logo.png' or 'images/city-night.jpg'. One background is
-- selected at random whenever the selector opens. Leave Backgrounds empty to
-- use the built-in Pulse ambient artwork on the right side.
Config.Selector = {
    ServerName         = 'Pulse Roleplay',
    ScreenLabel        = 'Character selection',
    Title              = 'Choose your character',
    Subtitle           = 'Select who you want to enter the city as, or create a new profile.',
    VisualTitle        = 'Welcome back',
    VisualSubtitle     = 'Pick up where you left off. Your character data stays synced with PulseMDT.',
    LogoURL            = false,
    Backgrounds        = {},
    BackgroundPosition = 'center center',
    AccentColor        = '#2f9bd6',
}

-- Legacy options from pulse_core 0.1 are still read when the matching value
-- above is empty. Existing installations can upgrade without losing branding.
Config.LogoURL = false
Config.Backgrounds = {}

-- Allow creating new characters from the in-game selector.
Config.AllowCreate = true

-- Allow deleting characters from the in-game selector. Deletion additionally
-- requires the "Let players delete their own characters" toggle in the web
-- dashboard's Features page; if that is off, in-game delete is refused too.
Config.AllowDelete = true

-- Command that reopens the character selector (switch character). Set to false
-- to disable switching after first spawn.
Config.SwitchCommand = 'characters'

-- Where brand-new characters (no saved position) spawn: x, y, z, heading.
-- Also the final fallback if SpawnPoints is empty.
Config.DefaultSpawn = { x = 196.96, y = -934.54, z = 29.69, heading = 140.0 }

-- Spawn selection. When enabled, players pick a spawn location after choosing
-- a character. When disabled (or only one option exists), the step is skipped
-- and the character spawns at their last position or the first spawn point.
Config.SpawnSelector = true

-- Offer "Where you logged off" as a spawn option when the character has a
-- saved position.
Config.AllowLastPosition = true

-- Named spawn locations offered to players. Add or remove freely per server;
-- these three are starter defaults covering the city, Sandy Shores, and
-- Paleto Bay (public places a civilian would plausibly turn up).
Config.SpawnPoints = {
    { label = 'Legion Square (Los Santos)',      x = 196.96,  y = -934.54, z = 29.69, heading = 140.0 },
    { label = 'Eastern Motel (Sandy Shores)',    x = 343.53,  y = 2636.94, z = 43.94, heading = 190.0 },
    { label = 'Dream View Motel (Paleto Bay)',   x = -102.78, y = 6336.28, z = 31.49, heading = 45.0 },
}

-- Job spawn groups. Characters whose occupation matches one of the words in
-- `jobs` (case-insensitive, substring match) are offered these extra spawn
-- locations on top of the public ones. Add groups for your own departments.
Config.JobSpawns = {
    {
        name = 'Law Enforcement',
        jobs = { 'police', 'officer', 'sheriff', 'deputy', 'trooper', 'lspd', 'bcso', 'sahp' },
        spawns = {
            { label = 'Mission Row PD',       x = 437.6,  y = -986.6, z = 29.69, heading = 90.0 },
            { label = 'Sandy Shores Sheriff', x = 1849.4, y = 3688.6, z = 33.27, heading = 210.0 },
            { label = 'Paleto Bay Sheriff',   x = -447.2, y = 6009.4, z = 30.72, heading = 310.0 },
        },
    },
    {
        name = 'Fire & EMS',
        jobs = { 'ems', 'paramedic', 'medic', 'doctor', 'nurse', 'firefighter', 'fire', 'lsfd' },
        spawns = {
            { label = 'Pillbox Hill Medical',          x = 307.8,   y = -590.5,   z = 43.3,  heading = 70.0 },
            { label = 'Fire Station 7 (Los Santos)',   x = 1194.71, y = -1474.14, z = 33.86, heading = 0.0 },
            { label = 'Fire Station 2 (Sandy Shores)', x = 1691.5,  y = 3597.95,  z = 34.56, heading = 0.0 },
            { label = 'Fire Station 1 (Paleto Bay)',   x = -384.07, y = 6117.9,   z = 30.48, heading = 0.0 },
        },
    },
}

-- Where the player hovers while the selector is open (scenic camera position).
Config.SelectorCamera = { x = -1678.0, y = -1125.0, z = 60.0, heading = 260.0 }

-- Seconds between automatic saves of the active character's position.
Config.SaveInterval = 60

-- Salaries. Requires the Economy feature to be enabled in the web dashboard
-- (Features page); when it is off, no money moves and paychecks are skipped.
-- Every `intervalMinutes` of play time, characters WITH a job are paid
-- `amount` and characters WITHOUT one get `welfareAmount` instead (set it to
-- 0 to disable welfare). Amounts and interval can also be changed live from
-- the dashboard's Scripts page.
Config.Salary = {
    enabled = true,
    intervalMinutes = 30,
    amount = 250,
    welfareAmount = 100,
    -- Per-job overrides matched against the character's occupation
    -- (case-insensitive substring; first match wins). Jobs not listed here
    -- earn `amount`. The dashboard's "Per-job salaries" field overrides this.
    -- Example:
    --   jobRates = {
    --       { match = 'police', amount = 500 },
    --       { match = 'ems',    amount = 450 },
    --   },
    jobRates = {},
}

-- Occupation values treated as "no job" (case-insensitive). Anything else
-- counts as employed and earns the full salary.
Config.JoblessValues = { '', 'civilian', 'unemployed', 'none', 'n/a' }

-- Appearance persistence. When fivem-appearance or illenium-appearance is
-- running on the server, characters keep their looks: appearance saves to the
-- CAD, reapplies on spawn, and the creator opens once for brand-new
-- characters. Without either resource this does nothing and the ped models
-- below are used instead.
Config.Appearance = {
    enabled = true,
    openCreatorOnNew = true,
}

-- Ped models offered when creating a character (label = shown, model = spawned).
Config.PedModels = {
    { label = 'Male 1',   model = 'a_m_y_business_03' },
    { label = 'Male 2',   model = 'a_m_y_hipster_01' },
    { label = 'Male 3',   model = 'a_m_m_skater_01' },
    { label = 'Female 1', model = 'a_f_y_business_02' },
    { label = 'Female 2', model = 'a_f_y_hipster_02' },
    { label = 'Female 3', model = 'a_f_y_tourist_01' },
}
