# pulse_core

`pulse_core` is PulseMDT's standalone FiveM character framework. It supplies character selection, spawning, appearance, last-position saving, salaries, balances, and money exports for the other Pulse scripts.

## Requirements

- `pulsemdt`
- `pulse_notify` optional

Do not run it alongside `qb-core`, `qbx_core`, or `es_extended`. The resource detects those frameworks and stays dormant to avoid taking over character flow.

## Installation

Configure `pulsemdt` first, edit `config.lua`, and start resources in this order:

```cfg
ensure pulsemdt
ensure pulse_notify
ensure pulse_core
```

## Commands

- `/characters` reopens the character selector by default.
- `/balance` displays the active character's balances.
- `/coords` displays current coordinates.

`config.lua` controls character limits, selector presentation, spawn points, appearance options, save interval, salaries, and supported ped models. Server exports include character lookup plus balance read/write helpers; see the comments at the top of `config.lua` for signatures.
