Optional pulse_core selector artwork

Place community logos and right-side background images in this folder, then
reference them from config.lua without the nui/ prefix:

    LogoURL = 'images/community-logo.png'
    Backgrounds = {
        'images/city-night.jpg',
        'images/sheriff-station.jpg',
    }

HTTPS image URLs are also supported. Wide landscape images work best; use
BackgroundPosition in Config.Selector to adjust the crop.
