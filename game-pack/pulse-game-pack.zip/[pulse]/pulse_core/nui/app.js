const RESOURCE = 'pulse_core';
const DEFAULT_SELECTOR = {
  serverName: 'Pulse Roleplay',
  screenLabel: 'Character selection',
  title: 'Choose your character',
  subtitle: 'Select who you want to enter the city as, or create a new profile.',
  visualTitle: 'Welcome back',
  visualSubtitle: 'Pick up where you left off. Your character data stays synced with PulseMDT.',
  logo: null,
  background: null,
  backgroundPosition: 'center center',
  accentColor: '#2f9bd6',
};
let state = {
  characters: [], pedModels: [], canCreate: true, canDelete: true,
  maxCharacters: 5, hasActive: false, offline: false,
  selector: { ...DEFAULT_SELECTOR },
};
let confirmDeleteId = null;

const app = document.getElementById('app');
const views = {
  loading: document.getElementById('loading'),
  fatal: document.getElementById('fatal'),
  unavailable: document.getElementById('unavailable'),
  picker: document.getElementById('picker'),
  spawnView: document.getElementById('spawnView'),
  createView: document.getElementById('createView'),
};
const cardsEl = document.getElementById('cards');
const spawnCardsEl = document.getElementById('spawnCards');
const spawnTitle = document.getElementById('spawnTitle');
const offlineNote = document.getElementById('offlineNote');
const toastEl = document.getElementById('toast');
const cancelBtn = document.getElementById('cancelBtn');
const slotsEl = document.getElementById('slots');
const slotsFill = document.getElementById('slotsFill');
const slotsLabel = document.getElementById('slotsLabel');
const formError = document.getElementById('formError');
let toastTimer = null;

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function show(name) {
  for (const key of Object.keys(views)) views[key].classList.toggle('hidden', key !== name);
  if (name !== 'createView') formError.textContent = '';
}

function toast(msg) {
  toastEl.textContent = msg;
  toastEl.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.add('hidden'), 4200);
}

function age(dob) {
  if (!dob) return null;
  const d = new Date(dob);
  if (isNaN(d)) return null;
  return Math.max(0, Math.floor((Date.now() - d.getTime()) / (365.25 * 24 * 3600 * 1000)));
}

function initials(name) {
  return String(name || '?').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
}

function selectorFrom(data) {
  const selector = data?.selector || {};
  return {
    ...DEFAULT_SELECTOR,
    ...selector,
    logo: selector.logo || data?.logo || null,
    background: selector.background || data?.background || null,
  };
}

/* ---- custom dropdown ---- */
function makeSelect(rootId, options, initial) {
  const root = document.getElementById(rootId);
  root.innerHTML = '';
  let value = initial ?? (options[0] && options[0].value);

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'sel-btn';
  const labelSpan = document.createElement('span');
  btn.appendChild(labelSpan);
  const list = document.createElement('div');
  list.className = 'sel-list';

  function labelFor(v) {
    const o = options.find((o) => o.value === v);
    return o ? o.label : String(v);
  }
  function render() {
    labelSpan.textContent = labelFor(value);
    list.querySelectorAll('.sel-opt').forEach((el) => {
      el.classList.toggle('selected', el.dataset.value === String(value));
    });
  }

  for (const o of options) {
    const opt = document.createElement('button');
    opt.type = 'button';
    opt.className = 'sel-opt';
    opt.dataset.value = String(o.value);
    opt.textContent = o.label;
    opt.addEventListener('click', () => {
      value = o.value;
      root.classList.remove('open');
      btn.setAttribute('aria-expanded', 'false');
      render();
    });
    list.appendChild(opt);
  }

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    document.querySelectorAll('.select.open').forEach((s) => { if (s !== root) s.classList.remove('open'); });
    root.classList.toggle('open');
    btn.setAttribute('aria-expanded', String(root.classList.contains('open')));
  });

  btn.setAttribute('aria-haspopup', 'listbox');
  btn.setAttribute('aria-expanded', 'false');

  root.append(btn, list);
  render();
  return { get value() { return value; } };
}
document.addEventListener('click', () => {
  document.querySelectorAll('.select.open').forEach((s) => {
    s.classList.remove('open');
    s.querySelector('.sel-btn')?.setAttribute('aria-expanded', 'false');
  });
});

let genderSel = null;
let modelSel = null;

/* ---- configurable selector branding and right-side artwork ---- */
function applyAccent(value) {
  if (!/^#[0-9a-f]{3}([0-9a-f]{3})?$/i.test(value || '')) value = DEFAULT_SELECTOR.accentColor;
  let hex = value.slice(1);
  if (hex.length === 3) hex = hex.split('').map((part) => part + part).join('');
  const rgb = [0, 2, 4].map((offset) => parseInt(hex.slice(offset, offset + 2), 16));
  const hover = rgb.map((channel) => Math.max(0, Math.round(channel * 0.86)));
  const root = document.documentElement.style;
  root.setProperty('--accent', `#${hex}`);
  root.setProperty('--accent-hover', `rgb(${hover.join(', ')})`);
  root.setProperty('--accent-dim', `rgba(${rgb.join(', ')}, 0.14)`);
  root.setProperty('--accent-border', `rgba(${rgb.join(', ')}, 0.42)`);
}

function applyScene() {
  const selector = { ...DEFAULT_SELECTOR, ...(state.selector || {}) };
  const image = document.getElementById('sceneImage');

  document.getElementById('serverName').textContent = selector.serverName;
  document.getElementById('screenLabel').textContent = selector.screenLabel;
  document.getElementById('railTitle').textContent = selector.title;
  document.getElementById('railSub').textContent = selector.subtitle;
  document.getElementById('visualTitle').textContent = selector.visualTitle;
  document.getElementById('visualSubtitle').textContent = selector.visualSubtitle;
  document.getElementById('connectionLabel').textContent = `Connected to ${selector.serverName}`;
  document.title = `${selector.serverName} — ${selector.screenLabel}`;
  applyAccent(selector.accentColor);

  image.style.objectPosition = selector.backgroundPosition || 'center center';
  if (selector.background) {
    image.classList.remove('hidden');
    image.onload = () => app.classList.add('has-bg');
    image.onerror = () => {
      image.classList.add('hidden');
      app.classList.remove('has-bg');
    };
    image.src = selector.background;
  } else {
    image.removeAttribute('src');
    image.classList.add('hidden');
    app.classList.remove('has-bg');
  }

  const logo = document.getElementById('logo');
  logo.innerHTML = 'Pulse<span>MDT</span>';
  if (selector.logo) {
    logo.innerHTML = '';
    const img = document.createElement('img');
    img.src = selector.logo;
    img.alt = `${selector.serverName} logo`;
    img.addEventListener('error', () => { logo.innerHTML = 'Pulse<span>MDT</span>'; });
    logo.appendChild(img);
  }
}

/* ---- rail ---- */
function renderRail() {
  const used = state.characters.length;
  const max = state.maxCharacters || 5;
  slotsEl.classList.toggle('hidden', used === 0);
  slotsFill.style.width = `${Math.min(100, (used / max) * 100)}%`;
  slotsLabel.textContent = `${used} of ${max} character slots used`;
  offlineNote.classList.toggle('hidden', !state.offline);
  cancelBtn.classList.toggle('hidden', !state.hasActive);
}

/* ---- spawn step ---- */
function spawnOptionsFor(c) {
  const opts = [];
  if (state.allowLast && c.last_pos) {
    opts.push({ value: 'last', label: 'Where you logged off', kind: 'Last location', cls: 'last' });
  }
  for (const j of c.job_spawns || []) {
    opts.push({ value: j.value, label: j.label, kind: j.kind, cls: 'job' });
  }
  for (const p of state.spawnPoints || []) {
    opts.push({ value: p.index, label: p.label, kind: 'Spawn point' });
  }
  return opts;
}

function beginPlay(c) {
  const opts = spawnOptionsFor(c);
  if (!state.spawnSelector || opts.length <= 1) {
    show('loading');
    post('select', { charId: c.id, spawn: opts.length === 1 ? opts[0].value : null });
    return;
  }
  spawnTitle.textContent = `Where should ${String(c.name).split(/\s+/)[0]} spawn?`;
  spawnCardsEl.innerHTML = '';
  let order = 0;
  for (const o of opts) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'card spot' + (o.cls ? ' ' + o.cls : '');
    card.style.setProperty('--i', order++);
    const h3 = document.createElement('h3');
    h3.textContent = o.label;
    const kind = document.createElement('div');
    kind.className = 'kind';
    kind.textContent = o.kind;
    card.append(h3, kind);
    card.addEventListener('click', () => {
      show('loading');
      post('select', { charId: c.id, spawn: o.value });
    });
    spawnCardsEl.appendChild(card);
  }
  show('spawnView');
}

/* ---- picker ---- */
function renderCards() {
  cardsEl.innerHTML = '';
  confirmDeleteId = null;
  let order = 0;

  for (const c of state.characters) {
    const card = document.createElement('div');
    card.className = 'card' + (c.id === state.activeCharId ? ' active-char' : '');
    card.style.setProperty('--i', order++);

    const av = document.createElement('div');
    av.className = 'avatar';
    av.textContent = initials(c.name);

    const h3 = document.createElement('h3');
    h3.textContent = c.name;

    const sub = document.createElement('div');
    sub.className = 'sub';
    const a = age(c.date_of_birth);
    const top = [];
    if (a !== null) top.push(`Age ${a}`);
    if (c.gender) top.push(c.gender);
    sub.textContent = top.join(' · ');
    if (c.job && c.job.trim()) {
      const occ = document.createElement('span');
      occ.className = 'occupation';
      occ.textContent = c.job;
      sub.appendChild(occ);
    }

    const pills = document.createElement('div');
    pills.className = 'pills';
    const lic = document.createElement('span');
    const suspended = String(c.license_status || '').toLowerCase() === 'suspended';
    lic.className = 'pill ' + (suspended ? 'bad' : 'ok');
    lic.textContent = suspended ? 'License suspended' : 'License valid';
    pills.appendChild(lic);
    if (c.id === state.activeCharId) {
      const now = document.createElement('span');
      now.className = 'pill now';
      now.textContent = 'Current';
      pills.appendChild(now);
    }

    const actions = document.createElement('div');
    actions.className = 'cardActions';
    const play = document.createElement('button');
    play.className = 'primary play';
    play.textContent = 'Play';
    play.addEventListener('click', (e) => {
      e.stopPropagation();
      beginPlay(c);
    });
    actions.appendChild(play);

    if (state.canDelete && !state.offline && c.id !== state.activeCharId) {
      const del = document.createElement('button');
      del.className = 'danger small';
      del.textContent = 'Delete';
      del.addEventListener('click', (e) => {
        e.stopPropagation();
        if (confirmDeleteId === c.id) {
          confirmDeleteId = null;
          post('delete', { charId: c.id });
        } else {
          confirmDeleteId = c.id;
          del.textContent = 'Confirm?';
          setTimeout(() => {
            if (confirmDeleteId === c.id) { confirmDeleteId = null; del.textContent = 'Delete'; }
          }, 3000);
        }
      });
      actions.appendChild(del);
    }

    card.append(av, h3, sub, pills, actions);
    cardsEl.appendChild(card);
  }

  if (state.canCreate && !state.offline && state.characters.length < state.maxCharacters) {
    const add = document.createElement('button');
    add.type = 'button';
    add.className = 'card new';
    add.style.setProperty('--i', order++);
    const plus = document.createElement('div');
    plus.className = 'plus';
    plus.textContent = '+';
    const lbl = document.createElement('div');
    lbl.textContent = 'New character';
    add.append(plus, lbl);
    add.addEventListener('click', openCreate);
    cardsEl.appendChild(add);
  }

  renderRail();
  show('picker');
}

function openCreate() {
  genderSel = makeSelect('genderSel', [
    { value: 'Male', label: 'Male' },
    { value: 'Female', label: 'Female' },
  ], 'Male');
  modelSel = makeSelect('modelSel',
    (state.pedModels || []).map((m) => ({ value: m.model, label: m.label })),
    state.pedModels && state.pedModels[0] && state.pedModels[0].model);
  document.getElementById('createForm').reset();
  formError.textContent = '';
  show('createView');
  setTimeout(() => document.getElementById('fName').focus(), 40);
}

document.getElementById('createForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const first = document.getElementById('fName').value.trim();
  const last = document.getElementById('lName').value.trim();
  const dob = document.getElementById('fDob').value;
  if (!first || !last || !dob) {
    formError.textContent = 'Fill in first name, last name, and date of birth.';
    return;
  }
  formError.textContent = '';
  post('create', {
    name: `${first} ${last}`,
    dob,
    height: document.getElementById('fHeight').value.trim(),
    job: document.getElementById('fJob').value.trim() || 'Civilian',
    gender: genderSel ? genderSel.value : 'Male',
    pedModel: modelSel ? modelSel.value : null,
  });
});

document.getElementById('createBack').addEventListener('click', () => renderCards());
document.getElementById('spawnBack').addEventListener('click', () => renderCards());
document.getElementById('retryBtn').addEventListener('click', () => { show('loading'); post('retry'); });
cancelBtn.addEventListener('click', () => post('cancel'));

/* ---- messages from the client script ---- */
window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'loading') {
    app.classList.remove('hidden');
    show('loading');
  } else if (m.action === 'characters') {
    const d = m.data || {};
    if (d.unavailable) {
      state.selector = selectorFrom(d);
      applyScene();
      app.classList.remove('hidden');
      show('unavailable');
      return;
    }
    state = {
      characters: d.characters || [],
      activeCharId: d.activeCharId ?? null,
      pedModels: d.pedModels || [],
      canCreate: d.canCreate !== false,
      canDelete: d.canDelete !== false,
      maxCharacters: d.maxCharacters || 5,
      hasActive: d.hasActive === true,
      offline: d.offline === true,
      spawnSelector: d.spawnSelector !== false,
      allowLast: d.allowLast !== false,
      spawnPoints: d.spawnPoints || [],
      selector: selectorFrom(d),
    };
    applyScene();
    app.classList.remove('hidden');
    if (state.characters.length === 0 && state.canCreate && !state.offline) { renderRail(); openCreate(); }
    else renderCards();
  } else if (m.action === 'error') {
    const msg = (m.data && m.data.message) || 'Something went wrong.';
    const creating = !views.createView.classList.contains('hidden');
    const picking = !views.picker.classList.contains('hidden');
    if (creating) { formError.textContent = msg; return; }
    toast(msg);
    if (picking) return;
    if (state.characters.length > 0) renderCards(); else if (state.canCreate) openCreate();
  } else if (m.action === 'fatal') {
    state.selector = selectorFrom(m.data || {});
    applyScene();
    app.classList.remove('hidden');
    document.getElementById('fatalMsg').textContent = (m.data && m.data.message) || '';
    show('fatal');
  } else if (m.action === 'close') {
    app.classList.add('hidden');
  }
});
