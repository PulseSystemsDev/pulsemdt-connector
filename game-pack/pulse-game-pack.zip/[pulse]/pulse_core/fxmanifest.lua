fx_version 'cerulean'
game 'gta5'

name 'pulse_core'
description 'PulseMDT - Standalone character framework'
version '0.2.0'
author 'PulseMDT'
url 'https://pulsemdt.com'

dependency 'pulsemdt'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
    'nui/images/*',
}

lua54 'yes'
