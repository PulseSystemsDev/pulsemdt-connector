local jailed = {}

local RCFG = { enabled = true, settings = {} }

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_jailing') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function setting(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    if v == nil then return fallback end
    return v
end
local function num(key, fallback) return tonumber(setting(key, fallback)) or fallback end
local function moduleEnabled() return RCFG.enabled ~= false end

local function effectiveCells()
    local raw = RCFG.settings and RCFG.settings.stationsJson
    if type(raw) == 'string' and raw ~= '' then
        local ok, parsed = pcall(json.decode, raw)
        if ok and type(parsed) == 'table' then
            local out = {}
            for _, s in ipairs(parsed) do
                if s.job == 'jail' and tonumber(s.x) then
                    out[#out + 1] = {
                        label = tostring(s.label or 'Cell'),
                        x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                        heading = tonumber(s.heading) or 0.0,
                    }
                end
            end
            if #out > 0 then return out end
        end
    end
    return Config.Cells
end

local function notify(src, msg)
    TriggerClientEvent('pulse_jailing:notify', src, msg)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local function applyJail(src, sentence)
    local cells = effectiveCells()
    if #cells == 0 then return end
    local cell = cells[(sentence.id % #cells) + 1]
    jailed[src] = {
        id = sentence.id, remaining = sentence.remaining, total = sentence.total,
        reason = sentence.reason, lastSync = GetGameTimer(), lastNotify = GetGameTimer(),
    }
    TriggerClientEvent('pulse_jailing:begin', src, {
        cell = cell, remaining = sentence.remaining, reason = sentence.reason,
        stripWeapons = Config.StripWeapons,
        restrictRadius = num('restrictRadius', Config.RestrictRadius),
    })
end

local function releasePlayer(src, early, skipApi)
    local st = jailed[src]
    if not st then return end
    jailed[src] = nil
    TriggerClientEvent('pulse_jailing:release', src, { early = early })
    if not skipApi then
        local sentenceId = st.id
        pcall(function()
            exports.pulsemdt:ApiRequest('POST', '/jail', { action = 'release', id = sentenceId, early = early == true }, nil)
        end)
    end
end

CreateThread(function()
    while true do
        Wait(1000)
        local now = GetGameTimer()
        for src, st in pairs(jailed) do
            if GetPlayerName(src) then
                st.remaining = math.max(0, st.remaining - 1)
                TriggerClientEvent('pulse_jailing:tick', src, st.remaining)
                if st.remaining <= 0 then
                    releasePlayer(src, false)
                else
                    if now - st.lastSync >= (Config.SyncIntervalSeconds * 1000) then
                        st.lastSync = now
                        local sentenceId, remaining = st.id, st.remaining
                        pcall(function()
                            exports.pulsemdt:ApiRequest('POST', '/jail', { action = 'sync', id = sentenceId, remainingSeconds = remaining }, nil)
                        end)
                    end
                    local intervalMs = num('notifyIntervalMinutes', Config.NotifyIntervalMinutes) * 60000
                    if now - st.lastNotify >= intervalMs then
                        st.lastNotify = now
                        local mins = math.ceil(st.remaining / 60)
                        notify(src, ('~y~Jail~s~ %d minute%s remaining.'):format(mins, mins == 1 and '' or 's'))
                    end
                end
            else
                jailed[src] = nil
            end
        end
    end
end)

RegisterNetEvent('pulse_jailing:doJail', function(data)
    local src = source
    if not moduleEnabled() then notify(src, '~y~Jailing is disabled on this server.') return end
    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'police', 'law') end)
    if not authorized then notify(src, '~r~An on-duty law-enforcement role is required to jail someone.') return end

    local targetSrc = tonumber(data and data.serverId)
    local minutes = tonumber(data and data.minutes)
    local reason = tostring(data and data.reason or ''):gsub('%s+$', '')
    if reason == '' then reason = 'No reason provided' end
    reason = reason:sub(1, 200)

    if not targetSrc or not GetPlayerName(targetSrc) then notify(src, '~r~No player with that server ID.') return end
    if targetSrc == src then notify(src, '~r~You cannot jail yourself.') return end
    if not minutes or minutes <= 0 then notify(src, '~r~Enter a valid number of minutes.') return end
    if jailed[targetSrc] then notify(src, '~y~That player is already in jail.') return end

    local officerPed, targetPed = GetPlayerPed(src), GetPlayerPed(targetSrc)
    if officerPed == 0 or targetPed == 0 or #(GetEntityCoords(officerPed) - GetEntityCoords(targetPed)) > Config.MaxTargetDistance then
        notify(src, '~r~That player is too far away.')
        return
    end

    getCharId(targetSrc, function(charId)
        local seconds = math.floor(minutes * 60)
        local body = {
            action = 'book', charId = charId, characterName = GetPlayerName(targetSrc),
            discordId = getDiscordId(targetSrc), seconds = seconds, reason = reason,
            jailedBy = getDiscordId(src), jailedByName = GetPlayerName(src), source = 'manual',
        }
        exports.pulsemdt:ApiRequest('POST', '/jail', body, function(code, res)
            if code == 201 and res and res.id then
                applyJail(targetSrc, { id = res.id, remaining = seconds, total = seconds, reason = reason })
                notify(src, ('~g~Jail~s~ %s booked for %d minutes.'):format(GetPlayerName(targetSrc), minutes))
            else
                notify(src, '~r~Jail~s~ Could not reach the CAD. Try again.')
            end
        end)
    end)
end)

RegisterNetEvent('pulse_jailing:doUnjail', function(data)
    local src = source
    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'police', 'law') end)
    if not authorized then notify(src, '~r~An on-duty law-enforcement role is required to release someone.') return end

    local targetSrc = tonumber(data and data.serverId)
    if not targetSrc or not jailed[targetSrc] then notify(src, '~y~That player is not in jail.') return end
    local name = GetPlayerName(targetSrc) or 'Player'
    releasePlayer(targetSrc, true)
    notify(src, ('~g~Jail~s~ %s released early.'):format(name))
end)

-- One CAD read per pass, checked against every connected player: applies new
-- bookings (dashboard or Discord) to anyone already connected, and releases
-- anyone the CAD no longer lists as active (an early release issued from the
-- dashboard or Discord bot while they were already serving time in-game).
local function reconcileAll()
    exports.pulsemdt:ApiRequest('GET', '/jail', nil, function(code, res)
        if code ~= 200 or not res or not res.jails then return end
        local activeById = {}
        for _, j in ipairs(res.jails) do activeById[j.id] = j end

        for src, st in pairs(jailed) do
            if not activeById[st.id] then
                releasePlayer(src, true, true)
            end
        end

        for _, pid in ipairs(GetPlayers()) do
            local src = tonumber(pid)
            if src and not jailed[src] then
                getCharId(src, function(charId)
                    if not charId or jailed[src] then return end
                    for _, j in ipairs(res.jails) do
                        if j.char_id == charId and tonumber(j.remaining_seconds) and tonumber(j.remaining_seconds) > 0 then
                            applyJail(src, { id = j.id, remaining = tonumber(j.remaining_seconds), total = tonumber(j.total_seconds), reason = j.reason })
                            return
                        end
                    end
                end)
            end
        end
    end)
end

RegisterNetEvent('pulse_jailing:ready', function()
    reconcileAll()
end)

CreateThread(function()
    while true do
        Wait(Config.PollIntervalMs)
        if moduleEnabled() then reconcileAll() end
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local st = jailed[src]
    if st then
        local sentenceId, remaining = st.id, st.remaining
        pcall(function()
            exports.pulsemdt:ApiRequest('POST', '/jail', { action = 'sync', id = sentenceId, remainingSeconds = remaining }, nil)
        end)
    end
    jailed[src] = nil
end)
