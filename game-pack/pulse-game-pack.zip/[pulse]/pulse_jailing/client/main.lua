local jailedNow = false
local cellPos = nil
local outsideSince = nil
local restrictRadius = Config.RestrictRadius

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_jailing:notify', function(msg)
    if msg then notify(msg) end
end)

RegisterNetEvent('pulse_jailing:begin', function(data)
    jailedNow = true
    cellPos = data.cell
    outsideSince = nil
    restrictRadius = tonumber(data.restrictRadius) or Config.RestrictRadius
    local ped = PlayerPedId()
    SetEntityCoords(ped, data.cell.x, data.cell.y, data.cell.z, false, false, false, false)
    SetEntityHeading(ped, data.cell.heading or 0.0)
    if data.stripWeapons then RemoveAllPedWeapons(ped, true) end
    SendNUIMessage({ action = 'begin', reason = data.reason, remaining = data.remaining })
    notify(('~r~Jail~s~ You have been booked: %s'):format(data.reason or ''))
end)

RegisterNetEvent('pulse_jailing:tick', function(remaining)
    if jailedNow then SendNUIMessage({ action = 'tick', remaining = remaining }) end
end)

RegisterNetEvent('pulse_jailing:release', function(data)
    jailedNow = false
    cellPos = nil
    outsideSince = nil
    restrictRadius = Config.RestrictRadius
    SendNUIMessage({ action = 'end' })
    local ped = PlayerPedId()
    local rp = Config.ReleasePoint
    SetEntityCoords(ped, rp.x, rp.y, rp.z, false, false, false, false)
    SetEntityHeading(ped, rp.heading or 0.0)
    if data and data.early then
        notify('~g~Jail~s~ You have been released early.')
    else
        notify('~g~Jail~s~ You have served your time. Released.')
    end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_jailing:ready')
end)

CreateThread(function()
    while true do
        Wait(1000)
        if jailedNow and cellPos then
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            local dist = #(pos - vector3(cellPos.x, cellPos.y, cellPos.z))
            if dist > restrictRadius then
                outsideSince = outsideSince or GetGameTimer()
                if GetGameTimer() - outsideSince > (Config.RestrictGraceSeconds * 1000) then
                    SetEntityCoords(ped, cellPos.x, cellPos.y, cellPos.z, false, false, false, false)
                    notify('~y~Jail~s~ Stay inside the cell block.')
                    outsideSince = nil
                end
            else
                outsideSince = nil
            end
            RemoveAllPedWeapons(ped, true)
        end
    end
end)

RegisterCommand(Config.Command, function(_, args)
    if not args[1] or not args[2] then
        notify('~b~Jail~s~ Usage: /jail <serverId> <minutes> [reason]')
        return
    end
    TriggerServerEvent('pulse_jailing:doJail', {
        serverId = tonumber(args[1]),
        minutes = tonumber(args[2]),
        reason = table.concat(args, ' ', 3),
    })
end, false)

RegisterCommand(Config.ReleaseCommand, function(_, args)
    if not args[1] then
        notify('~b~Jail~s~ Usage: /unjail <serverId>')
        return
    end
    TriggerServerEvent('pulse_jailing:doUnjail', { serverId = tonumber(args[1]) })
end, false)

CreateThread(function()
    local b = Config.Blip
    local rp = Config.ReleasePoint
    local blip = AddBlipForCoord(rp.x, rp.y, rp.z)
    SetBlipSprite(blip, b.sprite)
    SetBlipColour(blip, b.color)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(b.label)
    EndTextCommandSetBlipName(blip)
end)
