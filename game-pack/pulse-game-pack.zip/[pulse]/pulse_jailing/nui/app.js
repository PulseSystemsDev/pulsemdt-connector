const hud = document.getElementById('hud');
const timeEl = document.getElementById('time');
const reasonEl = document.getElementById('reason');

function fmt(totalSeconds) {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action === 'begin') {
    reasonEl.textContent = data.reason || '';
    timeEl.textContent = fmt(data.remaining || 0);
    hud.classList.remove('hidden');
  } else if (data.action === 'tick') {
    timeEl.textContent = fmt(data.remaining || 0);
  } else if (data.action === 'end') {
    hud.classList.add('hidden');
  }
});
