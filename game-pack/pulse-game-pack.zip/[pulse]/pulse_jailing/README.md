# pulse_jailing

`pulse_jailing` applies and synchronizes PulseMDT jail sentences in game. Sentences created in game, in the PulseMDT dashboard, or through the Discord bot are reflected on the player.

## Requirements

- `pulsemdt`
- An active PulseMDT character; `pulse_core` is recommended
- OneSync recommended
- `pulse_notify` optional

## Installation

Configure cells, the release point, restrictions, and polling in `config.lua`, then start `pulse_jailing` after `pulsemdt`.

## Commands

- `/jail <serverId> <minutes> [reason]`
- `/unjail <serverId>`

Only eligible on-duty law-enforcement users can create or release sentences. Settings control weapon removal, the permitted jail radius, grace period, notifications, and synchronization intervals.
