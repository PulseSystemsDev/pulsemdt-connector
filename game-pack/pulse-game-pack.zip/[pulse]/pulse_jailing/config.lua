-- PulseMDT :: pulse_jailing (CAD-integrated jail)
--
-- Sentences live in the CAD, not a local file, so a jailing started here, from
-- the dashboard's Legal page, or from the Discord bot's /jail command all show
-- up as the same record. Reaches the CAD through the main `pulsemdt` resource,
-- so no API key here.
--
-- On-duty officers jail an explicit player by server ID (not "nearest
-- player"), since a crowd standing near an officer would make nearest-player
-- selection risky:
--   /jail <serverId> <minutes> [reason]
--   /unjail <serverId>
--
-- A CAD-initiated booking (from the dashboard or Discord) reaches an already
-- connected player within one poll interval (PollIntervalMs below); nobody
-- needs to run a command for that to apply.
--
-- Cell and release locations are dashboard-editable from the Scripts page
-- ("Jail cells"), the same mechanism pulse_jobs and pulse_dutystations use,
-- or replace the defaults below directly.

Config = {}

-- Officer command names.
Config.Command = 'jail'
Config.ReleaseCommand = 'unjail'

-- An officer must be within this many metres of the target server ID to jail
-- them (sanity check against jailing someone across the map by ID).
Config.MaxTargetDistance = 15.0

-- Strip weapons on entry.
Config.StripWeapons = true

-- Minutes between "time remaining" notifications while jailed.
Config.NotifyIntervalMinutes = 5

-- Metres a jailed player can wander from their assigned cell before being
-- teleported back. Grace period avoids false positives from lag/props.
Config.RestrictRadius = 25.0
Config.RestrictGraceSeconds = 8

-- How often (ms) the server checks the CAD for new bookings that should apply
-- to an already-connected player (dashboard or Discord-issued sentences).
Config.PollIntervalMs = 45000

-- How often (seconds) remaining time is checkpointed to the CAD, so a server
-- restart can't let someone skip the rest of their sentence.
Config.SyncIntervalSeconds = 60

-- Default cells (replaced by dashboard-managed stations when any exist).
Config.Cells = {
    { label = 'Bolingbroke Cell Block', x = 1846.0, y = 2585.0, z = 45.7, heading = 90.0 },
}

-- Where a released player is teleported.
Config.ReleasePoint = { x = 1857.3, y = 2588.4, z = 45.6, heading = 160.0 }

Config.Blip = { sprite = 428, color = 1, label = 'Bolingbroke Penitentiary' }
