# pulse_radar

`pulse_radar` adds a front/rear in-vehicle speed radar with lockable readings and PulseMDT-configurable alert thresholds.

## Requirements

- `pulsemdt`
- `pulse_notify` optional

## Installation

Start `pulse_radar` after `pulsemdt` and configure controls, units, range, and vehicle restrictions in `config.lua`.

## Controls

- `/radar` toggles the display by default.
- Page Up locks/unlocks the front reading.
- Page Down locks/unlocks the rear reading.

`Config.EmergencyOnly` restricts use to emergency vehicles. Speed units can be `mph` or `kmh`; alert speed and maximum detection range are configurable. Measurement runs client-side and the server supplies supported live settings.
