-- PulseMDT :: pulse_radar (In-vehicle speed radar)
--
-- A front/rear radar unit for patrol vehicles. Fully client-side measurement;
-- an officer locks a reading and writes the fine from the MDT tablet.

Config = {}

-- Command that toggles the radar on/off while in a permitted vehicle.
Config.Command = 'radar'

-- Key that toggles the radar. Set to false to disable.
Config.ToggleKey = false

-- Keys that lock/unlock the front and rear readings.
Config.LockFrontKey = 'PAGEUP'
Config.LockRearKey  = 'PAGEDOWN'

-- Only allow the radar in emergency vehicles (class 18). Set false to allow
-- the radar in any vehicle.
Config.EmergencyOnly = true

-- Units shown on the unit: 'mph' or 'kmh'.
Config.Units = 'mph'

-- Fast-lock: readings at or above this speed flash and beep.
Config.AlertSpeed = 80

-- Max distance (metres) the radar can clock a vehicle.
Config.MaxRange = 120.0
