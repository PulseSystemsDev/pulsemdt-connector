local radarOn = false
local lockedFront = nil
local lockedRear = nil
local remoteEnabled = true
local remoteAlert = nil

local SPEED_FACTOR = Config.Units == 'kmh' and 3.6 or 2.236936

local function alertSpeed()
    return remoteAlert or Config.AlertSpeed
end

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function sendNUI(action, data)
    SendNUIMessage({ action = action, data = data or {} })
end

local function canUseRadar()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return false end
    if Config.EmergencyOnly and GetVehicleClass(veh) ~= 18 then return false end
    return true, veh
end

local function clockDirection(veh, forward)
    local mult = forward and 1.0 or -1.0
    local from = GetOffsetFromEntityInWorldCoords(veh, 0.0, mult * 3.0, 0.5)
    local to   = GetOffsetFromEntityInWorldCoords(veh, 0.0, mult * Config.MaxRange, 0.5)
    local ray = StartShapeTestCapsule(from.x, from.y, from.z, to.x, to.y, to.z, 3.0, 10, veh, 7)
    local _, hit, _, _, entity = GetShapeTestResult(ray)
    if hit == 1 and entity ~= 0 and IsEntityAVehicle(entity) then
        local speed = GetEntitySpeed(entity) * SPEED_FACTOR
        local plate = (GetVehicleNumberPlateText(entity) or ''):gsub('%s+$', '')
        return { speed = math.floor(speed + 0.5), plate = plate }
    end
    return nil
end

local function setRadar(state)
    radarOn = state
    lockedFront, lockedRear = nil, nil
    sendNUI(state and 'show' or 'hide', { units = Config.Units, alert = alertSpeed() })
    if state then
        CreateThread(function()
            while radarOn do
                Wait(250)
                local ok, veh = canUseRadar()
                if not ok then
                    setRadar(false)
                    break
                end
                local front = clockDirection(veh, true)
                local rear  = clockDirection(veh, false)
                sendNUI('update', {
                    front = front,
                    rear = rear,
                    lockedFront = lockedFront,
                    lockedRear = lockedRear,
                    patrol = math.floor(GetEntitySpeed(veh) * SPEED_FACTOR + 0.5),
                })
                local hot = (front and front.speed >= alertSpeed()) or (rear and rear.speed >= alertSpeed())
                if hot then
                    PlaySoundFrontend(-1, 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET', false)
                end
            end
        end)
    end
end

RegisterCommand(Config.Command, function()
    if radarOn then
        setRadar(false)
    else
        if not remoteEnabled then
            notify('~y~PulseMDT~s~ The radar is disabled on this server.')
            return
        end
        local ok = canUseRadar()
        if not ok then
            notify('~y~PulseMDT~s~ The radar only works in a patrol vehicle.')
            return
        end
        setRadar(true)
    end
end, false)

RegisterNetEvent('pulse_radar:remoteConfig', function(cfg)
    if type(cfg) ~= 'table' then return end
    remoteEnabled = cfg.enabled ~= false
    remoteAlert = tonumber(cfg.alertSpeed)
    if not remoteEnabled and radarOn then setRadar(false) end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1000)
    TriggerServerEvent('pulse_radar:requestConfig')
end)

if Config.ToggleKey then
    RegisterKeyMapping(Config.Command, 'PulseMDT: Toggle radar', 'keyboard', Config.ToggleKey)
end

RegisterCommand('+pulse_radar_lockf', function()
    if not radarOn then return end
    if lockedFront then
        lockedFront = nil
        return
    end
    local ok, veh = canUseRadar()
    if ok then
        lockedFront = clockDirection(veh, true)
        if lockedFront then
            PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', false)
        end
    end
end, false)
RegisterCommand('-pulse_radar_lockf', function() end, false)
RegisterKeyMapping('+pulse_radar_lockf', 'PulseMDT Radar: Lock front', 'keyboard', Config.LockFrontKey)

RegisterCommand('+pulse_radar_lockr', function()
    if not radarOn then return end
    if lockedRear then
        lockedRear = nil
        return
    end
    local ok, veh = canUseRadar()
    if ok then
        lockedRear = clockDirection(veh, false)
        if lockedRear then
            PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', false)
        end
    end
end, false)
RegisterCommand('-pulse_radar_lockr', function() end, false)
RegisterKeyMapping('+pulse_radar_lockr', 'PulseMDT Radar: Lock rear', 'keyboard', Config.LockRearKey)
