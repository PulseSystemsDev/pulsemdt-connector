const radar = document.getElementById('radar');
let alertAt = 80;

const el = {
  fSpeed: document.getElementById('fSpeed'),
  fPlate: document.getElementById('fPlate'),
  fLock: document.getElementById('fLock'),
  fLockPlate: document.getElementById('fLockPlate'),
  rSpeed: document.getElementById('rSpeed'),
  rPlate: document.getElementById('rPlate'),
  rLock: document.getElementById('rLock'),
  rLockPlate: document.getElementById('rLockPlate'),
  patrol: document.getElementById('patrol'),
  units: document.getElementById('units'),
};

function setReading(speedEl, plateEl, reading) {
  if (reading && typeof reading.speed === 'number') {
    speedEl.textContent = String(reading.speed);
    speedEl.classList.toggle('hot', reading.speed >= alertAt);
    plateEl.textContent = reading.plate || '';
  } else {
    speedEl.textContent = '---';
    speedEl.classList.remove('hot');
    plateEl.textContent = '';
  }
}

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'show') {
    alertAt = (m.data && m.data.alert) || 80;
    el.units.textContent = ((m.data && m.data.units) || 'mph').toUpperCase();
    radar.classList.remove('hidden');
  } else if (m.action === 'hide') {
    radar.classList.add('hidden');
  } else if (m.action === 'update') {
    const d = m.data || {};
    setReading(el.fSpeed, el.fPlate, d.front);
    setReading(el.rSpeed, el.rPlate, d.rear);
    setReading(el.fLock, el.fLockPlate, d.lockedFront);
    setReading(el.rLock, el.rLockPlate, d.lockedRear);
    el.patrol.textContent = String(d.patrol ?? 0);
  }
});
