local function currentConfig()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_radar') end)
    if ok and type(c) == 'table' then
        return {
            enabled = c.enabled ~= false,
            alertSpeed = c.settings and tonumber(c.settings.alertSpeed) or nil,
        }
    end
    return { enabled = true }
end

AddEventHandler('pulsemdt:scriptsRefreshed', function()
    TriggerClientEvent('pulse_radar:remoteConfig', -1, currentConfig())
end)

RegisterNetEvent('pulse_radar:requestConfig', function()
    TriggerClientEvent('pulse_radar:remoteConfig', source, currentConfig())
end)
