local GROUPS = {}
for _, g in ipairs(Config.Groups) do GROUPS[#GROUPS + 1] = g.key end

local RCFG = { enabled = true, settings = {} }

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_garage') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function moduleEnabled() return RCFG.enabled ~= false end

local function effectiveStations()
    local byGroup = {}
    for _, key in ipairs(GROUPS) do byGroup[key] = {} end

    local raw = RCFG.settings and RCFG.settings.stationsJson
    local source = nil
    if type(raw) == 'string' and raw ~= '' then
        local ok, parsed = pcall(json.decode, raw)
        if ok and type(parsed) == 'table' then source = parsed end
    end
    if type(source) == 'table' then
        for _, s in ipairs(source) do
            if byGroup[s.job] and tonumber(s.x) then
                byGroup[s.job][#byGroup[s.job] + 1] = {
                    label = tostring(s.label or 'Garage'),
                    x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                    heading = tonumber(s.heading) or 0.0,
                }
            end
        end
    end
    for _, key in ipairs(GROUPS) do
        if #byGroup[key] == 0 then
            for _, s in ipairs(Config.Stations[key] or {}) do
                byGroup[key][#byGroup[key] + 1] = s
            end
        end
    end
    return byGroup
end

local function broadcastStations(target)
    local groups = {}
    local blips = {}
    for _, g in ipairs(Config.Groups) do
        groups[#groups + 1] = { key = g.key, label = g.label }
        blips[g.key] = g.blip
    end
    TriggerClientEvent('pulse_garage:stations', target or -1, {
        groups = groups, stations = effectiveStations(), blips = blips,
        radius = Config.StationRadius, bayDistance = Config.BayDistance,
    })
end

RegisterNetEvent('pulse_garage:requestStations', function()
    broadcastStations(source)
end)

local function notify(src, msg)
    TriggerClientEvent('pulse_garage:notify', src, msg)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

RegisterNetEvent('pulse_garage:openMenu', function(data)
    local src = source
    if not moduleEnabled() then notify(src, '~y~Garages are disabled on this server.') return end
    local group = data and data.group
    getCharId(src, function(charId)
        if not charId then notify(src, '~r~No active character.') return end
        exports.pulsemdt:ApiRequest('GET', '/garage?charId=' .. charId, nil, function(code, res)
            if code ~= 200 or not res then notify(src, '~r~The garage is unavailable right now.') return end
            TriggerClientEvent('pulse_garage:menu', src, { vehicles = res.vehicles or {}, group = group })
        end)
    end)
end)

RegisterNetEvent('pulse_garage:store', function(data)
    local src = source
    getCharId(src, function(charId)
        if not charId then return end
        local plate = tostring(data and data.plate or ''):gsub('^%s+', ''):gsub('%s+$', '')
        local group = data and data.group
        exports.pulsemdt:ApiRequest('GET', '/garage?charId=' .. charId, nil, function(code, res)
            if code ~= 200 or not res then notify(src, '~r~The garage is unavailable right now.') return end
            local match = nil
            for _, v in ipairs(res.vehicles or {}) do
                if v.plate == plate and v.garaged ~= 1 then match = v break end
            end
            if not match then notify(src, '~r~You do not own that vehicle, or it is already stored.') return end
            if group and match.class ~= group then
                notify(src, ('~r~This is not a %s garage.'):format(group))
                return
            end
            exports.pulsemdt:ApiRequest('POST', '/garage', { action = 'store', charId = charId, vehicleId = match.id }, function(scode)
                if scode == 200 then
                    TriggerClientEvent('pulse_garage:stored', src, {})
                    notify(src, ('~g~Garage~s~ %s stored.'):format(match.model))
                else
                    notify(src, '~r~Could not store that vehicle right now.')
                end
            end)
        end)
    end)
end)

RegisterNetEvent('pulse_garage:retrieve', function(data)
    local src = source
    local vehicleId = tonumber(data and data.vehicleId)
    if not vehicleId then return end
    getCharId(src, function(charId)
        if not charId then return end
        exports.pulsemdt:ApiRequest('POST', '/garage', { action = 'retrieve', charId = charId, vehicleId = vehicleId }, function(code, res)
            if code == 200 and res and res.plate then
                TriggerClientEvent('pulse_garage:spawn', src, { plate = res.plate, model = res.model })
            else
                notify(src, '~r~Could not retrieve that vehicle right now.')
            end
        end)
    end)
end)
