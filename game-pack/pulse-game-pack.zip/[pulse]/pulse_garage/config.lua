-- PulseMDT :: pulse_garage (Store and retrieve owned vehicles)
--
-- Any vehicle registered to a character in the CAD (bought at the
-- dealership, added by the framework bridge, or entered by hand on the
-- civilian portal) can be stored here and pulled back out later. This is
-- separate from pulse_impound: impound is what happens to your vehicle when
-- police tow it, this is what you do with it yourself.
--
-- Three garage groups, one per vehicle class (land, air, sea), so a boat
-- doesn't spawn in the middle of a street and a car doesn't spawn on water.
-- A garage only stores or retrieves vehicles matching its own class.
--
-- Reaches the CAD through the main `pulsemdt` resource, so no API key here.
--
-- Garage locations are dashboard-editable from the Scripts page ("Garages"),
-- the same mechanism pulse_jobs, pulse_dutystations, pulse_jailing, and
-- pulse_needs use, or replace the defaults below directly.

Config = {}

Config.StationRadius = 2.5

-- The vehicle bay is projected this many metres in front of the garage point
-- along its heading, same idea as pulse_jobs' job station bays.
Config.BayDistance = 7.0

Config.Groups = {
    { key = 'land', label = 'Garage',   blip = { sprite = 357, color = 3,  label = 'Garage' } },
    { key = 'air',  label = 'Hangar',   blip = { sprite = 359, color = 5,  label = 'Hangar' } },
    { key = 'sea',  label = 'Marina',   blip = { sprite = 356, color = 25, label = 'Marina' } },
}

-- Default garages (replaced per group by dashboard stations when any exist).
Config.Stations = {
    land = {
        { label = 'Downtown Garage', x = -196.8, y = -1301.6, z = 31.3, heading = 30.0 },
    },
    air = {
        { label = 'Los Santos Hangar', x = -1336.9, y = -2495.5, z = 13.9, heading = 320.0 },
    },
    sea = {
        { label = 'Vespucci Marina', x = -1462.8, y = -1015.9, z = 3.0, heading = 130.0 },
    },
}
