# pulse_garage

`pulse_garage` stores and retrieves character-owned vehicles through PulseMDT, with separate public and role-specific garage groups.

## Requirements

- `pulsemdt` with garage records available
- An active PulseMDT character; `pulse_core` is recommended
- `pulse_notify` optional

## Installation

Keep the folder name `pulse_garage`, configure groups and locations in `config.lua`, and start it after `pulsemdt`.

## Configuration

`Config.Groups` defines garage types and blips. `Config.Stations` defines their locations. `Config.StationRadius` controls interaction range, while `Config.BayDistance` controls where vehicles spawn.

Dashboard-managed station data can override local stations. A vehicle must belong to the active character before it can be stored or retrieved.
