const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'pulse_garage';

const garage = document.getElementById('garage');
const title = document.getElementById('title');
const closeBtn = document.getElementById('close');
const storeBtn = document.getElementById('storeBtn');
const storeHint = document.getElementById('storeHint');
const list = document.getElementById('list');
const empty = document.getElementById('empty');

function post(name, body) {
  return fetch(`https://${resource}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  });
}

closeBtn.addEventListener('click', () => { garage.classList.add('hidden'); post('closeGarage'); });
storeBtn.addEventListener('click', () => { post('storeVehicle'); garage.classList.add('hidden'); post('closeGarage'); });

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !garage.classList.contains('hidden')) {
    garage.classList.add('hidden');
    post('closeGarage');
  }
});

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action !== 'menu') return;

  title.textContent = data.label || 'Garage';
  const hasCurrent = !!data.currentPlate;
  storeBtn.classList.toggle('hidden', !hasCurrent);
  storeHint.classList.toggle('hidden', hasCurrent);

  const garaged = (data.vehicles || []).filter((v) => v.garaged);
  list.innerHTML = '';
  empty.classList.toggle('hidden', garaged.length > 0);
  garaged.forEach((v) => {
    const row = document.createElement('div');
    row.className = 'v-item';
    row.innerHTML = `
      <div>
        <div class="name">${v.model}</div>
        <div class="sub">${v.plate}</div>
      </div>
      <button type="button">Retrieve</button>
    `;
    row.querySelector('button').addEventListener('click', () => {
      post('retrieveVehicle', { vehicleId: v.id });
      garage.classList.add('hidden');
      post('closeGarage');
    });
    list.appendChild(row);
  });

  garage.classList.remove('hidden');
});
