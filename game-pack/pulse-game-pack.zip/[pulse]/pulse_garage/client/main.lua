local stationData = { groups = {}, stations = {}, blips = {}, radius = 2.5, bayDistance = 7.0 }
local groupByKey = {}
local stationBlips = {}
local activeStation = nil
local activeGroup = nil
local menuOpen = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_garage:notify', function(msg)
    if msg then notify(msg) end
end)

local function rebuildStationBlips()
    for _, b in ipairs(stationBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    stationBlips = {}
    for key, list in pairs(stationData.stations or {}) do
        local meta = stationData.blips and stationData.blips[key]
        if meta then
            for _, st in ipairs(list) do
                local b = AddBlipForCoord(st.x, st.y, st.z)
                SetBlipSprite(b, meta.sprite or 357)
                SetBlipColour(b, meta.color or 3)
                SetBlipScale(b, 0.75)
                SetBlipAsShortRange(b, true)
                BeginTextCommandSetBlipName('STRING')
                AddTextComponentSubstringPlayerName(meta.label or key)
                EndTextCommandSetBlipName(b)
                stationBlips[#stationBlips + 1] = b
            end
        end
    end
end

RegisterNetEvent('pulse_garage:stations', function(payload)
    if type(payload) ~= 'table' then return end
    stationData = payload
    groupByKey = {}
    for _, g in ipairs(stationData.groups or {}) do groupByKey[g.key] = g end
    rebuildStationBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_garage:requestStations')
end)

local function bayFor(st)
    local rad = math.rad(st.heading or 0.0)
    return {
        x = st.x - math.sin(rad) * (stationData.bayDistance or 7.0),
        y = st.y + math.cos(rad) * (stationData.bayDistance or 7.0),
        z = st.z,
        heading = st.heading or 0.0,
    }
end

local function currentVehiclePlate()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return nil end
    return (GetVehicleNumberPlateText(veh) or ''):gsub('^%s+', ''):gsub('%s+$', '')
end

RegisterNetEvent('pulse_garage:menu', function(data)
    menuOpen = true
    SetNuiFocus(true, true)
    local group = groupByKey[data.group]
    local filtered = {}
    for _, v in ipairs(data.vehicles or {}) do
        if v.class == data.group then filtered[#filtered + 1] = v end
    end
    SendNUIMessage({
        action = 'menu', vehicles = filtered, currentPlate = currentVehiclePlate(),
        label = group and group.label or 'Garage',
    })
end)

RegisterNetEvent('pulse_garage:stored', function()
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 then DeleteVehicle(veh) end
end)

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local deadline = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return nil end
        Wait(25)
    end
    return hash
end

RegisterNetEvent('pulse_garage:spawn', function(data)
    if not activeStation then return end
    local hash = loadModel(data.model)
    if not hash then notify('~r~Garage~s~ That vehicle model failed to load.') return end
    local bay = bayFor(activeStation)
    local veh = CreateVehicle(hash, bay.x, bay.y, bay.z, bay.heading, true, false)
    SetModelAsNoLongerNeeded(hash)
    SetVehicleNumberPlateText(veh, data.plate)
    SetVehicleOnGroundProperly(veh)
    notify(('~g~Garage~s~ %s is waiting in the bay.'):format(data.model))
end)

RegisterNUICallback('storeVehicle', function(_, cb)
    local plate = currentVehiclePlate()
    if plate then TriggerServerEvent('pulse_garage:store', { plate = plate, group = activeGroup }) end
    cb({})
end)

RegisterNUICallback('retrieveVehicle', function(data, cb)
    TriggerServerEvent('pulse_garage:retrieve', { vehicleId = data.vehicleId })
    cb({})
end)

RegisterNUICallback('closeGarage', function(_, cb)
    menuOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

CreateThread(function()
    while true do
        local sleep = 900
        if not menuOpen then
            local pos = GetEntityCoords(PlayerPedId())
            for key, list in pairs(stationData.stations or {}) do
                local group = groupByKey[key]
                for _, st in ipairs(list) do
                    local dist = #(pos - vector3(st.x, st.y, st.z))
                    if dist < 30.0 then
                        sleep = 0
                        DrawMarker(2, st.x, st.y, st.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            0.5, 0.5, 0.5, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                        if dist <= (stationData.radius or 2.5) and group then
                            BeginTextCommandDisplayHelp('STRING')
                            AddTextComponentSubstringPlayerName(('Press ~INPUT_CONTEXT~ : %s'):format(group.label or key))
                            EndTextCommandDisplayHelp(0, false, true, -1)
                            if IsControlJustReleased(0, 38) then
                                activeStation = st
                                activeGroup = key
                                TriggerServerEvent('pulse_garage:openMenu', { group = key })
                                Wait(400)
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
