-- This annotated file documents every supported setting.
-- The resource loads config.lua, so copy these values there when changing the configuration.
-- This configuration is loaded client-side and can be downloaded and read by every player.
-- Never put API keys, passwords, access tokens, webhooks, private URLs, or other secrets here.

Config = {
    -- Title used when a notification does not provide a non-empty title.
    -- The effective value is shortened to MaximumTitleLength characters.
    DefaultTitle = 'PulseMDT',

    -- Kind used when a notification provides an unknown or missing kind.
    -- Supported values are alert, success, warning, and info.
    DefaultKind = 'info',

    -- Display time in milliseconds when a notification omits duration.
    -- The effective value is constrained by MinimumDuration and MaximumDuration.
    DefaultDuration = 6000,

    -- Shortest permitted display time in milliseconds.
    -- Values are clamped to the hard safety range of 250 through 120000.
    MinimumDuration = 2500,

    -- Longest permitted display time in milliseconds.
    -- This cannot be lower than MinimumDuration or higher than 120000.
    MaximumDuration = 20000,

    -- Maximum number of notifications shown at once.
    -- Values are clamped to the range of 1 through 20.
    MaximumVisible = 5,

    -- Maximum number of notifications retained while the browser UI starts or reloads.
    -- When full, the oldest queued notification is discarded.
    -- Values are clamped to the range of 1 through 200.
    QueueLimit = 50,

    -- Maximum Unicode characters retained in a title.
    -- Values are clamped to the range of 1 through 200.
    MaximumTitleLength = 80,

    -- Maximum Unicode characters retained in a message.
    -- Values are clamped to the range of 1 through 4000.
    MaximumMessageLength = 1000,

    -- Visible label for each supported notification kind.
    -- Each label is shortened to 32 Unicode characters and falls back when empty or invalid.
    Labels = {
        alert = 'Alert',
        success = 'Success',
        warning = 'Notice',
        info = 'Info',
    },
}
