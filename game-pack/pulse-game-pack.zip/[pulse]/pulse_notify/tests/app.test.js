const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

class FakeElement {
  constructor(tagName) {
    this.tagName = tagName;
    this.children = [];
    this.parentElement = null;
    this.dataset = {};
    this.className = '';
    this.textContent = '';
    this.listeners = new Map();
    this.classes = new Set();
    this.classList = { add: (name) => this.classes.add(name) };
    this.style = {
      values: new Map(),
      setProperty: (name, value) => this.style.values.set(name, value),
    };
  }

  append(...elements) {
    elements.forEach((element) => {
      element.parentElement = this;
      this.children.push(element);
    });
  }

  prepend(element) {
    element.parentElement = this;
    this.children.unshift(element);
  }

  remove() {
    if (!this.parentElement) return;
    const index = this.parentElement.children.indexOf(this);
    if (index >= 0) this.parentElement.children.splice(index, 1);
    this.parentElement = null;
  }

  addEventListener(name, handler) {
    const handlers = this.listeners.get(name) || [];
    handlers.push(handler);
    this.listeners.set(name, handlers);
  }

  removeEventListener(name, handler) {
    const handlers = this.listeners.get(name) || [];
    this.listeners.set(name, handlers.filter((item) => item !== handler));
  }

  dispatch(name, event) {
    const handlers = [...(this.listeners.get(name) || [])];
    handlers.forEach((handler) => handler(event));
  }
}

function createHarness() {
  const stack = new FakeElement('div');
  const windowListeners = new Map();
  const timerCallbacks = new Map();
  let nextTimer = 1;

  const context = vm.createContext({
    document: {
      getElementById: () => stack,
      createElement: (tagName) => new FakeElement(tagName),
    },
    window: {
      addEventListener: (name, handler) => windowListeners.set(name, handler),
    },
    setTimeout: (handler) => {
      const id = nextTimer;
      nextTimer += 1;
      timerCallbacks.set(id, handler);
      return id;
    },
    clearTimeout: (id) => timerCallbacks.delete(id),
  });

  const source = fs.readFileSync(path.join(__dirname, '..', 'nui', 'app.js'), 'utf8');
  vm.runInContext(source, context, { filename: 'nui/app.js' });

  return {
    stack,
    timerCallbacks,
    notify(data) {
      windowListeners.get('message')({ data: { action: 'notify', data } });
    },
    runTimer(id) {
      const handler = timerCallbacks.get(id);
      timerCallbacks.delete(id);
      if (handler) handler();
    },
  };
}

function titleOf(toast) {
  return toast.children[0].children[1].textContent;
}

test('six synchronous notifications retain only the newest five', () => {
  const harness = createHarness();
  for (let index = 0; index < 6; index += 1) {
    harness.notify({ kind: 'info', title: `Test ${index}`, message: 'Burst', duration: 2500 });
  }

  assert.equal(harness.stack.children.length, 5);
  assert.deepEqual(harness.stack.children.map(titleOf), ['Test 5', 'Test 4', 'Test 3', 'Test 2', 'Test 1']);
  assert.equal(harness.timerCallbacks.size, 5);
});

test('payload values are validated, clamped, shortened, and rendered as text', () => {
  const harness = createHarness();
  const unsafe = '<img src=x onerror=alert(1)>';
  harness.notify({ kind: 'unknown', title: unsafe.repeat(10), message: unsafe, duration: Infinity });

  const toast = harness.stack.children[0];
  assert.equal(toast.className, 'toast info');
  assert.equal(Array.from(titleOf(toast)).length, 80);
  assert.equal(toast.children[1].textContent, unsafe);
  assert.equal(toast.style.values.get('--life'), '6000ms');
});

test('invalid payload types are ignored', () => {
  const harness = createHarness();
  harness.notify(null);
  harness.notify('not-an-object');
  harness.notify([]);
  assert.equal(harness.stack.children.length, 0);
});

test('only the toast-out animation removes a leaving toast', () => {
  const harness = createHarness();
  harness.notify({ kind: 'alert', title: 'Dispatch', message: 'Test', duration: 2500 });
  const toast = harness.stack.children[0];
  const expiry = [...harness.timerCallbacks.keys()][0];
  harness.runTimer(expiry);

  toast.dispatch('animationend', { target: toast.children[2], animationName: 'life' });
  assert.equal(harness.stack.children.length, 1);
  toast.dispatch('animationend', { target: toast, animationName: 'toast-in' });
  assert.equal(harness.stack.children.length, 1);
  toast.dispatch('animationend', { target: toast, animationName: 'toast-out' });
  assert.equal(harness.stack.children.length, 0);
});
