# pulse_notify

`pulse_notify` is a lightweight standalone notification resource for FiveM. It accepts familiar GTA-formatted strings or structured tables and renders safe, bounded NUI toasts without a framework dependency.

## Features

- Alert, success, warning, and info styles
- Client export plus client/server event support
- GTA formatting cleanup, including multiline `~n~` input
- Configurable labels, durations, limits, and startup queue
- Bounded notification count with deterministic overflow removal
- Text-only DOM rendering to prevent HTML injection
- Native NUI startup handshake so early notifications are queued instead of lost

## Installation

1. Put this repository in your FiveM resources directory.
2. Keep the folder name exactly `pulse_notify`.
3. Keep the included comment-free `config.lua`, or copy `config.example.lua` over it and edit the values.
4. Add this line to `server.cfg` before resources that use its export:

```cfg
ensure pulse_notify
```

GitHub source ZIPs extract to a suffixed folder such as `pulse_notify-main`. Rename that folder to `pulse_notify`; FiveM export lookups use the resource folder name.

## Client usage

Pass a GTA-formatted string:

```lua
exports.pulse_notify:Notify('~g~PulseMDT~s~ Payment sent.')
```

Pass a structured notification:

```lua
exports.pulse_notify:Notify({
    kind = 'success',
    title = 'Garage',
    message = 'Vehicle stored.',
    duration = 5000,
})
```

Use the local client event when an event fits the calling resource better:

```lua
TriggerEvent('pulse_notify:send', {
    kind = 'info',
    title = 'Dispatch',
    message = 'Unit status updated.',
})
```

`Notify` returns `true` when it accepts the payload and `false` for an unsupported payload type.

## Server usage

Send a notification to one client:

```lua
TriggerClientEvent('pulse_notify:send', playerId, {
    kind = 'warning',
    title = 'Dispatch',
    message = 'Return to your assigned area.',
    duration = 7000,
})
```

Use `-1` instead of `playerId` only when every connected player should receive the notification.

## Payloads

Structured payloads support these fields:

| Field | Accepted value | Default |
| --- | --- | --- |
| `kind` | `alert`, `success`, `warning`, or `info` | `Config.DefaultKind` |
| `title` | String, number, or boolean | `Config.DefaultTitle` |
| `message` | String, number, or boolean | Empty |
| `duration` | Milliseconds | `Config.DefaultDuration` |

Durations and text lengths are clamped to the configured and hard safety limits. Unknown kinds use the configured default.

String payloads recognize the common leading color codes `~r~`, `~g~`, `~y~`, and `~b~` for their notification kind. Formatting tags are removed before display, `~n~` becomes a line break before the message is normalized, and a leading colored segment ending in `~s~` is used as the title.

## Configuration

Every setting is documented in `config.example.lua`. The shipped `config.lua` contains the same working defaults without comments.

| Setting | Purpose | Hard bounds |
| --- | --- | --- |
| `Config.DefaultTitle` | Fallback notification title | Configured title limit |
| `Config.DefaultKind` | Fallback kind | Four supported kinds |
| `Config.DefaultDuration` | Fallback display time in milliseconds | Effective duration range |
| `Config.MinimumDuration` | Shortest display time | 250-120000 ms |
| `Config.MaximumDuration` | Longest display time | Minimum-120000 ms |
| `Config.MaximumVisible` | Toasts visible at once | 1-20 |
| `Config.QueueLimit` | Notifications retained while NUI starts | 1-200 |
| `Config.MaximumTitleLength` | Maximum title length | 1-200 Unicode characters |
| `Config.MaximumMessageLength` | Maximum message length | 1-4000 Unicode characters |
| `Config.Labels` | Visible labels for each kind | 32 Unicode characters each |

The configuration runs on the client and is downloadable by players. Never put credentials, tokens, webhooks, private URLs, or other secrets in `config.lua`.

## Troubleshooting

### The export does not exist

Confirm the folder is named exactly `pulse_notify`, the resource is started, and `ensure pulse_notify` appears before the resource calling the export.

### Early startup notifications do not appear

The client retains a bounded startup queue until the NUI confirms initialization. Check the F8 console for NUI errors and make sure `nui/index.html`, `nui/app.js`, and `nui/style.css` were copied together.

### Too many or too few notifications are visible

Set `Config.MaximumVisible` and restart the resource. Values outside the supported range are clamped.

### A notification disappears sooner or later than requested

The duration is constrained by `Config.MinimumDuration` and `Config.MaximumDuration`, including values supplied by other resources.

## Validation

The NUI regression suite uses only Node.js built-ins:

```sh
node --test tests/app.test.js
```

## Support

See the [Pulse Systems documentation](https://docs.pulsesystems.dev/) for related resources and support information.
