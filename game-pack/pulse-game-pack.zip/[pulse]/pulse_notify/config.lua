Config = {
    DefaultTitle = 'PulseMDT',
    DefaultKind = 'info',
    DefaultDuration = 6000,
    MinimumDuration = 2500,
    MaximumDuration = 20000,
    MaximumVisible = 5,
    QueueLimit = 50,
    MaximumTitleLength = 80,
    MaximumMessageLength = 1000,
    Labels = {
        alert = 'Alert',
        success = 'Success',
        warning = 'Notice',
        info = 'Info',
    },
}
