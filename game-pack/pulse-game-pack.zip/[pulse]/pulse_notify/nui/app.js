const stack = document.getElementById('stack');
const HARD_LIMITS = {
  durationMinimum: 250,
  durationMaximum: 120000,
  visibleMaximum: 20,
  titleMaximum: 200,
  messageMaximum: 4000,
  labelMaximum: 32,
};

const DEFAULTS = {
  defaultTitle: 'PulseMDT',
  defaultKind: 'info',
  defaultDuration: 6000,
  minimumDuration: 2500,
  maximumDuration: 20000,
  maximumVisible: 5,
  maximumTitleLength: 80,
  maximumMessageLength: 1000,
  labels: {
    alert: 'Alert',
    success: 'Success',
    warning: 'Notice',
    info: 'Info',
  },
};

const VALID_KINDS = new Set(['alert', 'success', 'warning', 'info']);
const timers = new WeakMap();
let settings = { ...DEFAULTS, labels: { ...DEFAULTS.labels } };

function finiteNumber(value) {
  if (typeof value === 'string' && value.trim() === '') return null;
  if (typeof value !== 'number' && typeof value !== 'string') return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function clampInteger(value, fallback, minimum, maximum) {
  const parsed = finiteNumber(value);
  return Math.min(maximum, Math.max(minimum, Math.round(parsed ?? fallback)));
}

function truncateText(value, limit) {
  const sample = value.length > limit * 4 ? value.slice(0, limit * 4) : value;
  return Array.from(sample).slice(0, limit).join('');
}

function cleanText(value, fallback, limit) {
  const valueType = typeof value;
  if (value == null || !['string', 'number', 'boolean'].includes(valueType)) value = fallback;
  if (typeof value === 'number' && !Number.isFinite(value)) value = fallback;
  let text = String(value ?? '');
  if (text.length > limit * 8) text = text.slice(0, limit * 8);
  text = text.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim();
  return truncateText(text, limit);
}

function normalizeKind(value, fallback) {
  if (typeof value !== 'string') return fallback;
  const normalized = value.toLowerCase();
  return VALID_KINDS.has(normalized) ? normalized : fallback;
}

function trimOverflow() {
  Array.from(stack.children).slice(settings.maximumVisible).forEach(removeToast);
}

function applyConfig(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return;

  const maximumTitleLength = clampInteger(input.maximumTitleLength, DEFAULTS.maximumTitleLength, 1, HARD_LIMITS.titleMaximum);
  const maximumMessageLength = clampInteger(input.maximumMessageLength, DEFAULTS.maximumMessageLength, 1, HARD_LIMITS.messageMaximum);
  const minimumDuration = clampInteger(input.minimumDuration, DEFAULTS.minimumDuration, HARD_LIMITS.durationMinimum, HARD_LIMITS.durationMaximum);
  const maximumDuration = clampInteger(input.maximumDuration, DEFAULTS.maximumDuration, minimumDuration, HARD_LIMITS.durationMaximum);
  const defaultKind = normalizeKind(input.defaultKind, DEFAULTS.defaultKind);
  let defaultTitle = cleanText(input.defaultTitle, DEFAULTS.defaultTitle, maximumTitleLength);
  if (!defaultTitle) defaultTitle = truncateText(DEFAULTS.defaultTitle, maximumTitleLength);

  const suppliedLabels = input.labels && typeof input.labels === 'object' && !Array.isArray(input.labels) ? input.labels : {};
  const labels = {};
  VALID_KINDS.forEach((kind) => {
    labels[kind] = cleanText(suppliedLabels[kind], DEFAULTS.labels[kind], HARD_LIMITS.labelMaximum) || DEFAULTS.labels[kind];
  });

  settings = {
    defaultTitle,
    defaultKind,
    defaultDuration: clampInteger(input.defaultDuration, DEFAULTS.defaultDuration, minimumDuration, maximumDuration),
    minimumDuration,
    maximumDuration,
    maximumVisible: clampInteger(input.maximumVisible, DEFAULTS.maximumVisible, 1, HARD_LIMITS.visibleMaximum),
    maximumTitleLength,
    maximumMessageLength,
    labels,
  };

  trimOverflow();
}

function removeToast(el) {
  if (!el) return;
  const state = timers.get(el);
  if (state) {
    if (state.expiry != null) clearTimeout(state.expiry);
    if (state.fallback != null) clearTimeout(state.fallback);
    if (state.animationEnd) el.removeEventListener('animationend', state.animationEnd);
  }
  timers.delete(el);
  el.remove();
}

function dismiss(el) {
  if (!el || el.dataset.leaving === '1') return;
  el.dataset.leaving = '1';
  el.classList.add('leaving');

  const state = timers.get(el) || {};
  if (state.expiry != null) clearTimeout(state.expiry);
  state.animationEnd = (event) => {
    if (event.target === el && event.animationName === 'toast-out') removeToast(el);
  };
  el.addEventListener('animationend', state.animationEnd);
  state.fallback = setTimeout(() => removeToast(el), 400);
  timers.set(el, state);
}

function notify(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return false;

  const kind = normalizeKind(data.kind, settings.defaultKind);
  const duration = clampInteger(data.duration, settings.defaultDuration, settings.minimumDuration, settings.maximumDuration);
  let title = cleanText(data.title, settings.defaultTitle, settings.maximumTitleLength);
  if (!title) title = settings.defaultTitle;
  const message = cleanText(data.message, '', settings.maximumMessageLength);

  const el = document.createElement('div');
  el.className = `toast ${kind}` + (message ? '' : ' no-message');
  el.style.setProperty('--life', `${duration}ms`);

  const head = document.createElement('div');
  head.className = 'head';
  const kindEl = document.createElement('span');
  kindEl.className = 'kind';
  kindEl.textContent = settings.labels[kind];
  const titleEl = document.createElement('span');
  titleEl.className = 'title';
  titleEl.textContent = title;
  head.append(kindEl, titleEl);

  const msgEl = document.createElement('div');
  msgEl.className = 'message';
  msgEl.textContent = message;

  const life = document.createElement('div');
  life.className = 'life';

  el.append(head, msgEl, life);
  stack.prepend(el);

  timers.set(el, { expiry: setTimeout(() => dismiss(el), duration) });
  trimOverflow();
  return true;
}

window.addEventListener('message', (event) => {
  const message = event.data;
  if (!message || typeof message !== 'object' || Array.isArray(message)) return;
  if (message.action === 'notify') notify(message.data);
});

async function postNui(endpoint) {
  const resourceName = typeof GetParentResourceName === 'function' ? GetParentResourceName() : '';
  if (!resourceName) return null;

  const response = await fetch(`https://${resourceName}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: '{}',
  });

  if (!response.ok) throw new Error(`NUI request failed with ${response.status}`);
  const payload = await response.json();
  if (!payload || payload.ok !== true) throw new Error('NUI request was rejected');
  return payload;
}

let retryDelay = 100;

async function initializeNui() {
  if (typeof GetParentResourceName !== 'function') return;

  try {
    const ready = await postNui('ready');
    applyConfig(ready && ready.config);
    await postNui('initialized');
  } catch (_) {
    setTimeout(initializeNui, retryDelay);
    retryDelay = Math.min(retryDelay * 2, 2000);
  }
}

initializeNui();
