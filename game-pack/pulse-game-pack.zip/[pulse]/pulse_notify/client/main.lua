local HARD_LIMITS = {
    durationMinimum = 250,
    durationMaximum = 120000,
    visibleMaximum = 20,
    queueMaximum = 200,
    titleMaximum = 200,
    messageMaximum = 4000,
    labelMaximum = 32,
}

local KIND_BY_CODE = {
    r = 'alert',
    g = 'success',
    y = 'warning',
    b = 'info',
}

local VALID_KINDS = {
    alert = true,
    success = true,
    warning = true,
    info = true,
}

local DEFAULT_LABELS = {
    alert = 'Alert',
    success = 'Success',
    warning = 'Notice',
    info = 'Info',
}

local function finiteNumber(value)
    local valueType = type(value)
    if valueType ~= 'number' and valueType ~= 'string' then
        return nil
    end

    local parsed = tonumber(value)
    if not parsed or parsed ~= parsed or parsed == math.huge or parsed == -math.huge then
        return nil
    end

    return parsed
end

local function clampInteger(value, fallback, minimum, maximum)
    local parsed = finiteNumber(value) or fallback
    parsed = math.floor(parsed + 0.5)
    if parsed < minimum then return minimum end
    if parsed > maximum then return maximum end
    return parsed
end

local function truncateUtf8(value, limit)
    local ok, length = pcall(utf8.len, value)
    if not ok or not length then
        value = value:gsub('[\128-\255]', '?')
        length = #value
    end

    if length <= limit then return value end

    local offset = utf8.offset(value, limit + 1)
    if offset then return value:sub(1, offset - 1) end
    return value
end

local function cleanText(value, fallback, limit)
    local valueType = type(value)
    if value == nil then
        value = fallback
    elseif valueType ~= 'string' and valueType ~= 'number' and valueType ~= 'boolean' then
        value = fallback
    end

    local text = tostring(value or '')
    text = text:gsub('[\r\n\t]+', ' ')
    text = text:gsub('%c', '')
    text = text:gsub('%s+', ' ')
    text = text:match('^%s*(.-)%s*$') or ''
    return truncateUtf8(text, limit)
end

local function normalizeKind(value, fallback)
    if type(value) == 'string' then
        local normalized = value:lower()
        if VALID_KINDS[normalized] then return normalized end
    end
    return fallback
end

local rawConfig = type(Config) == 'table' and Config or {}
local maximumTitleLength = clampInteger(rawget(rawConfig, 'MaximumTitleLength'), 80, 1, HARD_LIMITS.titleMaximum)
local maximumMessageLength = clampInteger(rawget(rawConfig, 'MaximumMessageLength'), 1000, 1, HARD_LIMITS.messageMaximum)
local minimumDuration = clampInteger(rawget(rawConfig, 'MinimumDuration'), 2500, HARD_LIMITS.durationMinimum, HARD_LIMITS.durationMaximum)
local maximumDuration = clampInteger(rawget(rawConfig, 'MaximumDuration'), 20000, minimumDuration, HARD_LIMITS.durationMaximum)
local defaultKind = normalizeKind(rawget(rawConfig, 'DefaultKind'), 'info')
local defaultTitle = cleanText(rawget(rawConfig, 'DefaultTitle'), 'PulseMDT', maximumTitleLength)
if defaultTitle == '' then
    defaultTitle = truncateUtf8('PulseMDT', maximumTitleLength)
end

local rawLabels = rawget(rawConfig, 'Labels')
if type(rawLabels) ~= 'table' then rawLabels = {} end

local labels = {}
for kind, fallback in pairs(DEFAULT_LABELS) do
    local label = cleanText(rawget(rawLabels, kind), fallback, HARD_LIMITS.labelMaximum)
    labels[kind] = label ~= '' and label or fallback
end

local settings = {
    defaultTitle = defaultTitle,
    defaultKind = defaultKind,
    defaultDuration = clampInteger(rawget(rawConfig, 'DefaultDuration'), 6000, minimumDuration, maximumDuration),
    minimumDuration = minimumDuration,
    maximumDuration = maximumDuration,
    maximumVisible = clampInteger(rawget(rawConfig, 'MaximumVisible'), 5, 1, HARD_LIMITS.visibleMaximum),
    queueLimit = clampInteger(rawget(rawConfig, 'QueueLimit'), 50, 1, HARD_LIMITS.queueMaximum),
    maximumTitleLength = maximumTitleLength,
    maximumMessageLength = maximumMessageLength,
    labels = labels,
}

local nuiConfig = {
    defaultTitle = settings.defaultTitle,
    defaultKind = settings.defaultKind,
    defaultDuration = settings.defaultDuration,
    minimumDuration = settings.minimumDuration,
    maximumDuration = settings.maximumDuration,
    maximumVisible = settings.maximumVisible,
    maximumTitleLength = settings.maximumTitleLength,
    maximumMessageLength = settings.maximumMessageLength,
    labels = settings.labels,
}

local function stripFormatting(value)
    value = value:gsub('~[nN]~', '\n')
    value = value:gsub('~[^~\r\n]+~', '')
    value = value:gsub('</?[cC]>', '')
    return value
end

local function kindFromString(value)
    for code in value:gmatch('~([%a])~') do
        local kind = KIND_BY_CODE[code:lower()]
        if kind then return kind end
    end
    return settings.defaultKind
end

local function normalizeDuration(value)
    return clampInteger(value, settings.defaultDuration, settings.minimumDuration, settings.maximumDuration)
end

local function parseString(input)
    local rawLimit = settings.maximumTitleLength + settings.maximumMessageLength + 256
    local raw = truncateUtf8(input, rawLimit)
    local kind = kindFromString(raw)
    local prepared = raw:gsub('\r\n', '\n'):gsub('\r', '\n'):gsub('~[nN]~', '\n')
    local firstLine, rest = prepared:match('^([^\n]*)\n(.*)$')
    local title
    local message

    if firstLine then
        title = stripFormatting(firstLine)
        message = stripFormatting(rest)
    else
        local code, styledTitle, styledMessage = prepared:match('^~([%a])~(.-)~[sS]~%s*(.*)$')
        if code and KIND_BY_CODE[code:lower()] and styledTitle ~= '' then
            title = stripFormatting(styledTitle)
            message = stripFormatting(styledMessage)
        else
            title = settings.defaultTitle
            message = stripFormatting(prepared)
        end
    end

    title = cleanText(title, settings.defaultTitle, settings.maximumTitleLength)
    if title == '' then title = settings.defaultTitle end

    return {
        kind = kind,
        title = title,
        message = cleanText(message, '', settings.maximumMessageLength),
        duration = settings.defaultDuration,
    }
end

local function parseTable(input)
    local title = cleanText(rawget(input, 'title'), settings.defaultTitle, settings.maximumTitleLength)
    if title == '' then title = settings.defaultTitle end

    return {
        kind = normalizeKind(rawget(input, 'kind'), settings.defaultKind),
        title = title,
        message = cleanText(rawget(input, 'message'), '', settings.maximumMessageLength),
        duration = normalizeDuration(rawget(input, 'duration')),
    }
end

local function parse(input)
    if type(input) == 'string' then return parseString(input) end
    if type(input) == 'table' then return parseTable(input) end
    return nil
end

local pending = {}
local nuiReady = false

local function send(data)
    SendNUIMessage({ action = 'notify', data = data })
end

local function enqueue(data)
    if #pending >= settings.queueLimit then
        table.remove(pending, 1)
    end
    pending[#pending + 1] = data
end

local function flushPending()
    local queued = pending
    pending = {}
    for index = 1, #queued do
        send(queued[index])
    end
end

local function show(input)
    local data = parse(input)
    if not data then return false end

    if nuiReady then
        send(data)
    else
        enqueue(data)
    end

    return true
end

RegisterNUICallback('ready', function(_, callback)
    nuiReady = false
    callback({ ok = true, config = nuiConfig })
end)

RegisterNUICallback('initialized', function(_, callback)
    nuiReady = true
    callback({ ok = true })
    flushPending()
end)

exports('Notify', show)

RegisterNetEvent('pulse_notify:send', function(input)
    show(input)
end)
