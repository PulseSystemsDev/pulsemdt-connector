fx_version 'cerulean'
game 'gta5'

name 'pulse_notify'
description 'PulseMDT - Notification UI'
version '0.1.0'
author 'PulseMDT'
url 'https://pulsemdt.com'

client_scripts {
    'config.lua',
    'client/main.lua',
}

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
}
