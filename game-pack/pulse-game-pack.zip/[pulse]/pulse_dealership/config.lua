-- PulseMDT :: pulse_dealership (Vehicle dealership)
--
-- Showcase rooms, a filterable catalog, walk-around previewing, and time and
-- distance limited test drives, plus cash or financed purchases with
-- optional trade-ins. Vehicles bought here register in the CAD the same way
-- the framework bridge registers owned vehicles, so pulse_impound, ANPR, and
-- NCIC lookups all see them immediately. Reaches the CAD through the main
-- `pulsemdt` resource, so no API key here.
--
-- Trading in or storing a purchased vehicle uses pulse_garage's vehicle
-- ownership data; install pulse_garage too if you want players to be able to
-- store what they buy here (not required for buying itself).
--
-- Showroom locations are dashboard-editable from the Scripts page
-- ("Showrooms"), the same mechanism pulse_jobs, pulse_dutystations,
-- pulse_jailing, pulse_needs, and pulse_garage use, or replace the defaults
-- below directly.
--
-- Financing only progresses while a character is connected and this
-- resource is running; FiveM has no background scheduler, so a missed
-- payment while offline is only noticed the next time that character plays.

Config = {}

Config.StationRadius = 3.0
Config.PreviewDistance = 6.0
Config.TestDriveDistance = 10.0

-- Default showrooms (replaced by dashboard stations when any exist).
Config.Stations = {
    { label = 'Legion Square Motors', x = 231.6, y = -800.9, z = 30.7, heading = 160.0 },
}

Config.Blip = { sprite = 225, color = 2, label = 'Dealership' }

-- Vehicle catalog. `financeable` controls whether the finance option shows
-- for that vehicle; `category` drives the catalog menu's filter tabs; `class`
-- controls which garage (land/air/sea) it delivers to and stores in.
Config.Catalog = {
    { key = 'blista',      label = 'Blista',                 model = 'blista',             category = 'economy', class = 'land', price = 15000,  financeable = true },
    { key = 'tailgater',   label = 'Tailgater',               model = 'tailgater',          category = 'economy', class = 'land', price = 28000,  financeable = true },
    { key = 'sultanrs',    label = 'Sultan RS',               model = 'sultanrs',           category = 'sport',   class = 'land', price = 65000,  financeable = true },
    { key = 'cometrc',     label = 'Comet Retro Custom',      model = 'cometretrocustom',   category = 'sport',   class = 'land', price = 85000,  financeable = true },
    { key = 'schafter5',   label = 'Schafter V12',            model = 'schafter5',          category = 'luxury',  class = 'land', price = 120000, financeable = true },
    { key = 'cognoscenti', label = 'Cognoscenti',             model = 'cognoscenti2',       category = 'luxury',  class = 'land', price = 150000, financeable = false },
    { key = 'maverick',    label = 'Maverick',                model = 'maverick',           category = 'air',     class = 'air',  price = 180000, financeable = true },
    { key = 'dinghy',      label = 'Dinghy',                  model = 'dinghy',             category = 'sea',     class = 'sea',  price = 12000,  financeable = true },
    { key = 'toro',        label = 'Toro',                    model = 'toro',               category = 'sea',     class = 'sea',  price = 95000,  financeable = true },
}

-- Test drives: how long before it's returned automatically, and how far the
-- player may stray from the showroom before it's returned early.
Config.TestDriveSeconds = 90
Config.TestDriveMaxDistance = 300.0

-- Financing.
Config.InstallmentOptions = { 4, 8, 12 }
Config.MinDownPaymentPercent = 10
Config.MaxMissedPayments = 3

-- How often (minutes) an active finance plan attempts its next installment
-- for a currently-connected character.
Config.FinanceCheckIntervalMinutes = 5

-- Trade-ins: percentage of the current catalog price if the traded vehicle's
-- model matches a catalog entry, otherwise a flat fallback credit.
Config.TradeInPercent = 40
Config.TradeInFallbackValue = 500
