# pulse_dealership

`pulse_dealership` adds configurable showrooms, a vehicle catalog, previews, timed test drives, purchases, financing, repossession, and trade-ins backed by PulseMDT.

## Requirements

- `pulsemdt` with character, garage, and economy features available
- `pulse_core` recommended
- `pulse_notify` optional

## Installation

Keep the folder name `pulse_dealership`, configure locations and inventory in `config.lua`, then start it after `pulsemdt`.

## Configuration

`Config.Stations` and `Config.Catalog` define dealership locations and vehicles. Other settings control preview placement, test-drive time and distance, installment counts, minimum down payment, repossession threshold, finance checks, and trade-in value.

The PulseMDT Scripts page can override supported dealership settings and station locations without editing the resource.
