local CATALOG_BY_KEY = {}
for _, item in ipairs(Config.Catalog) do CATALOG_BY_KEY[item.key] = item end

local charCache = {}

local RCFG = { enabled = true, settings = {} }

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_dealership') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function setting(key, fallback)
    local v = RCFG.settings and RCFG.settings[key]
    if v == nil then return fallback end
    return v
end
local function num(key, fallback) return tonumber(setting(key, fallback)) or fallback end
local function moduleEnabled() return RCFG.enabled ~= false end

local function effectiveStations()
    local raw = RCFG.settings and RCFG.settings.stationsJson
    if type(raw) == 'string' and raw ~= '' then
        local ok, parsed = pcall(json.decode, raw)
        if ok and type(parsed) == 'table' then
            local out = {}
            for _, s in ipairs(parsed) do
                if s.job == 'dealership' and tonumber(s.x) then
                    out[#out + 1] = {
                        label = tostring(s.label or 'Dealership'),
                        x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                        heading = tonumber(s.heading) or 0.0,
                    }
                end
            end
            if #out > 0 then return out end
        end
    end
    return Config.Stations
end

local function broadcastStations(target)
    TriggerClientEvent('pulse_dealership:stations', target or -1, {
        stations = effectiveStations(), blip = Config.Blip, radius = Config.StationRadius,
        catalog = Config.Catalog, previewDistance = Config.PreviewDistance, testDriveDistance = Config.TestDriveDistance,
        testDriveSeconds = Config.TestDriveSeconds, testDriveMaxDistance = Config.TestDriveMaxDistance,
        installmentOptions = Config.InstallmentOptions,
        minDownPaymentPercent = num('minDownPaymentPercent', Config.MinDownPaymentPercent),
        tradeInPercent = num('tradeInPercent', Config.TradeInPercent),
        tradeInFallbackValue = num('tradeInFallbackValue', Config.TradeInFallbackValue),
    })
end

RegisterNetEvent('pulse_dealership:requestStations', function()
    broadcastStations(source)
end)

local function notify(src, msg)
    TriggerClientEvent('pulse_dealership:notify', src, msg)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local PLATE_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
local function generatePlate()
    local out = {}
    for i = 1, 8 do
        local idx = math.random(1, #PLATE_CHARS)
        out[i] = PLATE_CHARS:sub(idx, idx)
    end
    return table.concat(out)
end

RegisterNetEvent('pulse_dealership:ready', function()
    local src = source
    getCharId(src, function(charId)
        charCache[src] = charId
    end)
end)

RegisterNetEvent('pulse_dealership:getMyVehicles', function()
    local src = source
    getCharId(src, function(charId)
        if not charId then TriggerClientEvent('pulse_dealership:myVehicles', src, {}) return end
        exports.pulsemdt:ApiRequest('GET', '/garage?charId=' .. charId, nil, function(code, res)
            TriggerClientEvent('pulse_dealership:myVehicles', src, (code == 200 and res and res.vehicles) or {})
        end)
    end)
end)

RegisterNetEvent('pulse_dealership:buy', function(data)
    local src = source
    if not moduleEnabled() then notify(src, '~y~The dealership is closed right now.') return end

    local item = data and CATALOG_BY_KEY[data.catalogKey]
    if not item then notify(src, '~r~Unknown vehicle.') return end

    local financed = data.financed == true and item.financeable == true
    local installments = 0
    local downPayment = item.price
    if financed then
        installments = tonumber(data.installments) or 0
        local validInstallments = false
        for _, opt in ipairs(Config.InstallmentOptions) do if opt == installments then validInstallments = true break end end
        if not validInstallments then notify(src, '~r~Invalid installment plan.') return end

        downPayment = tonumber(data.downPayment) or 0
        local minDown = math.floor(item.price * (num('minDownPaymentPercent', Config.MinDownPaymentPercent) / 100))
        if downPayment < minDown then
            notify(src, ('~r~Down payment must be at least $%d.'):format(minDown))
            return
        end
        if downPayment > item.price then downPayment = item.price end
    end

    getCharId(src, function(charId)
        if not charId then notify(src, '~r~No active character.') return end

        local function completePurchase()
            local plate = generatePlate()
            exports.pulsemdt:ApiRequest('POST', '/dealership', {
                action = 'purchase', charId = charId, plate = plate, model = item.model, class = item.class,
                price = item.price, financed = financed, downPayment = downPayment, installments = installments,
            }, function(code, res)
                if code == 201 and res and res.ok then
                    notify(src, ('~g~Dealership~s~ %s purchased.'):format(item.label))
                    TriggerClientEvent('pulse_dealership:delivered', src, { plate = plate, model = item.model })
                elseif code == 402 then
                    notify(src, '~r~Not enough money for that.')
                else
                    notify(src, '~r~The dealership could not process that sale.')
                end
            end)
        end

        local tradeInVehicleId = tonumber(data.tradeInVehicleId)
        if tradeInVehicleId then
            local tradeModel = tostring(data.tradeInModel or '')
            local matchedCatalog = nil
            for _, c in ipairs(Config.Catalog) do if c.model == tradeModel then matchedCatalog = c break end end
            local creditAmount = matchedCatalog
                and math.floor(matchedCatalog.price * (num('tradeInPercent', Config.TradeInPercent) / 100))
                or num('tradeInFallbackValue', Config.TradeInFallbackValue)

            exports.pulsemdt:ApiRequest('POST', '/dealership', {
                action = 'tradeIn', charId = charId, vehicleId = tradeInVehicleId, creditAmount = creditAmount,
            }, function(code, res)
                if code == 200 and res and res.ok then
                    notify(src, ('~g~Dealership~s~ Trade-in credited: $%d.'):format(res.credited or creditAmount))
                    completePurchase()
                else
                    notify(src, '~r~That trade-in could not be processed (it may still be financed).')
                end
            end)
        else
            completePurchase()
        end
    end)
end)

CreateThread(function()
    while true do
        Wait(math.max(1, num('financeCheckIntervalMinutes', Config.FinanceCheckIntervalMinutes)) * 60000)
        if moduleEnabled() then
            for src, charId in pairs(charCache) do
                if GetPlayerName(src) and charId then
                    exports.pulsemdt:ApiRequest('GET', '/dealership?charId=' .. charId, nil, function(code, res)
                        if code ~= 200 or not res or not res.plans then return end
                        for _, plan in ipairs(res.plans) do
                            exports.pulsemdt:ApiRequest('POST', '/dealership', {
                                action = 'chargeInstallment', financeId = plan.id, maxMissedPayments = Config.MaxMissedPayments,
                            }, function(ccode, cres)
                                if ccode ~= 200 or not cres then return end
                                if cres.paidOff then
                                    notify(src, ('~g~Dealership~s~ %s is paid off.'):format(plan.model))
                                elseif cres.charged then
                                    notify(src, ('~y~Dealership~s~ Installment charged for %s.'):format(plan.model))
                                elseif cres.repossessed then
                                    notify(src, ('~r~Dealership~s~ %s was repossessed after missed payments.'):format(plan.model))
                                    TriggerClientEvent('pulse_dealership:repossessed', src, { plate = cres.plate })
                                else
                                    notify(src, ('~y~Dealership~s~ Missed a payment on %s.'):format(plan.model))
                                end
                            end)
                        end
                    end)
                else
                    charCache[src] = nil
                end
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    charCache[source] = nil
end)
