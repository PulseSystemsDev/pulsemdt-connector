const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'pulse_dealership';

const catalogPanel = document.getElementById('catalog');
const buyPanel = document.getElementById('buyPanel');
const testDriveHud = document.getElementById('testDriveHud');
const tdTime = document.getElementById('tdTime');

const tabsEl = document.getElementById('tabs');
const itemsEl = document.getElementById('items');
const catalogClose = document.getElementById('catalogClose');

const buyTitle = document.getElementById('buyTitle');
const buyPrice = document.getElementById('buyPrice');
const cashBtn = document.getElementById('cashBtn');
const financeBtn = document.getElementById('financeBtn');
const financeFields = document.getElementById('financeFields');
const downPaymentInput = document.getElementById('downPayment');
const installmentOptionsEl = document.getElementById('installmentOptions');
const tradeInSelect = document.getElementById('tradeInSelect');
const confirmBuyBtn = document.getElementById('confirmBuyBtn');
const buyClose = document.getElementById('buyClose');

let catalog = [];
let installmentChoices = [];
let minDownPaymentPercent = 10;
let tradeInPercent = 40;
let tradeInFallbackValue = 500;
let tradeInVehicles = [];
let currentTab = 'all';
let buyItem = null;
let financed = false;
let selectedInstallments = 0;

function post(name, body) {
  return fetch(`https://${resource}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  });
}

function money(n) {
  return `$${Math.round(n).toLocaleString()}`;
}

function renderTabs() {
  const categories = ['all', ...new Set(catalog.map((c) => c.category))];
  tabsEl.innerHTML = '';
  categories.forEach((cat) => {
    const btn = document.createElement('button');
    btn.className = `tab${cat === currentTab ? ' active' : ''}`;
    btn.textContent = cat;
    btn.addEventListener('click', () => { currentTab = cat; renderTabs(); renderItems(); });
    tabsEl.appendChild(btn);
  });
}

function renderItems() {
  const list = currentTab === 'all' ? catalog : catalog.filter((c) => c.category === currentTab);
  itemsEl.innerHTML = '';
  list.forEach((item) => {
    const row = document.createElement('div');
    row.className = 'item';
    row.innerHTML = `
      <div class="top">
        <span class="name">${item.label}</span>
        <span class="price">${money(item.price)}</span>
      </div>
      <div class="actions">
        <button type="button" data-act="preview">Preview</button>
        <button type="button" data-act="test">Test Drive</button>
        <button type="button" data-act="buy" class="primary">Buy</button>
      </div>
    `;
    row.querySelector('[data-act="preview"]').addEventListener('click', () => post('previewItem', { catalogKey: item.key }));
    row.querySelector('[data-act="test"]').addEventListener('click', () => {
      post('testDrive', { catalogKey: item.key });
      post('closeDealership');
      catalogPanel.classList.add('hidden');
    });
    row.querySelector('[data-act="buy"]').addEventListener('click', () => openBuyPanel(item));
    itemsEl.appendChild(row);
  });
}

function renderInstallmentOptions() {
  installmentOptionsEl.innerHTML = '';
  installmentChoices.forEach((n) => {
    const btn = document.createElement('button');
    btn.className = `toggle-btn${n === selectedInstallments ? ' active' : ''}`;
    btn.textContent = `${n}x`;
    btn.addEventListener('click', () => {
      selectedInstallments = n;
      renderInstallmentOptions();
    });
    installmentOptionsEl.appendChild(btn);
  });
}

function renderTradeInOptions() {
  tradeInSelect.innerHTML = '<option value="">None</option>';
  tradeInVehicles.forEach((v) => {
    const opt = document.createElement('option');
    opt.value = String(v.id);
    const isCatalogModel = catalog.some((c) => c.model === v.model);
    const estimate = isCatalogModel
      ? Math.floor((catalog.find((c) => c.model === v.model).price) * (tradeInPercent / 100))
      : tradeInFallbackValue;
    opt.textContent = `${v.model} (${v.plate}) - est. ${money(estimate)}`;
    tradeInSelect.appendChild(opt);
  });
}

function openBuyPanel(item) {
  buyItem = item;
  financed = false;
  selectedInstallments = installmentChoices[0] || 0;
  buyTitle.textContent = item.label;
  buyPrice.textContent = money(item.price);
  cashBtn.classList.add('active');
  financeBtn.classList.remove('active');
  financeBtn.classList.toggle('hidden', !item.financeable);
  financeFields.classList.add('hidden');
  downPaymentInput.value = Math.floor(item.price * (minDownPaymentPercent / 100));
  renderInstallmentOptions();
  post('requestTradeInOptions');
  catalogPanel.classList.add('hidden');
  buyPanel.classList.remove('hidden');
}

cashBtn.addEventListener('click', () => {
  financed = false;
  cashBtn.classList.add('active');
  financeBtn.classList.remove('active');
  financeFields.classList.add('hidden');
});

financeBtn.addEventListener('click', () => {
  if (financeBtn.classList.contains('hidden')) return;
  financed = true;
  financeBtn.classList.add('active');
  cashBtn.classList.remove('active');
  financeFields.classList.remove('hidden');
});

confirmBuyBtn.addEventListener('click', () => {
  if (!buyItem) return;
  const tradeInVehicleId = tradeInSelect.value ? Number(tradeInSelect.value) : null;
  const tradeInModel = tradeInVehicleId
    ? (tradeInVehicles.find((v) => v.id === tradeInVehicleId) || {}).model
    : null;
  post('confirmBuy', {
    catalogKey: buyItem.key,
    financed,
    downPayment: financed ? Number(downPaymentInput.value) || 0 : buyItem.price,
    installments: financed ? selectedInstallments : 0,
    tradeInVehicleId,
    tradeInModel,
  });
  post('closeDealership');
  buyPanel.classList.add('hidden');
});

catalogClose.addEventListener('click', () => { post('closeDealership'); catalogPanel.classList.add('hidden'); });
buyClose.addEventListener('click', () => { catalogPanel.classList.remove('hidden'); buyPanel.classList.add('hidden'); });

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  if (!buyPanel.classList.contains('hidden')) { buyPanel.classList.add('hidden'); post('closeDealership'); return; }
  if (!catalogPanel.classList.contains('hidden')) { catalogPanel.classList.add('hidden'); post('closeDealership'); }
});

window.addEventListener('message', (e) => {
  const data = e.data;
  if (data.action === 'catalog') {
    catalog = data.catalog || [];
    installmentChoices = data.installmentOptions || [];
    minDownPaymentPercent = data.minDownPaymentPercent ?? 10;
    tradeInPercent = data.tradeInPercent ?? 40;
    tradeInFallbackValue = data.tradeInFallbackValue ?? 500;
    currentTab = 'all';
    renderTabs();
    renderItems();
    catalogPanel.classList.remove('hidden');
  } else if (data.action === 'tradeInOptions') {
    tradeInVehicles = data.vehicles || [];
    renderTradeInOptions();
  } else if (data.action === 'testDriveStart') {
    testDriveHud.classList.remove('hidden');
    const m = Math.floor(data.seconds / 60), s = data.seconds % 60;
    tdTime.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  } else if (data.action === 'testDriveTick') {
    const m = Math.floor(data.remaining / 60), s = data.remaining % 60;
    tdTime.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  } else if (data.action === 'testDriveEnd') {
    testDriveHud.classList.add('hidden');
  }
});
