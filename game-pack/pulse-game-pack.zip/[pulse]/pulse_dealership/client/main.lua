local stationData = {
    stations = {}, blip = {}, radius = 3.0, catalog = {},
    previewDistance = 6.0, testDriveDistance = 10.0, testDriveSeconds = 90, testDriveMaxDistance = 300.0,
    installmentOptions = {}, minDownPaymentPercent = 10, tradeInPercent = 40, tradeInFallbackValue = 500,
}
local catalogByKey = {}
local stationBlips = {}
local activeStation = nil
local menuOpen = false
local previewVeh = nil
local testDriveVeh = nil
local testDriveActive = false

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_dealership:notify', function(msg)
    if msg then notify(msg) end
end)

local function rebuildStationBlips()
    for _, b in ipairs(stationBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    stationBlips = {}
    local meta = stationData.blip or {}
    for _, st in ipairs(stationData.stations or {}) do
        local b = AddBlipForCoord(st.x, st.y, st.z)
        SetBlipSprite(b, meta.sprite or 225)
        SetBlipColour(b, meta.color or 2)
        SetBlipScale(b, 0.8)
        SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName(meta.label or 'Dealership')
        EndTextCommandSetBlipName(b)
        stationBlips[#stationBlips + 1] = b
    end
end

RegisterNetEvent('pulse_dealership:stations', function(payload)
    if type(payload) ~= 'table' then return end
    stationData = payload
    catalogByKey = {}
    for _, item in ipairs(stationData.catalog or {}) do catalogByKey[item.key] = item end
    rebuildStationBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_dealership:requestStations')
    TriggerServerEvent('pulse_dealership:ready')
end)

local function projectFrom(station, distance)
    local rad = math.rad(station.heading or 0.0)
    return {
        x = station.x - math.sin(rad) * distance,
        y = station.y + math.cos(rad) * distance,
        z = station.z,
        heading = ((station.heading or 0.0) + 180.0) % 360.0,
    }
end

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local deadline = GetGameTimer() + 10000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > deadline then return nil end
        Wait(25)
    end
    return hash
end

local function clearPreview()
    if previewVeh and DoesEntityExist(previewVeh) then DeleteVehicle(previewVeh) end
    previewVeh = nil
end

local function spawnPreview(model)
    if not activeStation then return end
    clearPreview()
    local hash = loadModel(model)
    if not hash then notify('~r~Dealership~s~ That model failed to load.') return end
    local pos = projectFrom(activeStation, stationData.previewDistance or 6.0)
    previewVeh = CreateVehicle(hash, pos.x, pos.y, pos.z, pos.heading, false, false)
    SetModelAsNoLongerNeeded(hash)
    SetEntityInvincible(previewVeh, true)
    FreezeEntityPosition(previewVeh, true)
    SetVehicleDoorsLocked(previewVeh, 2)
end

local function endTestDrive(reason)
    if not testDriveActive then return end
    testDriveActive = false
    if testDriveVeh and DoesEntityExist(testDriveVeh) then DeleteVehicle(testDriveVeh) end
    testDriveVeh = nil
    SendNUIMessage({ action = 'testDriveEnd' })
    if reason then notify(('~y~Dealership~s~ Test drive over: %s'):format(reason)) end
end

local function startTestDrive(model)
    if not activeStation then return end
    if testDriveActive then notify('~y~You are already on a test drive.') return end
    local hash = loadModel(model)
    if not hash then notify('~r~Dealership~s~ That model failed to load.') return end
    local pos = projectFrom(activeStation, stationData.testDriveDistance or 10.0)
    testDriveVeh = CreateVehicle(hash, pos.x, pos.y, pos.z, pos.heading, true, false)
    SetModelAsNoLongerNeeded(hash)
    TaskWarpPedIntoVehicle(PlayerPedId(), testDriveVeh, -1)
    testDriveActive = true
    local origin = vector3(activeStation.x, activeStation.y, activeStation.z)
    local seconds = stationData.testDriveSeconds or 90
    local maxDist = stationData.testDriveMaxDistance or 300.0

    CreateThread(function()
        local remaining = seconds
        while testDriveActive and remaining > 0 do
            Wait(1000)
            remaining = remaining - 1
            SendNUIMessage({ action = 'testDriveTick', remaining = remaining })
            if testDriveVeh and DoesEntityExist(testDriveVeh) then
                local dist = #(GetEntityCoords(testDriveVeh) - origin)
                if dist > maxDist then
                    endTestDrive('too far from the showroom')
                    return
                end
            end
        end
        if testDriveActive then endTestDrive('time is up') end
    end)
    SendNUIMessage({ action = 'testDriveStart', seconds = seconds })
end

RegisterNetEvent('pulse_dealership:delivered', function(data)
    if not activeStation then return end
    local hash = loadModel(data.model)
    if not hash then return end
    local pos = projectFrom(activeStation, stationData.previewDistance or 6.0)
    clearPreview()
    local veh = CreateVehicle(hash, pos.x, pos.y, pos.z, pos.heading, true, false)
    SetModelAsNoLongerNeeded(hash)
    SetVehicleNumberPlateText(veh, data.plate)
    SetVehicleOnGroundProperly(veh)
end)

RegisterNetEvent('pulse_dealership:repossessed', function(data)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 then
        local plate = (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', '')
        if plate == data.plate then DeleteVehicle(veh) end
    end
end)

RegisterNetEvent('pulse_dealership:myVehicles', function(vehicles)
    SendNUIMessage({ action = 'tradeInOptions', vehicles = vehicles or {} })
end)

RegisterNUICallback('previewItem', function(data, cb)
    local item = catalogByKey[data.catalogKey]
    if item then spawnPreview(item.model) end
    cb({})
end)

RegisterNUICallback('testDrive', function(data, cb)
    local item = catalogByKey[data.catalogKey]
    if item then startTestDrive(item.model) end
    cb({})
end)

RegisterNUICallback('requestTradeInOptions', function(_, cb)
    TriggerServerEvent('pulse_dealership:getMyVehicles')
    cb({})
end)

RegisterNUICallback('confirmBuy', function(data, cb)
    TriggerServerEvent('pulse_dealership:buy', data)
    cb({})
end)

RegisterNUICallback('closeDealership', function(_, cb)
    menuOpen = false
    clearPreview()
    SetNuiFocus(false, false)
    cb({})
end)

CreateThread(function()
    while true do
        local sleep = 900
        if not menuOpen then
            local pos = GetEntityCoords(PlayerPedId())
            for _, st in ipairs(stationData.stations or {}) do
                local dist = #(pos - vector3(st.x, st.y, st.z))
                if dist < 40.0 then
                    sleep = 0
                    DrawMarker(2, st.x, st.y, st.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                        0.5, 0.5, 0.5, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                    if dist <= (stationData.radius or 3.0) then
                        BeginTextCommandDisplayHelp('STRING')
                        AddTextComponentSubstringPlayerName('Press ~INPUT_CONTEXT~ : Dealership')
                        EndTextCommandDisplayHelp(0, false, true, -1)
                        if IsControlJustReleased(0, 38) then
                            activeStation = st
                            menuOpen = true
                            SetNuiFocus(true, true)
                            SendNUIMessage({
                                action = 'catalog', catalog = stationData.catalog,
                                installmentOptions = stationData.installmentOptions,
                                minDownPaymentPercent = stationData.minDownPaymentPercent,
                                tradeInPercent = stationData.tradeInPercent,
                                tradeInFallbackValue = stationData.tradeInFallbackValue,
                            })
                            Wait(400)
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
