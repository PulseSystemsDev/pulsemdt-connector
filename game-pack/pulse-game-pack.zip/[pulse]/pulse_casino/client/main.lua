local casinoOpen = false
local stationData = { groups = {}, stations = {}, radius = 2.5 }
local groupByKey = {}
local stationBlips = {}

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function rebuildStationBlips()
    for _, b in ipairs(stationBlips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    stationBlips = {}
    for key, list in pairs(stationData.stations or {}) do
        local group = groupByKey[key]
        for _, st in ipairs(list) do
            local b = AddBlipForCoord(st.x, st.y, st.z)
            SetBlipSprite(b, 679)
            SetBlipColour(b, 5)
            SetBlipScale(b, 0.8)
            SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(group and group.label or key)
            EndTextCommandSetBlipName(b)
            stationBlips[#stationBlips + 1] = b
        end
    end
end

RegisterNetEvent('pulse_casino:stations', function(payload)
    if type(payload) ~= 'table' then return end
    stationData = payload
    groupByKey = {}
    for _, g in ipairs(stationData.groups or {}) do groupByKey[g.key] = g end
    rebuildStationBlips()
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_casino:requestStations')
end)

RegisterNetEvent('pulse_casino:show', function(data)
    casinoOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'show', data = data or {} })
end)

RegisterNetEvent('pulse_casino:result', function(res)
    SendNUIMessage({ action = 'result', data = res or {} })
end)

RegisterNetEvent('pulse_casino:denied', function(msg)
    notify('~y~Casino~s~ ' .. (msg or 'Unavailable.'))
end)

RegisterNUICallback('slots', function(data, cb)
    TriggerServerEvent('pulse_casino:slots', data or {})
    cb({})
end)

RegisterNUICallback('roulette', function(data, cb)
    TriggerServerEvent('pulse_casino:roulette', data or {})
    cb({})
end)

RegisterNUICallback('blackjackStart', function(data, cb)
    TriggerServerEvent('pulse_casino:blackjackStart', data or {})
    cb({})
end)

RegisterNUICallback('blackjackHit', function(_, cb)
    TriggerServerEvent('pulse_casino:blackjackHit')
    cb({})
end)

RegisterNUICallback('blackjackStand', function(_, cb)
    TriggerServerEvent('pulse_casino:blackjackStand')
    cb({})
end)

RegisterNUICallback('close', function(_, cb)
    casinoOpen = false
    SetNuiFocus(false, false)
    cb({})
end)

CreateThread(function()
    while true do
        local sleep = 900
        if not casinoOpen then
            local pos = GetEntityCoords(PlayerPedId())
            for key, list in pairs(stationData.stations or {}) do
                local group = groupByKey[key]
                for _, st in ipairs(list) do
                    local dist = #(pos - vector3(st.x, st.y, st.z))
                    if dist < 30.0 then
                        sleep = 0
                        DrawMarker(2, st.x, st.y, st.z + 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                            0.5, 0.5, 0.5, 47, 155, 214, 180, true, true, 2, false, nil, nil, false)
                        if dist <= (stationData.radius or 2.5) and group then
                            BeginTextCommandDisplayHelp('STRING')
                            AddTextComponentSubstringPlayerName(('Press ~INPUT_CONTEXT~ : %s'):format(group.label or key))
                            EndTextCommandDisplayHelp(0, false, true, -1)
                            if IsControlJustReleased(0, 38) then
                                TriggerServerEvent('pulse_casino:open', { group = key })
                                Wait(400)
                            end
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
