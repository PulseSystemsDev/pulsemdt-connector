local GROUPS = {}
for _, g in ipairs(Config.Groups) do GROUPS[#GROUPS + 1] = g.key end

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_casino') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function limits()
    local minBet = RCFG.settings and tonumber(RCFG.settings.minBet) or Config.MinBet
    local maxBet = RCFG.settings and tonumber(RCFG.settings.maxBet) or Config.MaxBet
    return math.max(1, minBet), math.max(minBet, maxBet)
end

local function effectiveStations()
    local byGroup = {}
    for _, key in ipairs(GROUPS) do byGroup[key] = {} end

    local raw = RCFG.settings and RCFG.settings.stationsJson
    local source = nil
    if type(raw) == 'string' and raw ~= '' then
        local ok, parsed = pcall(json.decode, raw)
        if ok and type(parsed) == 'table' then source = parsed end
    end
    if type(source) == 'table' then
        for _, s in ipairs(source) do
            if byGroup[s.job] and tonumber(s.x) then
                byGroup[s.job][#byGroup[s.job] + 1] = {
                    label = tostring(s.label or 'Table'),
                    x = tonumber(s.x), y = tonumber(s.y), z = tonumber(s.z),
                    heading = tonumber(s.heading) or 0.0,
                }
            end
        end
    end
    for _, key in ipairs(GROUPS) do
        if #byGroup[key] == 0 then
            for _, s in ipairs(Config.Stations[key] or {}) do
                byGroup[key][#byGroup[key] + 1] = s
            end
        end
    end
    return byGroup
end

local function broadcastStations(target)
    local groups = {}
    for _, g in ipairs(Config.Groups) do groups[#groups + 1] = { key = g.key, label = g.label } end
    TriggerClientEvent('pulse_casino:stations', target or -1, {
        groups = groups, stations = effectiveStations(), radius = Config.Radius,
    })
end

RegisterNetEvent('pulse_casino:requestStations', function()
    broadcastStations(source)
end)

local function nearTable(src, group)
    local ped = GetPlayerPed(src)
    if ped == 0 then return false end
    local pos = GetEntityCoords(ped)
    for _, st in ipairs(effectiveStations()[group] or {}) do
        if #(pos - vector3(st.x, st.y, st.z)) <= Config.Radius + 4.0 then return true end
    end
    return false
end

local function sendResult(src, payload)
    TriggerClientEvent('pulse_casino:result', src, payload)
end

local function getDiscordId(src)
    for _, ident in ipairs(GetPlayerIdentifiers(src)) do
        if ident:sub(1, 8) == 'discord:' then return ident:sub(9) end
    end
    return nil
end

local function getCharId(src, cb)
    local ok, id = pcall(function() return exports.pulse_core:GetCharacterId(src) end)
    if ok and id then cb(id) return end
    local discordId = getDiscordId(src)
    if not discordId then cb(nil) return end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        cb(code == 200 and res and res.activeCharId or nil)
    end)
end

local function validBet(src, group, bet)
    if not RCFG.enabled then
        sendResult(src, { error = 'The casino is closed on this server.' })
        return nil
    end
    if not nearTable(src, group) then return nil end
    bet = math.floor(tonumber(bet) or 0)
    local minBet, maxBet = limits()
    if bet < minBet or bet > maxBet then
        sendResult(src, { error = ('Bets are $%d to $%d.'):format(minBet, maxBet) })
        return nil
    end
    return bet
end

-- Charges the bet; on success `play` must return (winnings, payload).
local function wager(src, charId, bet, game, play)
    exports.pulsemdt:ApiRequest('POST', '/money', {
        charId = charId, account = 'bank', amount = -bet, reason = 'Casino bet',
    }, function(code, res)
        if code == 402 then
            sendResult(src, { error = 'Insufficient bank balance for that bet.' })
            return
        elseif code == 403 then
            sendResult(src, { error = 'The economy is disabled on this server.' })
            return
        elseif code ~= 200 or not res or not res.ok then
            sendResult(src, { error = 'The table is not taking bets right now.' })
            return
        end

        local winnings, payload = play()
        payload.game = game
        payload.bet = bet
        payload.win = winnings
        if winnings > 0 then
            exports.pulsemdt:ApiRequest('POST', '/money', {
                charId = charId, account = 'bank', amount = winnings, reason = 'Casino win',
            }, function() sendResult(src, payload) end)
        else
            sendResult(src, payload)
        end
    end)
end

RegisterNetEvent('pulse_casino:open', function(data)
    local src = source
    local group = data and data.group
    if not RCFG.enabled then
        TriggerClientEvent('pulse_casino:denied', src, 'The casino is closed on this server.')
        return
    end
    if not group or not nearTable(src, group) then return end
    local minBet, maxBet = limits()
    getCharId(src, function(charId)
        if not charId then
            TriggerClientEvent('pulse_casino:denied', src, 'The casino is unavailable right now.')
            return
        end
        exports.pulsemdt:ApiRequest('GET', '/money?charId=' .. charId, nil, function(code, res)
            TriggerClientEvent('pulse_casino:show', src, {
                bank = (code == 200 and res and res.bank) or nil,
                minBet = minBet, maxBet = maxBet, group = group,
            })
        end)
    end)
end)

RegisterNetEvent('pulse_casino:slots', function(data)
    local src = source
    local bet = validBet(src, 'slots', data and data.bet)
    if not bet then return end

    getCharId(src, function(charId)
        if not charId then sendResult(src, { error = 'Could not resolve your character.' }) return end
        wager(src, charId, bet, 'slots', function()
            local pool = {}
            for _, s in ipairs(Config.Slots.symbols) do
                for _ = 1, s.weight do pool[#pool + 1] = s end
            end
            local reels = {}
            for i = 1, 3 do reels[i] = pool[math.random(#pool)] end

            local winnings = 0
            if reels[1].id == reels[2].id and reels[2].id == reels[3].id then
                winnings = math.floor(bet * reels[1].triple)
            elseif reels[1].id == reels[2].id or reels[2].id == reels[3].id or reels[1].id == reels[3].id then
                winnings = math.floor(bet * Config.Slots.pairMultiplier)
            end
            return winnings, { reels = { reels[1].id, reels[2].id, reels[3].id } }
        end)
    end)
end)

RegisterNetEvent('pulse_casino:roulette', function(data)
    local src = source
    local pick = data and data.pick
    if pick ~= 'red' and pick ~= 'black' and pick ~= 'green' then return end
    local bet = validBet(src, 'roulette', data and data.bet)
    if not bet then return end

    getCharId(src, function(charId)
        if not charId then sendResult(src, { error = 'Could not resolve your character.' }) return end
        wager(src, charId, bet, 'roulette', function()
            local r = Config.Roulette
            local roll = math.random(r.red + r.black + r.green)
            local outcome
            if roll <= r.red then outcome = 'red'
            elseif roll <= r.red + r.black then outcome = 'black'
            else outcome = 'green' end

            local winnings = 0
            if outcome == pick then
                winnings = math.floor(bet * r.payout[pick])
            end
            return winnings, { outcome = outcome, pick = pick }
        end)
    end)
end)

-- ── Blackjack ────────────────────────────────────────────────────────────
local SUITS = { 'S', 'H', 'D', 'C' }
local RANKS = { 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K' }

local function freshShoe()
    local shoe = {}
    for _, suit in ipairs(SUITS) do
        for _, rank in ipairs(RANKS) do
            shoe[#shoe + 1] = { rank = rank, suit = suit }
        end
    end
    for i = #shoe, 2, -1 do
        local j = math.random(i)
        shoe[i], shoe[j] = shoe[j], shoe[i]
    end
    return shoe
end

local function drawCard(shoe)
    if #shoe == 0 then return nil end
    return table.remove(shoe)
end

local function handValue(cards)
    local total, aces = 0, 0
    for _, c in ipairs(cards) do
        if c.rank == 'A' then
            aces = aces + 1
            total = total + 11
        elseif c.rank == 'J' or c.rank == 'Q' or c.rank == 'K' then total = total + 10
        else total = total + tonumber(c.rank) end
    end
    while total > 21 and aces > 0 do
        total = total - 10
        aces = aces - 1
    end
    return total
end

local blackjackRounds = {}

local function roundPayload(round, reveal)
    return {
        game = 'blackjack', bet = round.bet,
        playerCards = round.playerCards, playerTotal = handValue(round.playerCards),
        dealerCards = reveal and round.dealerCards or { round.dealerCards[1] },
        dealerTotal = reveal and handValue(round.dealerCards) or nil,
    }
end

RegisterNetEvent('pulse_casino:blackjackStart', function(data)
    local src = source
    if blackjackRounds[src] then return end
    local bet = validBet(src, 'blackjack', data and data.bet)
    if not bet then return end

    getCharId(src, function(charId)
        if not charId then sendResult(src, { error = 'Could not resolve your character.' }) return end
        exports.pulsemdt:ApiRequest('POST', '/money', {
            charId = charId, account = 'bank', amount = -bet, reason = 'Blackjack bet',
        }, function(code, res)
            if code == 402 then
                sendResult(src, { error = 'Insufficient bank balance for that bet.' })
                return
            elseif code == 403 then
                sendResult(src, { error = 'The economy is disabled on this server.' })
                return
            elseif code ~= 200 or not res or not res.ok then
                sendResult(src, { error = 'The table is not taking bets right now.' })
                return
            end

            local shoe = freshShoe()
            local round = { bet = bet, charId = charId, shoe = shoe, playerCards = {}, dealerCards = {}, done = false }
            round.playerCards[1] = drawCard(shoe)
            round.dealerCards[1] = drawCard(shoe)
            round.playerCards[2] = drawCard(shoe)
            round.dealerCards[2] = drawCard(shoe)
            blackjackRounds[src] = round

            if handValue(round.playerCards) == 21 then
                local winnings = math.floor(bet * (1 + Config.Blackjack.blackjackPayout))
                round.done = true
                local payload = roundPayload(round, true)
                payload.win = winnings
                payload.outcome = 'blackjack'
                blackjackRounds[src] = nil
                exports.pulsemdt:ApiRequest('POST', '/money', {
                    charId = charId, account = 'bank', amount = winnings, reason = 'Blackjack win',
                }, function() sendResult(src, payload) end)
                return
            end

            local payload = roundPayload(round, false)
            payload.win = 0
            payload.outcome = 'inprogress'
            sendResult(src, payload)
        end)
    end)
end)

RegisterNetEvent('pulse_casino:blackjackHit', function()
    local src = source
    local round = blackjackRounds[src]
    if not round or round.done then return end

    round.playerCards[#round.playerCards + 1] = drawCard(round.shoe)
    local total = handValue(round.playerCards)
    if total > 21 then
        round.done = true
        blackjackRounds[src] = nil
        local payload = roundPayload(round, true)
        payload.win = 0
        payload.outcome = 'bust'
        sendResult(src, payload)
        return
    end

    local payload = roundPayload(round, false)
    payload.win = 0
    payload.outcome = 'inprogress'
    sendResult(src, payload)
end)

RegisterNetEvent('pulse_casino:blackjackStand', function()
    local src = source
    local round = blackjackRounds[src]
    if not round or round.done then return end
    round.done = true
    blackjackRounds[src] = nil

    while handValue(round.dealerCards) < 17 do
        round.dealerCards[#round.dealerCards + 1] = drawCard(round.shoe)
    end

    local playerTotal, dealerTotal = handValue(round.playerCards), handValue(round.dealerCards)
    local winnings, outcome
    if dealerTotal > 21 or playerTotal > dealerTotal then
        winnings = math.floor(round.bet * (1 + Config.Blackjack.winPayout))
        outcome = 'win'
    elseif playerTotal == dealerTotal then
        winnings = round.bet
        outcome = 'push'
    else
        winnings = 0
        outcome = 'lose'
    end

    local payload = roundPayload(round, true)
    payload.win = winnings
    payload.outcome = outcome
    if winnings > 0 then
        exports.pulsemdt:ApiRequest('POST', '/money', {
            charId = round.charId, account = 'bank', amount = winnings, reason = 'Blackjack payout',
        }, function() sendResult(src, payload) end)
    else
        sendResult(src, payload)
    end
end)

AddEventHandler('playerDropped', function()
    blackjackRounds[source] = nil
end)
