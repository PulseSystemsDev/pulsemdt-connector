-- PulseMDT :: pulse_casino
--
-- Slots, roulette, and blackjack. Every roll and every card is dealt
-- SERVER-side and settles through the CAD economy (Economy feature
-- required), so results cannot be forged and all bets and winnings appear in
-- the character's transaction history. Bet limits can also be changed live
-- from the dashboard's Scripts page.
--
-- Each game has its own table(s) instead of one shared terminal, so a server
-- can spread them around the casino floor. Table locations are
-- dashboard-editable from the Scripts page ("Tables"), the same mechanism
-- pulse_jobs, pulse_dutystations, and every other physical-location script in
-- this suite use, or replace the defaults below directly.

Config = {}

Config.Radius = 2.5

Config.Groups = {
    { key = 'slots',     label = 'Slots' },
    { key = 'roulette',  label = 'Roulette' },
    { key = 'blackjack', label = 'Blackjack' },
}

-- Default tables (replaced per group by dashboard stations when any exist).
-- All near the Diamond Casino by default; spread out slightly so they don't
-- overlap.
Config.Stations = {
    slots = {
        { label = 'Slot Machines', x = 924.9, y = 47.6, z = 81.1, heading = 0.0 },
    },
    roulette = {
        { label = 'Roulette Table', x = 935.2, y = 46.1, z = 81.1, heading = 0.0 },
    },
    blackjack = {
        { label = 'Blackjack Table', x = 930.0, y = 58.4, z = 81.1, heading = 0.0 },
    },
}

Config.MinBet = 10
Config.MaxBet = 1000

-- Slots: symbol weights (chance) and 3-of-a-kind payout multipliers.
-- Two matching symbols pay 1.5x the bet.
Config.Slots = {
    symbols = {
        { id = 'CHE', weight = 5, triple = 4 },
        { id = 'LEM', weight = 4, triple = 6 },
        { id = 'BAR', weight = 3, triple = 10 },
        { id = '7',   weight = 1, triple = 25 },
    },
    pairMultiplier = 1.5,
}

-- Roulette: 15-slot wheel (7 red, 7 black, 1 green).
-- Red/black return 2x the bet; green returns 14x.
Config.Roulette = {
    red = 7, black = 7, green = 1,
    payout = { red = 2, black = 2, green = 14 },
}

-- Blackjack: dealer stands on all 17s. A natural blackjack (21 on the first
-- two cards) pays 3:2; a regular win pays 1:1; a push refunds the bet.
Config.Blackjack = {
    blackjackPayout = 1.5,
    winPayout = 1.0,
}
