const RESOURCE = 'pulse_casino';
const SYMBOLS = ['CHE', 'LEM', 'BAR', '7'];
const GROUP_TITLES = { slots: 'Slots', roulette: 'Roulette', blackjack: 'Blackjack' };
let spinning = false;
let spinTimer = null;
let limits = { min: 10, max: 1000 };
let currentGroup = 'slots';
let blackjackInRound = false;

const panel = document.getElementById('panel');
const title = document.getElementById('title');
const bankEl = document.getElementById('bank');
const limitsEl = document.getElementById('limits');
const betRow = document.getElementById('betRow');
const betEl = document.getElementById('bet');
const msgEl = document.getElementById('msg');
const reels = [document.getElementById('r1'), document.getElementById('r2'), document.getElementById('r3')];
const wheel = document.getElementById('wheel');
const outcomeEl = document.getElementById('outcome');
const spinBtn = document.getElementById('spin');
const panes = { slots: document.getElementById('tab-slots'), roulette: document.getElementById('tab-roulette'), blackjack: document.getElementById('tab-blackjack') };

const bjDealerCards = document.getElementById('bjDealerCards');
const bjPlayerCards = document.getElementById('bjPlayerCards');
const bjDealerTotal = document.getElementById('bjDealerTotal');
const bjPlayerTotal = document.getElementById('bjPlayerTotal');
const bjDeal = document.getElementById('bjDeal');
const bjActions = document.getElementById('bjActions');
const bjHit = document.getElementById('bjHit');
const bjStand = document.getElementById('bjStand');

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function money(n) {
  return '$' + Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function say(text, cls) {
  msgEl.textContent = text || '';
  msgEl.className = 'msg ' + (cls || '');
}

function bet() {
  const v = Math.floor(Number(betEl.value));
  if (!Number.isFinite(v) || v < limits.min || v > limits.max) {
    say(`Bets are $${limits.min} to $${limits.max}.`, 'err');
    return null;
  }
  return v;
}

function showGroup(group) {
  currentGroup = group;
  title.textContent = GROUP_TITLES[group] || 'The Diamond';
  for (const key of Object.keys(panes)) panes[key].classList.toggle('hidden', key !== group);
  betRow.classList.toggle('hidden', group === 'blackjack' && blackjackInRound);
}

function startSpin() {
  spinning = true;
  spinBtn.disabled = true;
  say('');
  reels.forEach((r) => r.classList.add('spinning'));
  reels.forEach((r) => r.classList.remove('win'));
  spinTimer = setInterval(() => {
    for (const r of reels) r.textContent = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
  }, 90);
}

function stopSpin(finalReels, allWin) {
  clearInterval(spinTimer);
  spinning = false;
  spinBtn.disabled = false;
  reels.forEach((r, i) => {
    r.classList.remove('spinning');
    r.textContent = finalReels?.[i] ?? r.textContent;
    r.classList.toggle('win', !!allWin);
  });
}

spinBtn.addEventListener('click', () => {
  if (spinning) return;
  const b = bet();
  if (b === null) return;
  startSpin();
  post('slots', { bet: b });
});

document.querySelectorAll('.pick').forEach((btn) => {
  btn.addEventListener('click', () => {
    const b = bet();
    if (b === null) return;
    say('Spinning...', 'neutral');
    wheel.className = 'wheel';
    outcomeEl.innerHTML = '&nbsp;';
    post('roulette', { bet: b, pick: btn.dataset.pick });
  });
});

function renderCard(card) {
  const el = document.createElement('span');
  const red = card.suit === 'H' || card.suit === 'D';
  el.className = 'bj-card' + (red ? ' red' : '');
  el.textContent = `${card.rank}${card.suit}`;
  return el;
}

function renderHand(container, cards) {
  container.innerHTML = '';
  (cards || []).forEach((c) => container.appendChild(renderCard(c)));
}

bjDeal.addEventListener('click', () => {
  const b = bet();
  if (b === null) return;
  say('');
  post('blackjackStart', { bet: b });
});

bjHit.addEventListener('click', () => post('blackjackHit'));
bjStand.addEventListener('click', () => post('blackjackStand'));

function close() {
  panel.classList.add('hidden');
  clearInterval(spinTimer);
  spinning = false;
  blackjackInRound = false;
  post('close');
}
document.getElementById('x').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (panel.classList.contains('hidden')) return;
  if (e.key === 'Escape') close();
});

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'show') {
    const d = m.data || {};
    if (typeof d.bank === 'number') bankEl.textContent = money(d.bank);
    limits = { min: d.minBet || 10, max: d.maxBet || 1000 };
    limitsEl.textContent = `$${limits.min} to $${limits.max}`;
    betEl.value = '';
    say('');
    blackjackInRound = false;
    bjDeal.classList.remove('hidden');
    bjActions.classList.add('hidden');
    renderHand(bjDealerCards, []);
    renderHand(bjPlayerCards, []);
    bjDealerTotal.textContent = '';
    bjPlayerTotal.textContent = '';
    showGroup(d.group || 'slots');
    panel.classList.remove('hidden');
    setTimeout(() => betEl.focus(), 40);
  } else if (m.action === 'result') {
    const d = m.data || {};
    if (d.error) {
      stopSpin(null, false);
      say(d.error, 'err');
      return;
    }
    if (d.game === 'slots') {
      const allWin = d.reels && d.reels[0] === d.reels[1] && d.reels[1] === d.reels[2];
      setTimeout(() => {
        stopSpin(d.reels, allWin && d.win > 0);
        say(d.win > 0 ? `You won ${money(d.win)}.` : `No win. ${money(d.bet)} lost.`, d.win > 0 ? 'ok' : 'neutral');
      }, 700);
    } else if (d.game === 'roulette') {
      setTimeout(() => {
        wheel.className = 'wheel ' + d.outcome;
        outcomeEl.textContent = d.outcome;
        say(d.win > 0 ? `${d.outcome} hits. You won ${money(d.win)}.` : `${d.outcome}. ${money(d.bet)} lost.`, d.win > 0 ? 'ok' : 'neutral');
      }, 600);
    } else if (d.game === 'blackjack') {
      renderHand(bjPlayerCards, d.playerCards);
      renderHand(bjDealerCards, d.dealerCards);
      bjPlayerTotal.textContent = d.playerTotal != null ? `(${d.playerTotal})` : '';
      bjDealerTotal.textContent = d.dealerTotal != null ? `(${d.dealerTotal})` : '';

      if (d.outcome === 'inprogress') {
        blackjackInRound = true;
        betRow.classList.add('hidden');
        bjDeal.classList.add('hidden');
        bjActions.classList.remove('hidden');
        say('Hit or stand.', 'neutral');
      } else {
        blackjackInRound = false;
        betRow.classList.remove('hidden');
        bjDeal.classList.remove('hidden');
        bjActions.classList.add('hidden');
        const messages = {
          blackjack: `Blackjack! You won ${money(d.win)}.`,
          win: `You won ${money(d.win)}.`,
          push: 'Push. Bet returned.',
          bust: `Bust. ${money(d.bet)} lost.`,
          lose: `Dealer wins. ${money(d.bet)} lost.`,
        };
        say(messages[d.outcome] || '', d.win > 0 ? 'ok' : d.outcome === 'push' ? 'neutral' : 'err');
      }
    }
  }
});
