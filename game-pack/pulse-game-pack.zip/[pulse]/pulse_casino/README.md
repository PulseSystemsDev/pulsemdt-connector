# pulse_casino

`pulse_casino` provides server-authoritative slots, roulette, and blackjack using the PulseMDT economy.

## Requirements

- `pulsemdt` with the economy enabled
- An active PulseMDT character; `pulse_core` is recommended
- `pulse_notify` optional

## Installation

Keep the folder name `pulse_casino`, configure table locations and limits in `config.lua`, and start it after `pulsemdt` and the optional shared resources.

## Configuration

- `Config.Groups` and `Config.Stations` define casino groups and table locations.
- `Config.MinBet` and `Config.MaxBet` set local wager limits.
- `Config.Slots`, `Config.Roulette`, and `Config.Blackjack` control each game.

Effective enablement, wager limits, and stations may be overridden from the PulseMDT Scripts page.
