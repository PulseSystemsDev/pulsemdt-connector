local zoneCooldowns = {}

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_shotspotter') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

local function cooldownSeconds()
    local v = RCFG.settings and tonumber(RCFG.settings.zoneCooldownSeconds)
    if v ~= nil then return v end
    return Config.ZoneCooldown
end

RegisterNetEvent('pulse_shotspotter:shots', function(data)
    local src = source
    if not RCFG.enabled then return end

    local zoneIdx = tonumber(data and data.zone)
    local zone = zoneIdx and Config.Zones[zoneIdx]
    if not zone then return end

    local ped = GetPlayerPed(src)
    local pos = GetEntityCoords(ped)
    if #(pos - vector3(zone.x, zone.y, zone.z)) > zone.radius + 60.0 then return end

    local now = os.time()
    if zoneCooldowns[zoneIdx] and (now - zoneCooldowns[zoneIdx]) < cooldownSeconds() then return end
    zoneCooldowns[zoneIdx] = now

    exports.pulsemdt:ApiWrite('POST', '/cad', {
        call_type   = 'ShotSpotter',
        location    = zone.name,
        description = ('Gunfire detected in %s'):format(zone.name),
        priority    = 2,
        lat         = pos.y,
        lng         = pos.x,
    }, nil)

    local ok, officers = pcall(function()
        return exports.pulsemdt:GetAvailableOfficers()
    end)
    if ok and type(officers) == 'table' then
        for _, officer in ipairs(officers) do
            TriggerClientEvent('pulse_shotspotter:alert', officer, {
                zone = zone.name,
                x = pos.x, y = pos.y, z = pos.z,
            })
        end
    end
end)
