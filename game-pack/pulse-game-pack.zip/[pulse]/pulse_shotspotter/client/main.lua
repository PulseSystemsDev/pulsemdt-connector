local lastReport = 0

local function inZone(pos)
    for i, zone in ipairs(Config.Zones) do
        if #(pos - vector3(zone.x, zone.y, zone.z)) <= zone.radius then
            return i
        end
    end
    return nil
end

CreateThread(function()
    while true do
        Wait(300)
        local ped = PlayerPedId()
        if IsPedShooting(ped) then
            local now = GetGameTimer()
            if now - lastReport > 5000 then
                local pos = GetEntityCoords(ped)
                local zone = inZone(pos)
                if zone then
                    lastReport = now
                    TriggerServerEvent('pulse_shotspotter:shots', { zone = zone })
                end
            end
        end
    end
end)

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_shotspotter:alert', function(hit)
    if not hit then return end
    notify(('~r~SHOTSPOTTER~s~\nGunfire detected in %s'):format(hit.zone or 'a monitored zone'))
    PlaySoundFrontend(-1, 'Event_Start_Text', 'GTAO_FM_Events_Soundset', false)

    local blip = AddBlipForCoord(hit.x + 0.0, hit.y + 0.0, (hit.z or 30.0) + 0.0)
    SetBlipSprite(blip, Config.Blip.sprite)
    SetBlipColour(blip, Config.Blip.color)
    SetBlipScale(blip, Config.Blip.scale + 0.0)
    SetBlipFlashes(blip, true)
    SetBlipAsShortRange(blip, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName('ShotSpotter: ' .. (hit.zone or 'Gunfire'))
    EndTextCommandSetBlipName(blip)
    SetTimeout(Config.Blip.duration * 1000, function()
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end)
end)
