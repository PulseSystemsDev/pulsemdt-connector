-- PulseMDT :: pulse_shotspotter (Gunfire detection)
--
-- Gunfire inside a monitored zone creates a live CAD call and pings AVAILABLE
-- on-duty officers with the location. Zones are configured here; the zone
-- cooldown can also be changed from the dashboard's Scripts page.

Config = {}

-- Monitored zones: gunfire inside `radius` metres of the centre triggers.
Config.Zones = {
    { name = 'Downtown Los Santos', x = 215.0,   y = -810.0,  z = 30.0, radius = 250.0 },
    { name = 'South Los Santos',    x = 80.0,    y = -1900.0, z = 21.0, radius = 350.0 },
    { name = 'Vespucci Beach',      x = -1350.0, y = -1090.0, z = 4.0,  radius = 250.0 },
}

-- Seconds before the same zone can trigger again (also on the dashboard).
Config.ZoneCooldown = 60

-- Map blip shown to alerted officers.
Config.Blip = {
    sprite   = 161,
    color    = 1,
    scale    = 1.0,
    duration = 90,
}
