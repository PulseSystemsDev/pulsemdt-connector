# pulse_shotspotter

`pulse_shotspotter` detects gunfire inside configured coverage zones and sends PulseMDT alerts to available on-duty public-safety units.

## Requirements

- `pulsemdt`
- `pulse_notify` optional

## Installation

Define coverage zones and alert behavior in `config.lua`, then start `pulse_shotspotter` after `pulsemdt`.

## Configuration

`Config.Zones` defines named circular coverage areas. `Config.ZoneCooldown` limits repeat reports from the same zone, and `Config.Blip` controls temporary responder map markers.

Only shots fired inside a configured zone are reported. Tune zone size and cooldown for the density and pace of your server.
