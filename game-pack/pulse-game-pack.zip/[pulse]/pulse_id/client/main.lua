local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

local function nearestPlayerServerId()
    local me = PlayerPedId()
    local myCoords = GetEntityCoords(me)
    local closest, closestDist = nil, Config.Range + 0.0
    for _, pid in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(pid)
        if ped ~= me and DoesEntityExist(ped) then
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= closestDist then
                closest, closestDist = pid, dist
            end
        end
    end
    if closest then return GetPlayerServerId(closest) end
    return nil
end

local function playScanAnim()
    if not Config.Animation then return end
    local ped = PlayerPedId()
    RequestAnimDict('cellphone@')
    local deadline = GetGameTimer() + 3000
    while not HasAnimDictLoaded('cellphone@') and GetGameTimer() < deadline do Wait(25) end
    if HasAnimDictLoaded('cellphone@') then
        TaskPlayAnim(ped, 'cellphone@', 'cellphone_text_read_base', 3.0, -1, 2000, 49, 0, false, false, false)
    end
end

local function scan()
    local target = nearestPlayerServerId()
    if not target then
        notify('~y~PulseMDT~s~ No person within range.')
        return
    end
    playScanAnim()
    TriggerServerEvent('pulse_id:scan', { target = target })
end

RegisterCommand(Config.Command, function()
    scan()
end, false)

if Config.OpenKey then
    RegisterKeyMapping(Config.Command, 'PulseMDT: Scan nearest ID', 'keyboard', Config.OpenKey)
end

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb({})
end)

RegisterNetEvent('pulse_id:result', function(res)
    res = res or {}
    if res.error then
        notify('~r~PulseMDT~s~ ' .. res.error)
        return
    end
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'result', data = res })
end)
