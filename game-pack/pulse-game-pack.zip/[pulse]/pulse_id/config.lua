-- PulseMDT :: pulse_id (Identity & fingerprint scanner)
--
-- Reaches the CAD through the main `pulsemdt` resource, so no API key here.
-- Identity resolves through the target's active character: pulse_core when it
-- is running (standalone servers), otherwise the civilian portal's active
-- character selection.

Config = {}

-- Command an on-duty officer uses to scan the nearest person.
Config.Command = 'scanid'

-- Key that triggers a scan. Set to false to disable.
Config.OpenKey = false

-- How close (metres) the person must be to scan them.
Config.Range = 3.0

-- Play a short scanning animation on the officer.
Config.Animation = true

-- Every scan is written to the CAD access log so lookups are auditable.
Config.LogScans = true
