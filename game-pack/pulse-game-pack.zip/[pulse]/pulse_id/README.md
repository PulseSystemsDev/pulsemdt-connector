# pulse_id

`pulse_id` lets on-duty law-enforcement personnel scan the nearest player's active PulseMDT identity and fingerprint record.

## Requirements

- `pulsemdt`
- The target must have a linked active character; `pulse_core` is recommended
- `pulse_notify` optional

## Installation

Start `pulse_id` after `pulsemdt` and configure the command, optional key, range, animation, and audit logging in `config.lua`.

## Usage

- `/scanid` scans the nearest player by default.
- Set `Config.OpenKey` to enable a keyboard shortcut.

The scanner must be on duty in an eligible law-enforcement role. `Config.LogScans` controls whether successful scans are written to the PulseMDT audit log.
