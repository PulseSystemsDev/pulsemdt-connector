const RESOURCE = 'pulse_id';

const panel = document.getElementById('panel');
const noid = document.getElementById('noid');
const card = document.getElementById('card');
const warrantsEl = document.getElementById('warrants');
const rowsEl = document.getElementById('rows');
const vehiclesEl = document.getElementById('vehicles');
const priorsEl = document.getElementById('priors');

function post(name, body) {
  return fetch(`https://${RESOURCE}/${name}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json; charset=UTF-8' },
    body: JSON.stringify(body || {}),
  }).catch(() => {});
}

function age(dob) {
  if (!dob) return null;
  const d = new Date(dob);
  if (isNaN(d)) return null;
  return Math.max(0, Math.floor((Date.now() - d.getTime()) / (365.25 * 24 * 3600 * 1000)));
}

function initials(name) {
  return String(name || '?').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
}

function row(k, v, cls) {
  const r = document.createElement('div');
  r.className = 'r';
  const kEl = document.createElement('span');
  kEl.className = 'k';
  kEl.textContent = k;
  const vEl = document.createElement('span');
  vEl.className = 'v' + (cls ? ' ' + cls : '');
  vEl.textContent = v;
  r.append(kEl, vEl);
  return r;
}

function li(text, sub) {
  const el = document.createElement('li');
  const t = document.createElement('div');
  t.textContent = text;
  el.appendChild(t);
  if (sub) {
    const s = document.createElement('div');
    s.className = 'sub';
    s.textContent = sub;
    el.appendChild(s);
  }
  return el;
}

function emptyLi(text) {
  const el = document.createElement('li');
  el.className = 'empty';
  el.textContent = text;
  return el;
}

function render(res) {
  panel.classList.remove('hidden');

  if (res.noIdentity || !res.person) {
    noid.classList.remove('hidden');
    card.classList.add('hidden');
    return;
  }
  noid.classList.add('hidden');
  card.classList.remove('hidden');

  const p = res.person;
  const photo = document.getElementById('photo');
  if (p.photo_url) {
    photo.style.backgroundImage = `url("${p.photo_url}")`;
    photo.textContent = '';
  } else {
    photo.style.backgroundImage = '';
    photo.textContent = initials(p.name);
  }
  document.getElementById('name').textContent = p.name;
  const a = age(p.date_of_birth);
  const meta = [];
  if (a !== null) meta.push(`${a} years old`);
  if (p.gender) meta.push(p.gender);
  document.getElementById('meta').textContent = meta.join(' · ');

  const warrants = Array.isArray(res.warrants) ? res.warrants : [];
  if (warrants.length > 0) {
    warrantsEl.classList.remove('hidden');
    warrantsEl.innerHTML = '';
    const head = document.createElement('div');
    head.textContent = `ACTIVE WARRANT${warrants.length > 1 ? 'S' : ''} (${warrants.length})`;
    const ul = document.createElement('ul');
    for (const w of warrants) ul.appendChild(li(w.reason || 'No reason listed'));
    warrantsEl.append(head, ul);
  } else {
    warrantsEl.classList.add('hidden');
  }

  rowsEl.innerHTML = '';
  const suspended = String(p.license_status || '').toLowerCase() === 'suspended';
  rowsEl.append(
    row('License', suspended ? 'SUSPENDED' : (p.license_status || 'Valid'), suspended ? 'bad' : 'ok'),
    row('Occupation', p.job && p.job.trim() ? p.job : 'Unknown'),
    row('Warrants', warrants.length > 0 ? String(warrants.length) : 'None', warrants.length > 0 ? 'bad' : 'ok'),
  );
  if (p.height && String(p.height).trim()) rowsEl.append(row('Height', p.height));

  vehiclesEl.innerHTML = '';
  const vehicles = Array.isArray(res.vehicles) ? res.vehicles : [];
  if (vehicles.length === 0) vehiclesEl.appendChild(emptyLi('No registered vehicles.'));
  for (const v of vehicles.slice(0, 5)) {
    vehiclesEl.appendChild(li(`${v.plate} · ${v.model || 'Unknown model'}`, v.status || ''));
  }

  priorsEl.innerHTML = '';
  const records = Array.isArray(res.records) ? res.records : [];
  if (records.length === 0) priorsEl.appendChild(emptyLi('No priors on file.'));
  for (const r of records.slice(0, 6)) {
    priorsEl.appendChild(li(r.type || 'Record', r.details || ''));
  }
}

function close() {
  panel.classList.add('hidden');
  post('close');
}

window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'result') render(m.data || {});
});

document.getElementById('x').addEventListener('click', close);
document.getElementById('done').addEventListener('click', close);
document.addEventListener('keydown', (e) => {
  if (panel.classList.contains('hidden')) return;
  if (e.key === 'Escape') close();
});
