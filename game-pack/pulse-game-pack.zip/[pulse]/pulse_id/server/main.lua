local function getDiscordId(src)
    for _, id in ipairs(GetPlayerIdentifiers(src)) do
        if id:sub(1, 8) == 'discord:' then
            return id:sub(9)
        end
    end
    return nil
end

local function urlEncode(str)
    return (str:gsub('[^%w%-%.%_%~]', function(c) return string.format('%%%02X', string.byte(c)) end))
end

local function resolveCharId(targetSrc, cb)
    local ok, char = pcall(function()
        return exports.pulse_core:GetCharacter(targetSrc)
    end)
    if ok and char and char.id then
        cb(char.id)
        return
    end
    local discordId = getDiscordId(targetSrc)
    if not discordId then
        cb(nil)
        return
    end
    exports.pulsemdt:ApiRequest('GET', '/characters?withActive=1&discordId=' .. discordId, nil, function(code, res)
        if code == 200 and type(res) == 'table' and res.activeCharId then
            cb(res.activeCharId)
        else
            cb(nil)
        end
    end)
end

local RCFG = { enabled = true, settings = {} }
local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_id') end)
    if ok and type(c) == 'table' then RCFG = c end
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

RegisterNetEvent('pulse_id:scan', function(data)
    local src = source

    if not RCFG.enabled then
        TriggerClientEvent('pulse_id:result', src, { error = 'ID scanning is disabled on this server.' })
        return
    end

    local authorized = false
    pcall(function() authorized = exports.pulsemdt:HasCadJob(src, 'police', 'law') end)
    if not authorized then
        TriggerClientEvent('pulse_id:result', src, { error = 'An on-duty law-enforcement role is required to scan IDs.' })
        return
    end

    local targetSrc = tonumber(data and data.target)
    if not targetSrc or not GetPlayerName(targetSrc) then
        TriggerClientEvent('pulse_id:result', src, { error = 'No person nearby.' })
        return
    end

    resolveCharId(targetSrc, function(charId)
        if not charId then
            TriggerClientEvent('pulse_id:result', src, { noIdentity = true })
            return
        end
        local scannerDiscordId = getDiscordId(src)
        local ncicUrl = '/ncic?charId=' .. charId
        if scannerDiscordId then
            ncicUrl = ncicUrl .. '&actorId=' .. scannerDiscordId .. '&actorName=' .. urlEncode(GetPlayerName(src) or 'Officer')
        end
        exports.pulsemdt:ApiRequest('GET', ncicUrl, nil, function(code, res)
            if code == 200 and type(res) == 'table' and res.person then
                TriggerClientEvent('pulse_id:result', src, res)
                if Config.LogScans then
                    exports.pulsemdt:ApiWrite('POST', '/logs', {
                        discordId = scannerDiscordId,
                        event = 'id_scan',
                        details = ('%s scanned the ID of %s'):format(GetPlayerName(src), res.person.name),
                    }, nil)
                end
            elseif code == 0 then
                TriggerClientEvent('pulse_id:result', src, { error = 'Records are offline right now.' })
            else
                TriggerClientEvent('pulse_id:result', src, { noIdentity = true })
            end
        end)
    end)
end)
