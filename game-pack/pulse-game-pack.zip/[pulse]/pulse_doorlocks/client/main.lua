local doors = {}
local registeredDoorIds = {}
local enabled = true

local function notify(msg)
    local ok = pcall(function() exports.pulse_notify:Notify(msg) end)
    if ok then return end
    SetNotificationTextEntry('STRING')
    AddTextComponentSubstringPlayerName(msg)
    DrawNotification(false, true)
end

RegisterNetEvent('pulse_doorlocks:notify', function(msg)
    if msg then notify(msg) end
end)

local function applyDoorState(door)
    local doorHash = GetHashKey('pulse_door_' .. tostring(door.id))
    if not registeredDoorIds[door.id] then
        AddDoorToSystem(doorHash, door.model, door.x, door.y, door.z, false, false, false)
        registeredDoorIds[door.id] = doorHash
    end
    if DoesDoorExist(doorHash) then
        DoorSystemSetDoorState(doorHash, door.locked and 1 or 0, false, false)
    end
end

RegisterNetEvent('pulse_doorlocks:sync', function(payload)
    local previous = doors
    if type(payload) == 'table' and payload.doors then
        enabled = payload.enabled ~= false
        doors = payload.doors or {}
    else
        enabled = true
        doors = payload or {}
    end
    if not enabled then
        for _, door in ipairs(previous) do
            local doorHash = registeredDoorIds[door.id]
            if doorHash and DoesDoorExist(doorHash) then
                DoorSystemSetDoorState(doorHash, 0, false, false)
            end
        end
    end
    for _, door in ipairs(doors) do
        applyDoorState(door)
    end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(200) end
    Wait(1500)
    TriggerServerEvent('pulse_doorlocks:requestSync')
end)

local function aimedEntity()
    local camCoord = GetGameplayCamCoord()
    local camRot = GetGameplayCamRot(2)
    local radX, radZ = math.rad(camRot.x), math.rad(camRot.z)
    local cosX = math.abs(math.cos(radX))
    local dir = vector3(-math.sin(radZ) * cosX, math.cos(radZ) * cosX, math.sin(radX))
    local dest = camCoord + dir * 10.0
    local ray = StartShapeTestRay(camCoord.x, camCoord.y, camCoord.z, dest.x, dest.y, dest.z, 16, PlayerPedId(), 0)
    local _, hit, _, _, entity = GetShapeTestResult(ray)
    if hit == 1 and entity ~= 0 then return entity end
    return nil
end

RegisterCommand('dooradd', function(_, args)
    if not enabled then
        notify('~y~Doorlocks~s~ This script is disabled on the server.')
        return
    end
    local entity = aimedEntity()
    if not entity then
        notify('~r~Doorlocks~s~ Aim at a door within a few metres and try again.')
        return
    end
    local label = table.concat(args, ' ')
    if label == '' then label = 'Door' end
    local pos = GetEntityCoords(entity)
    TriggerServerEvent('pulse_doorlocks:register', {
        label = label, model = GetEntityModel(entity),
        x = pos.x, y = pos.y, z = pos.z, heading = GetEntityHeading(entity),
    })
end, false)

CreateThread(function()
    while true do
        local sleep = 900
        if enabled then
            local pos = GetEntityCoords(PlayerPedId())
            for _, door in ipairs(doors) do
                local dist = #(pos - vector3(door.x, door.y, door.z))
                if dist < 20.0 then
                    sleep = 0
                    if dist <= Config.InteractRange then
                        BeginTextCommandDisplayHelp('STRING')
                        AddTextComponentSubstringPlayerName(door.locked and 'Press ~INPUT_CONTEXT~ to unlock' or 'Press ~INPUT_CONTEXT~ to lock')
                        EndTextCommandDisplayHelp(0, false, true, -1)
                        if IsControlJustReleased(0, 38) then
                            TriggerServerEvent('pulse_doorlocks:toggle', door.id)
                            Wait(500)
                        end
                    end
                end
            end
        end
        Wait(sleep)
    end
end)
