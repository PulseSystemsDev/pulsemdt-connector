local doors = {}
local nextId = 1
local RCFG = { enabled = true, settings = {} }

local function moduleEnabled()
    return RCFG.enabled ~= false
end

local function loadDoors()
    local raw = LoadResourceFile(GetCurrentResourceName(), 'doors.json')
    if not raw then return end
    local ok, data = pcall(json.decode, raw)
    if ok and type(data) == 'table' then
        doors = data
        for _, d in ipairs(doors) do
            if d.id >= nextId then nextId = d.id + 1 end
        end
    end
end

local function saveDoors()
    SaveResourceFile(GetCurrentResourceName(), 'doors.json', json.encode(doors), -1)
end

local function syncDoors(target)
    TriggerClientEvent('pulse_doorlocks:sync', target or -1, {
        enabled = moduleEnabled(),
        doors = moduleEnabled() and doors or {},
    })
end

loadDoors()

local function refreshRemote()
    local ok, c = pcall(function() return exports.pulsemdt:GetScriptConfig('pulse_doorlocks') end)
    if ok and type(c) == 'table' then RCFG = c end
    syncDoors()
end
AddEventHandler('pulsemdt:scriptsRefreshed', refreshRemote)
CreateThread(function() Wait(4000) refreshRemote() end)

RegisterNetEvent('pulse_doorlocks:requestSync', function()
    syncDoors(source)
end)

local function isDoorAdmin(src)
    return IsPlayerAceAllowed(src, Config.AcePermission)
end

local function notify(src, msg)
    TriggerClientEvent('chat:addMessage', src, { args = { '^3Doorlocks', msg } })
end

RegisterNetEvent('pulse_doorlocks:register', function(data)
    local src = source
    if not moduleEnabled() then return end
    if not isDoorAdmin(src) then return end
    if not data or not tonumber(data.x) then return end

    doors[#doors + 1] = {
        id = nextId, label = tostring(data.label or 'Door'), model = tonumber(data.model) or 0,
        x = tonumber(data.x), y = tonumber(data.y), z = tonumber(data.z), heading = tonumber(data.heading) or 0.0,
        minRank = Config.DefaultMinRank, departments = nil, locked = true,
    }
    nextId = nextId + 1
    saveDoors()
    syncDoors()
    notify(src, ('Door "%s" registered (id %d).'):format(data.label or 'Door', doors[#doors].id))
end)

RegisterCommand('doorlist', function(src)
    if src == 0 or not isDoorAdmin(src) then return end
    if #doors == 0 then notify(src, 'No doors registered.') return end
    for _, d in ipairs(doors) do
        notify(src, ('#%d %s - min rank %d%s'):format(d.id, d.label, d.minRank, d.locked and ' (locked)' or ' (unlocked)'))
    end
end, false)

RegisterCommand('doorremove', function(src, args)
    if src == 0 or not isDoorAdmin(src) then return end
    local id = tonumber(args[1])
    if not id then notify(src, 'Usage: /doorremove <id>') return end
    for i, d in ipairs(doors) do
        if d.id == id then
            table.remove(doors, i)
            saveDoors()
            syncDoors()
            notify(src, ('Door #%d removed.'):format(id))
            return
        end
    end
    notify(src, 'No door with that id.')
end, false)

RegisterCommand('doorrank', function(src, args)
    if src == 0 or not isDoorAdmin(src) then return end
    local id = tonumber(args[1])
    local rank = tonumber(args[2])
    if not id or not rank then notify(src, 'Usage: /doorrank <id> <rank>') return end
    for _, d in ipairs(doors) do
        if d.id == id then
            d.minRank = rank
            saveDoors()
            syncDoors()
            notify(src, ('Door #%d minimum rank set to %d.'):format(id, rank))
            return
        end
    end
    notify(src, 'No door with that id.')
end, false)

local function rankLevel(role)
    if type(role) ~= 'string' then return 1 end
    for name, level in pairs(Config.RankLevels) do
        if name:lower() == role:lower() then return level end
    end
    return 1
end

RegisterNetEvent('pulse_doorlocks:toggle', function(doorId)
    local src = source
    if not moduleEnabled() then return end
    local door = nil
    for _, d in ipairs(doors) do if d.id == doorId then door = d break end end
    if not door then return end

    local officer = nil
    pcall(function() officer = exports.pulsemdt:GetOfficer(src) end)
    if not officer then
        TriggerClientEvent('pulse_doorlocks:notify', src, '~r~Go on duty before using this door.')
        return
    end
    if rankLevel(officer.role) < door.minRank then
        TriggerClientEvent('pulse_doorlocks:notify', src, '~r~You do not have clearance for this door.')
        return
    end

    door.locked = not door.locked
    saveDoors()
    syncDoors()
    TriggerClientEvent('pulse_doorlocks:notify', src, door.locked and '~y~Door locked.' or '~g~Door unlocked.')
end)

exports('IsDoorLocked', function(doorId)
    if not moduleEnabled() then return nil end
    for _, d in ipairs(doors) do if d.id == doorId then return d.locked end end
    return nil
end)

-- For trusted server-side callers (like pulse_property) that have already
-- done their own permission check (property ownership, not officer rank) and
-- just need to set the resulting state, bypassing the rank/department gate
-- pulse_doorlocks:toggle enforces for its own player-facing interact prompt.
exports('SetDoorLocked', function(doorId, locked)
    if not moduleEnabled() then return false end
    for _, d in ipairs(doors) do
        if d.id == doorId then
            d.locked = locked
            saveDoors()
            syncDoors()
            return true
        end
    end
    return false
end)

exports('RegisterDoor', function(label, model, x, y, z, heading, minRank)
    if not moduleEnabled() then return nil end
    doors[#doors + 1] = {
        id = nextId, label = label, model = model, x = x, y = y, z = z, heading = heading or 0.0,
        minRank = minRank or Config.DefaultMinRank, departments = nil, locked = true,
    }
    nextId = nextId + 1
    saveDoors()
    syncDoors()
    return doors[#doors].id
end)

-- Trusted server-side cleanup for resources that own a registered door.
exports('RemoveDoor', function(doorId)
    for i, door in ipairs(doors) do
        if door.id == tonumber(doorId) then
            table.remove(doors, i)
            saveDoors()
            syncDoors()
            return true
        end
    end
    return false
end)
