-- PulseMDT :: pulse_doorlocks (Lockable world doors)
--
-- Lock/unlock world doors (evidence lockers, armories, restricted rooms) with
-- rank and department permission, the same gating pulse_hub already uses for
-- its garage and armory entries. Door state is resource-local (a JSON file,
-- the same idiom pulse_cameras uses for placed cameras), not CAD-persisted,
-- since doors are server fixtures, not character-owned property.
--
-- Other resources (a future property system, for example) can register and
-- check a door through the exports below instead of reimplementing this.
--
-- Admin commands (require the ace permission below):
--   /dooradd [name]        register the door you're aiming at
--   /doorlist              list registered doors in chat
--   /doorremove <id>       remove a door
--   /doorrank <id> <rank>  set the minimum rank required to use a door
--
-- Grant an admin access in server.cfg:
--   add_ace group.admin pulse.doorlocks allow

Config = {}

Config.AcePermission = 'pulse.doorlocks'

-- Range (metres) to interact with a registered door.
Config.InteractRange = 1.8

-- Rank names to numeric levels, matched against the on-duty officer's role,
-- same idiom as pulse_hub's Config.RankLevels.
Config.RankLevels = {
    ['Officer'] = 1,
    ['Corporal'] = 2,
    ['Sergeant'] = 3,
    ['Lieutenant'] = 4,
    ['Chief'] = 5,
}

-- Default minimum rank for newly registered doors (raise per-door with
-- /doorrank).
Config.DefaultMinRank = 1
