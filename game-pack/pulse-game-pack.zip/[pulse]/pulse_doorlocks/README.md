# pulse_doorlocks

`pulse_doorlocks` creates persistent world-door locks with on-duty department and rank checks.

## Requirements

- `pulsemdt`
- OneSync recommended
- `pulse_notify` optional

## Installation

Start `pulse_doorlocks` after `pulsemdt` and grant administrators the configured ACE permission:

```cfg
add_ace group.admin pulse.doorlocks allow
ensure pulse_doorlocks
```

## Commands

- `/dooradd <label> [minimum-rank]` registers the nearby/aimed-at door.
- `/doorlist` lists registered doors.
- `/doorremove <id>` removes a door.
- `/doorrank <id> <rank>` changes its minimum rank.

Configure interaction range and rank mappings in `config.lua`. Door state is stored in `doors.json`. Server exports are provided to inspect, change, or register door locks programmatically.
